package me.wolfsurge.mixin.mixins;

import cf.radeon.managers.ModuleManager;
import cf.radeon.module.modules.render.BlockHighlight;
import net.minecraft.client.renderer.RenderGlobal;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.RayTraceResult;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(RenderGlobal.class)
public final class MixinRenderGlobal {
    @Inject(method = "drawSelectionBox", at = @At("HEAD"), cancellable = true)
    public void drawSelectionBox(EntityPlayer entityPlayer, RayTraceResult rayTraceResult, int execute,
                                 float partialTicks, CallbackInfo callbackInfo) {
        if (ModuleManager.getModuleByName("BlockHighlight") != null && !ModuleManager.getModuleByName("BlockHighlight").nullCheck() && ModuleManager.getModuleByName("BlockHighlight").isEnabled()
                && BlockHighlight.cancelSelectionBox.getValue()) {
            callbackInfo.cancel();
        }
    }
}
