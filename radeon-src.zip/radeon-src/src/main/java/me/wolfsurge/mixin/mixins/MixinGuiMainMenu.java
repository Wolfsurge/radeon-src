package me.wolfsurge.mixin.mixins;

import net.minecraft.client.gui.GuiMainMenu;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import cf.radeon.gui.mainmenu.MainMenuHook;

@Mixin(value = GuiMainMenu.class, priority = 2147483647)
public class MixinGuiMainMenu {

    @Inject(method = {"drawScreen"}, at = {@At("TAIL")}, cancellable = true)
    public void drawScreen(int mouseX, int mouseY, float partialTicks, CallbackInfo ci) {
		MainMenuHook.render(mouseX, mouseY);
    }

}
