package me.wolfsurge.mixin.mixins;

import cf.radeon.module.modules.render.Xray;
import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value = Block.class, priority = 2147483647)
public final class MixinBlock {

    @Inject(method = "shouldSideBeRendered", at = @At("HEAD"), cancellable = true)
    public void renderSidePatch(IBlockState blockState, IBlockAccess blockAccess, BlockPos pos, EnumFacing side, CallbackInfoReturnable<Boolean> cir) {
        if (Xray.doXray) {
            if (Xray.xrayBlocks.contains(blockState.getBlock())) {
                cir.setReturnValue(true);
            } else {
                cir.setReturnValue(false);
                cir.cancel();
            }
        }
    }


    @Inject(method = "isFullCube", at = @At("HEAD"), cancellable = true)
    public void fullCubePatch(IBlockState iBlockState, CallbackInfoReturnable<Boolean> callbackInfoReturnable) {
        if (Xray.doXray) {
            callbackInfoReturnable.setReturnValue(Xray.xrayBlocks.contains(iBlockState.getBlock()));
        }
    }
}
