package me.wolfsurge.mixin.mixins;

import cf.radeon.managers.ModuleManager;
import cf.radeon.module.modules.movement.NoSlow;
import me.wolfsurge.api.util.Globals;
import net.minecraft.client.gui.GuiChat;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.util.MovementInput;
import net.minecraft.util.MovementInputFromOptions;
import org.lwjgl.input.Keyboard;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(value = MovementInputFromOptions.class)
public final class MixinMovementInputFromOptions extends MovementInput implements Globals {
    @Redirect(method = "updatePlayerMoveState", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/settings/KeyBinding;isKeyDown()Z"))
    public boolean isKeyPressed(KeyBinding keyBinding) {
        if (ModuleManager.getModuleByName("NoSlow").isEnabled() && NoSlow.guiMove.getValue() && mc.currentScreen != null
                && !(mc.currentScreen instanceof GuiChat)) {
            return Keyboard.isKeyDown(keyBinding.getKeyCode());
        }

        return keyBinding.isKeyDown();
    }
}
