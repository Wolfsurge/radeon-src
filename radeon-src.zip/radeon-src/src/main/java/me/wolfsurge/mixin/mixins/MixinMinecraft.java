package me.wolfsurge.mixin.mixins;

import cf.radeon.Radeon;
import cf.radeon.animation.Delta;
import net.minecraft.client.Minecraft;
import net.minecraft.world.WorldSettings;
import org.lwjgl.Sys;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Minecraft.class)
public class MixinMinecraft {

    // Animation
    long lastFrame = getTime();
    long getTime() { return (Sys.getTime() * 1000) / Sys.getTimerResolution(); }

    @Inject(method = "runGameLoop", at = @At("HEAD"))
    private void runGameLoop(CallbackInfo ci) {
        long currentTime = getTime();
        int deltaTime = (int) (currentTime - lastFrame);
        lastFrame = currentTime;
        Delta.DELTATIME = deltaTime;
    }

    @Inject(method = "launchIntegratedServer", at={@At("TAIL")})
    public void singlePlayerDiscordRP(String minecraftsessionservice, String gameprofilerepository, WorldSettings playerprofilecache, CallbackInfo ci) {
        Radeon.discordManager.update("Playing Singleplayer");
    }

    @Inject(method = { "shutdown" }, at = { @At("HEAD") })
    public void shutdown(final CallbackInfo info) {
        Radeon.shutdown();
    }

}
