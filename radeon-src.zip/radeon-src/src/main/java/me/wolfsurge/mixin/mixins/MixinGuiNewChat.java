package me.wolfsurge.mixin.mixins;

import cf.radeon.managers.ModuleManager;
import cf.radeon.module.modules.misc.ChatTweaks;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiNewChat;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(value = GuiNewChat.class, priority = 2147483647)
public final class MixinGuiNewChat {

    @Redirect(method = "drawChat", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/GuiNewChat;drawRect(IIIII)V"))
    public void drawBackground(int left, int top, int right, int bottom, int colour) {
        if (!ModuleManager.getModuleByName("ChatTweaks").isEnabled() || !ChatTweaks.clearBackground.getValue()) {
            Gui.drawRect(left, top, right, bottom, colour);
        }
    }
}

