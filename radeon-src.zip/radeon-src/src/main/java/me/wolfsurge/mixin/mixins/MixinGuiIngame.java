package me.wolfsurge.mixin.mixins;

import cf.radeon.module.modules.render.NoRender;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import cf.radeon.Radeon;
import net.minecraft.client.gui.GuiIngame;
import net.minecraft.client.gui.ScaledResolution;

@Mixin(value = GuiIngame.class, priority = 2147483647)
public abstract class MixinGuiIngame {
	
	@Inject(method = "renderPotionEffects", at = {@At("HEAD")}, cancellable = true)
	public void hookPotions(ScaledResolution sr, CallbackInfo info) {
		if(Radeon.moduleManager.isModuleEnabled("NoRender") && NoRender.potionIcons.isEnabled())
			info.cancel();
	}

	@Inject(method={"renderPortal"}, at = {@At("HEAD")}, cancellable = true)
	public void hookPortal(CallbackInfo info) {
		if(Radeon.moduleManager.isModuleEnabled("NoRender") && NoRender.portal.isEnabled()) {
			info.cancel();
		}
	}
}

