package me.wolfsurge.mixin.mixins;

import net.minecraft.client.gui.GuiScreen;
import net.minecraft.util.ResourceLocation;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(GuiScreen.class)
public class MixinGuiScreen {
}
