package me.wolfsurge.mixin.mixins;

import cf.radeon.managers.ModuleManager;
import cf.radeon.module.modules.exploit.Portals;
import cf.radeon.module.modules.movement.Velocity;
import me.wolfsurge.api.util.Globals;
import net.minecraft.client.gui.GuiScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import cf.radeon.Radeon;
import cf.radeon.event.impl.MotionEvent;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value = EntityPlayerSP.class, priority = 2147483647)
public class MixinEntityPlayerSP implements Globals {

	@Redirect(method = "onLivingUpdate", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/entity/EntityPlayerSP;closeScreen()V"))
	public void closeScreen(EntityPlayerSP entityPlayerSP) {
		if (ModuleManager.getModuleByName("Portals").isEnabled() && Portals.useGUIS.getValue())
			return;
	}

	@Redirect(method = "onLivingUpdate", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/Minecraft;displayGuiScreen(Lnet/minecraft/client/gui/GuiScreen;)V"))
	public void closeScreen(Minecraft minecraft, GuiScreen guiScreen) {
		if (ModuleManager.getModuleByName("Portals").isEnabled() && Portals.useGUIS.getValue())
			return;
	}

	@Inject(method = {"onUpdateWalkingPlayer"}, at = {@At("TAIL")}, cancellable = true)
	public void hookUWPPost(CallbackInfo ci) {
		Minecraft mc = Minecraft.getMinecraft();
		MotionEvent e = new MotionEvent(mc.player.posX, (mc.player.getEntityBoundingBox()).minY, mc.player.posZ, mc.player.rotationYaw, mc.player.rotationPitch, mc.player.onGround);
		Radeon.EVENT_BUS.post(e);
	}

	@Inject(method = "pushOutOfBlocks(DDD)Z", at = @At("HEAD"), cancellable = true)
	public void pushOutOfBlocks(double x, double y, double z, CallbackInfoReturnable<Boolean> callbackInfoReturnable) {
		if (ModuleManager.getModuleByName("Velocity").isEnabled() && Velocity.noPush.getValue()
				&& Velocity.noPushBlocks.getValue()) {
			callbackInfoReturnable.setReturnValue(false);
		}
	}

}
