package me.wolfsurge.mixin.mixins;

import cf.radeon.Radeon;
import net.minecraft.client.multiplayer.GuiConnecting;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value = GuiConnecting.class, priority = 2147483647)
public class MixinGuiConnecting {

    @Inject(method="drawScreen", at=@At("HEAD"))
    public void drawScreen(int mouseX, int mouseY, float partialTicks, CallbackInfo ci) {
        Radeon.discordManager.update("Playing Multiplayer");
    }

}
