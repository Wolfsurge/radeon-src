package me.wolfsurge.mixin.mixins;

import cf.radeon.managers.ModuleManager;
import cf.radeon.module.modules.render.Chams;
import me.wolfsurge.api.util.Globals;
import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.client.renderer.entity.RenderPlayer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(RenderPlayer.class)
public final class MixinRenderPlayer implements Globals {
    @Inject(method = "renderLeftArm", at = @At(value = "FIELD", target = "Lnet/minecraft/client/model/ModelPlayer;swingProgress:F", opcode = 181), cancellable = true)
    public void renderLeftArmPre(AbstractClientPlayer abstractClientPlayer, CallbackInfo callbackInfo) {
        if (ModuleManager.getModuleByName("Chams") != null && !ModuleManager.getModuleByName("Chams").nullCheck() && abstractClientPlayer == mc.player && ModuleManager.getModuleByName("Chams").isEnabled()
                && Chams.leftArm.getValue()) {
            try {
                Chams.chamsMode.renderLeftArmPre(abstractClientPlayer, callbackInfo);
            } catch (Exception ignored) {
            }
        }
    }

    @Inject(method = "renderLeftArm", at = @At(value = "RETURN"), cancellable = true)
    public void renderLeftArmPost(AbstractClientPlayer abstractClientPlayer, CallbackInfo callbackInfo) {
        if (ModuleManager.getModuleByName("Chams") != null && !ModuleManager.getModuleByName("Chams").nullCheck() && abstractClientPlayer == mc.player && ModuleManager.getModuleByName("Chams").isEnabled()
                && Chams.leftArm.getValue()) {
            Chams.chamsMode.renderLeftArmPost(abstractClientPlayer, callbackInfo);
        }
    }

    @Inject(method = "renderRightArm", at = @At(value = "FIELD", target = "Lnet/minecraft/client/model/ModelPlayer;swingProgress:F", opcode = 181), cancellable = true)
    public void renderRightArmPre(AbstractClientPlayer abstractClientPlayer, CallbackInfo callbackInfo) {
        if (ModuleManager.getModuleByName("Chams") != null && !ModuleManager.getModuleByName("Chams").nullCheck() && abstractClientPlayer == mc.player && ModuleManager.getModuleByName("Chams").isEnabled()
                && Chams.rightArm.getValue()) {
            try {
                Chams.chamsMode.renderRightArmPre(abstractClientPlayer, callbackInfo);
            } catch (Exception ignored) {
            }
        }
    }

    @Inject(method = "renderRightArm", at = @At(value = "RETURN"), cancellable = true)
    public void renderRightArmPost(AbstractClientPlayer abstractClientPlayer, CallbackInfo callbackInfo) {
        if (ModuleManager.getModuleByName("Chams") != null && !ModuleManager.getModuleByName("Chams").nullCheck() && abstractClientPlayer == mc.player && ModuleManager.getModuleByName("Chams").isEnabled()
                && Chams.rightArm.getValue()) {
            Chams.chamsMode.renderRightArmPost(abstractClientPlayer, callbackInfo);
        }
    }

    @Inject(method={"renderEntityName"}, at={@At(value="HEAD")}, cancellable=true)
    public void renderEntityNameHook(AbstractClientPlayer entityIn, double x, double y, double z, String name, double distanceSq, CallbackInfo info) {
        if (ModuleManager.getModuleByName("Nametags") != null && !ModuleManager.getModuleByName("Nametags").nullCheck() && ModuleManager.getModuleByName("Nametags").isEnabled()) {
            info.cancel();
        }
    }
}

