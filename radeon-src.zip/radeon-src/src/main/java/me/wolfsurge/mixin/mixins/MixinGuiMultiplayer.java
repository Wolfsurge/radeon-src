package me.wolfsurge.mixin.mixins;

import cf.radeon.Radeon;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiMultiplayer;
import net.minecraft.client.gui.GuiScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.io.IOException;

@Mixin(value = GuiMultiplayer.class, priority = 2147483647)
public abstract class MixinGuiMultiplayer extends GuiScreen {

    @Inject(method="drawScreen", at={@At("TAIL")})
    public void drawScreen(int mouseX, int mouseY, float partialTicks, CallbackInfo ci) {
        Radeon.discordManager.update("In Multiplayer Menu");
    }

    @Inject(method="actionPerformed", at={@At("TAIL")})
    protected void actionPerformed(GuiButton s1, CallbackInfo ci) throws IOException {}
}
