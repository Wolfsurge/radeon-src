package cf.radeon.clickgui.component.components;

import java.util.ArrayList;
import cf.radeon.animation.Animate;
import cf.radeon.animation.Easing;
import cf.radeon.clickgui.component.Component;
import cf.radeon.clickgui.component.Frame;
import cf.radeon.clickgui.component.components.sub.*;
import cf.radeon.managers.FontManager;
import cf.radeon.module.Module;
import cf.radeon.module.modules.client.ClickGuiModule;
import cf.radeon.module.settings.*;
import cf.radeon.utils.render.ColorUtil;
import cf.radeon.utils.render.RenderUtils2D;
import net.minecraft.client.Minecraft;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.opengl.GL11;
import net.minecraft.client.gui.Gui;
import static net.minecraft.client.renderer.GlStateManager.*;
import static org.lwjgl.opengl.GL11.*;

public class Button extends Component {

	public Module mod;
	public Frame parent;
	public int offset;
	private boolean isHovered;
	public ArrayList<Component> subcomponents;
	public boolean open;
	public int index;

	private final Animate animate = new Animate();

	public Button(Module mod, Frame parent, int index, int offset) {
		this.mod = mod;
		this.parent = parent;
		this.offset = offset;
		this.subcomponents = new ArrayList<>();
		this.open = false;
		this.index = index;
		int opY = offset + 12;

		for(Setting s : mod.settings) {
			if(s instanceof BooleanSetting) {
				this.subcomponents.add(new BooleanComponent((BooleanSetting) s, this, opY));
				opY += 12;
			} else if(s instanceof NumberSetting) {
				this.subcomponents.add(new SliderComponent((NumberSetting) s, this, opY));
				opY += 12;
			} else if(s instanceof ModeSetting) {
				this.subcomponents.add(new ModeButton(this, (ModeSetting) s, opY));
				opY += 12;
			} else if(s instanceof ColourPicker) {
				this.subcomponents.add(new ColourComponent((ColourPicker) s, this, opY));
				opY += 12;
			} else if(s instanceof StringSetting) {
				this.subcomponents.add(new StringComponent((StringSetting) s, this, opY));
				opY += 12;
			} else if(s instanceof KeybindSetting) {
				this.subcomponents.add(new KeybindComponent((KeybindSetting) s, this, opY));
				opY += 12;
			}
		}

		animate.setMin(0).setMax(90).setSpeed(200).setEase(Easing.CUBIC_IN_OUT).setReversed(false);
	}
	
	@Override
	public void setOff(int newOff) {
		offset = newOff;
		int opY = offset + 12;
		for(Component comp : this.subcomponents) {
			comp.setOff(opY);
			opY += comp.getHeight();
		}
	}
	
	@Override
	public void renderComponent(int mouseX, int mouseY) {
		animate.update();

		Gui.drawRect(parent.getX(), this.parent.getY() + this.offset, parent.getX() + parent.getWidth(), this.parent.getY() + 12 + this.offset, this.isHovered ? (this.mod.isEnabled() ? ClickGuiModule.hovered.getColor().getRGB() : ClickGuiModule.hovered.getColor().darker().getRGB()) : (this.mod.isEnabled() ? ClickGuiModule.enabled.getColor().getRGB(): ClickGuiModule.background.getColor().getRGB()));

		if(ClickGuiModule.rainbow.isEnabled())
			RenderUtils2D.drawGradientRect(parent.getX(), this.parent.getY() + this.offset, parent.getX() + parent.getWidth(), this.parent.getY() + 12 + this.offset,
					ColorUtil.rainbowWave(4, 1, 1, this.index * 150), ColorUtil.rainbowWave(4, 1, 1, (this.index + 1) * 150), false);

		glPushMatrix();
		FontManager.drawSmallStringWithShadow(this.mod.getName(), (parent.getX() + 2), (parent.getY() + offset + 2) + 2, this.mod.isEnabled() ? ClickGuiModule.enabledText.getColor().getRGB() : 0x999999);
		if(this.subcomponents.size() > 2) {
			pushMatrix();

			RenderUtils2D.drawRect(parent.getX() + parent.getWidth() - 8, parent.getY() + offset + 5.5, parent.getX() + parent.getWidth() - 2, parent.getY() + offset + 6.5, -1);
			RenderUtils2D.rotate(parent.getX() + parent.getWidth() - 8, parent.getY() + offset + 5.5, 6, 1, animate.getValue());
			RenderUtils2D.drawRect(parent.getX() + parent.getWidth() - 8, parent.getY() + offset + 5.5, parent.getX() + parent.getWidth() - 2, parent.getY() + offset + 6.5, -1);

			popMatrix();
		}

		glPopMatrix();
		if(open && !this.subcomponents.isEmpty()) {
			for(Component comp : this.subcomponents) {
				comp.renderComponent(mouseX, mouseY);
			}

			int len = 0;
			for(Component c : this.subcomponents) len += c.getHeight();

			RenderUtils2D.drawRect(parent.getX() + 2, parent.getY() + this.offset + 12, parent.getX() + 3, parent.getY() + this.offset + 12 + len, (ClickGuiModule.rainbow.isEnabled() ? ColorUtil.rainbowWave(4, 1, 1, this.index * 150) : ClickGuiModule.header.getColor().getRGB()));
		}
	}
	
	@Override
	public int getHeight() {
		if(this.open) {
			int h = 0;
			for(Component c : subcomponents) h += c.getHeight();
			return 12 + h;
		}
		return 12;
	}
	
	@Override
	public void updateComponent(int mouseX, int mouseY) {
		this.isHovered = isMouseOnButton(mouseX, mouseY);
		if(!this.subcomponents.isEmpty()) {
			int off = this.offset + 12;
			for(Component comp : this.subcomponents) {
				comp.updateComponent(mouseX, mouseY);
				comp.setOff(off);
				off += comp.getHeight();
			}
		}
	}
	
	@Override
	public void mouseClicked(int mouseX, int mouseY, int button) {
		if(isMouseOnButton(mouseX, mouseY) && button == 0) {
			this.mod.toggle();
		}
		if(isMouseOnButton(mouseX, mouseY) && button == 1) {
			this.open = !this.open;
			this.animate.setReversed(!this.animate.isReversed());
			this.parent.refresh();
		}
		for(Component comp : this.subcomponents) {
			comp.mouseClicked(mouseX, mouseY, button);
		}
	}
	
	@Override
	public void mouseReleased(int mouseX, int mouseY, int mouseButton) {
		for(Component comp : this.subcomponents) {
			comp.mouseReleased(mouseX, mouseY, mouseButton);
		}
	}
	
	@Override
	public void keyTyped(char typedChar, int key) {
		if(this.open) {
			for (Component comp : this.subcomponents) {
				comp.keyTyped(typedChar, key);
			}
		}
	}
	
	public boolean isMouseOnButton(int x, int y) {
		if(x > parent.getX() && x < parent.getX() + parent.getWidth() && y > this.parent.getY() + this.offset && y < this.parent.getY() + 12 + this.offset) {
			return true;
		}
		return false;
	}
}
