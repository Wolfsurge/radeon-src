package cf.radeon.clickgui.component.components.sub;

import cf.radeon.clickgui.component.Component;
import cf.radeon.clickgui.component.components.Button;
import cf.radeon.managers.FontManager;
import cf.radeon.module.modules.client.ClickGuiModule;
import cf.radeon.module.settings.KeybindSetting;
import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.GL11;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;  

public class KeybindComponent extends Component {

	private boolean hovered;
	private boolean binding;
	private Button parent;
	private KeybindSetting ks;
	private int offset;
	private int x;
	private int y;
	
	public KeybindComponent(KeybindSetting keybindSetting, Button button, int offset) {
		this.parent = button;
		this.ks = keybindSetting;
		this.x = button.parent.getX() + button.parent.getWidth();
		this.y = button.parent.getY() + button.offset;
		this.offset = offset;
	}
	
	@Override
	public void setOff(int newOff) {
		offset = newOff;
	}
	
	@Override
	public void renderComponent(int mouseX, int mouseY) {
		Gui.drawRect(parent.parent.getX() + 2, parent.parent.getY() + offset, parent.parent.getX() + (parent.parent.getWidth() * 1), parent.parent.getY() + offset + 12, this.hovered ? ClickGuiModule.hovered.getColor().getRGB() : ClickGuiModule.background.getColor().getRGB());
		Gui.drawRect(parent.parent.getX(), parent.parent.getY() + offset, parent.parent.getX() + 2, parent.parent.getY() + offset + 12, ClickGuiModule.background.getColor().getRGB());
		GL11.glPushMatrix();
		GL11.glScalef(0.5f,0.5f, 0.5f);
		FontManager.drawStringWithShadow(binding ? "Press a key..." : (ks.getName() + ": " + Keyboard.getKeyName(this.ks.getKeyCode())), (parent.parent.getX() + 7) * 2, (parent.parent.getY() + offset + 2) * 2 + 5, -1);
		GL11.glPopMatrix();
	}

	@Override
	public int getHeight() {
		return 12;
	}

	@Override
	public void updateComponent(int mouseX, int mouseY) {
		this.hovered = isMouseOnButton(mouseX, mouseY);
		this.y = parent.parent.getY() + offset;
		this.x = parent.parent.getX();
	}
	
	@Override
	public void mouseClicked(int mouseX, int mouseY, int button) {
		if(isMouseOnButton(mouseX, mouseY) && button == 0 && this.parent.open)
			this.binding = !this.binding;
		else if(isMouseOnButton(mouseX, mouseY) && button == 1 && this.parent.open) {
			this.binding = false;
			this.ks.setKeyCode(0);
		}
	}
	
	@Override
	public void keyTyped(char typedChar, int key) {
		if(this.binding) {
			this.ks.setKeyCode(key);
			this.binding = false;
		}
	}
	
	public boolean isMouseOnButton(int x, int y) {
		if(x > this.x && x < this.x + 88 && y > this.y && y < this.y + 12) {
			return true;
		}
		return false;
	}
}
