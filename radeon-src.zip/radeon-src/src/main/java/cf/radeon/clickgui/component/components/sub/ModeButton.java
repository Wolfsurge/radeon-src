package cf.radeon.clickgui.component.components.sub;

import cf.radeon.clickgui.component.Component;
import cf.radeon.clickgui.component.components.Button;
import cf.radeon.managers.FontManager;
import cf.radeon.module.Module;
import cf.radeon.module.modules.client.ClickGuiModule;
import cf.radeon.module.settings.ModeSetting;
import org.lwjgl.opengl.GL11;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;

public class ModeButton extends Component {

	private boolean hovered;
	private Button parent;
	private int offset;
	private int x;
	private int y;
	private ModeSetting mod;
	
	public ModeButton(Button button, ModeSetting modeSetting, int offset) {
		this.parent = button;
		this.mod = modeSetting;
		this.x = button.parent.getX() + button.parent.getWidth();
		this.y = button.parent.getY() + button.offset;
		this.offset = offset;
	}
	
	@Override
	public void setOff(int newOff) {
		offset = newOff;
	}
	
	@Override
	public void renderComponent(int mouseX, int mouseY) {
		Gui.drawRect(parent.parent.getX() + 2, parent.parent.getY() + offset, parent.parent.getX() + (parent.parent.getWidth() * 1), parent.parent.getY() + offset + 12, this.hovered ? ClickGuiModule.hovered.getColor().getRGB() : ClickGuiModule.background.getColor().getRGB());
		Gui.drawRect(parent.parent.getX(), parent.parent.getY() + offset, parent.parent.getX() + 2, parent.parent.getY() + offset + 12, ClickGuiModule.background.getColor().getRGB());
		GL11.glPushMatrix();
		GL11.glScalef(0.5f,0.5f, 0.5f);
		// Minecraft.getMinecraft().fontRenderer.drawStringWithShadow("Mode: " + mod.getMode(), (parent.parent.getX() + 7) * 2, (parent.parent.getY() + offset + 2) * 2 + 5, -1);
		FontManager.drawStringWithShadow("Mode: " + mod.getMode(), (parent.parent.getX() + 7) * 2, (parent.parent.getY() + offset + 2) * 2 + 5, -1);
		GL11.glPopMatrix();
	}

	@Override
	public int getHeight() {
		return 12;
	}
	
	@Override
	public void updateComponent(int mouseX, int mouseY) {
		this.hovered = isMouseOnButton(mouseX, mouseY);
		this.y = parent.parent.getY() + offset;
		this.x = parent.parent.getX();
	}
	
	@Override
	public void mouseClicked(int mouseX, int mouseY, int button) {
		if(isMouseOnButton(mouseX, mouseY) && button == 0 && this.parent.open) {
			mod.cycle();
		}
	}
	
	public boolean isMouseOnButton(int x, int y) {
		if(x > this.x && x < this.x + 88 && y > this.y && y < this.y + 12) {
			return true;
		}
		return false;
	}
}
