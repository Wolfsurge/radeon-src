package cf.radeon.clickgui.component.components.sub;

import cf.radeon.animation.Animate;
import cf.radeon.animation.Easing;
import cf.radeon.clickgui.component.Component;
import cf.radeon.clickgui.component.components.Button;
import cf.radeon.managers.FontManager;
import cf.radeon.module.modules.client.ClickGuiModule;
import cf.radeon.module.modules.client.Colours;
import cf.radeon.module.settings.BooleanSetting;
import cf.radeon.utils.render.ColorUtil;
import cf.radeon.utils.render.RenderUtils2D;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.opengl.GL11;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;

import static org.lwjgl.opengl.GL11.*;

public class BooleanComponent extends Component {

	private boolean hovered;
	private BooleanSetting op;
	private Button parent;
	private int offset;
	private int x;
	private int y;

	public Animate animate = new Animate();

	public BooleanComponent(BooleanSetting option, Button button, int offset) {
		this.op = option;
		this.parent = button;
		this.x = button.parent.getX() + button.parent.getWidth();
		this.y = button.parent.getY() + button.offset;
		this.offset = offset;

		animate.setMin(0).setMax(100).setSpeed(10).setEase(Easing.LINEAR).setReversed(!op.isEnabled());
	}

	@Override
	public void renderComponent(int mouseX, int mouseY) {
		animate.update();

		Gui.drawRect(parent.parent.getX() + 2, parent.parent.getY() + offset, parent.parent.getX() + parent.parent.getWidth(), parent.parent.getY() + offset + 12, this.hovered ? ClickGuiModule.hovered.getColor().getRGB() : ClickGuiModule.background.getColor().getRGB());
		Gui.drawRect(parent.parent.getX(), parent.parent.getY() + offset, parent.parent.getX() + 2, parent.parent.getY() + offset + 12, ClickGuiModule.background.getColor().getRGB());

		glPushMatrix();
		GL11.glScalef(0.5f,0.5f, 0.5f);
		FontManager.drawStringWithShadow(this.op.getName(), (parent.parent.getX() + 7) * 2, (parent.parent.getY() + offset + 2) * 2 + 4, op.isEnabled() ? ClickGuiModule.rainbow.isEnabled() ? ColorUtil.rainbowWave(4, 1, 1, parent.index * 150) : ClickGuiModule.enabledText.getColor().getRGB() : 0x999999);
		GL11.glPopMatrix();
	}

	@Override
	public int getHeight() {
		return 12;
	}

	@Override
	public void setOff(int newOff) {
		offset = newOff;
	}
	
	@Override
	public void updateComponent(int mouseX, int mouseY) {
		this.hovered = isMouseOnButton(mouseX, mouseY);
		this.y = parent.parent.getY() + offset;
		this.x = parent.parent.getX();
	}
	
	@Override
	public void mouseClicked(int mouseX, int mouseY, int button) {
		if(isMouseOnButton(mouseX, mouseY) && button == 0 && this.parent.open) {
			this.op.toggle();
			animate.setReversed(!animate.isReversed());
		}
	}
	
	public boolean isMouseOnButton(int x, int y) {
		if(x > this.x && x < this.x + 88 && y > this.y && y < this.y + 12) {
			return true;
		}
		return false;
	}
}
