package cf.radeon.clickgui.component;

import java.util.ArrayList;

import cf.radeon.Radeon;
import cf.radeon.animation.Animate;
import cf.radeon.animation.Easing;
import cf.radeon.clickgui.ClickGui;
import cf.radeon.clickgui.component.components.Button;
import cf.radeon.gui.GuiUtil;
import cf.radeon.managers.FontManager;
import cf.radeon.module.Category;
import cf.radeon.module.Module;
import cf.radeon.module.modules.client.ClickGuiModule;
import cf.radeon.module.modules.client.Colours;
import cf.radeon.utils.render.ColorUtil;
import cf.radeon.utils.render.DisplayUtils;
import cf.radeon.utils.render.RenderUtils2D;
import net.minecraft.client.Minecraft;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.opengl.GL11;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.Gui;

import static org.lwjgl.opengl.GL11.*;

public class Frame {

	public ArrayList<Component> components;
	public Category category;
	private boolean open;
	private int width;
	private int y;
	private int x;
	private int barHeight;
	private boolean isDragging;
	public int dragX;
	public int dragY;

	public int len = 0;
	public Animate animation = new Animate();
	public Animate frameArrow = new Animate();

	public Frame(Category cat) {
		this.components = new ArrayList<>();
		this.category = cat;
		this.width = 88;
		this.x = 5;
		this.y = 5;
		this.barHeight = 15;
		this.dragX = 0;
		this.open = false;
		this.isDragging = false;
		int tY = this.barHeight;

		int index = 1;
		for(Module mod : Radeon.moduleManager.getModulesInCategory(category)) {
			Button modButton = new Button(mod, this, tY / 12, tY);
			this.components.add(modButton);
			tY += 12;
			index++;
		}

		len = components.size() * 12;
		animation.setMin(0).setMax((components.size()) * 12).setSpeed(300).setEase(Easing.CUBIC_IN_OUT).setReversed(false);
		frameArrow.setMin(0).setMax(90).setSpeed(300).setEase(Easing.CUBIC_IN_OUT).setReversed(!animation.isReversed());
	}
	
	public ArrayList<Component> getComponents() {
		return components;
	}
	
	public void setX(int newX) {
		this.x = newX;
	}
	
	public void setY(int newY) {
		this.y = newY;
	}

	public int getBarHeight() {
		return barHeight;
	}

	public void setDrag(boolean drag) {
		this.isDragging = drag;
	}
	
	public boolean isOpen() {
		return open;
	}
	
	public void setOpen(boolean open) {
		this.open = open;
	}
	
	public void renderFrame(FontRenderer fontRenderer, int mouseX, int mouseY) {
		animation.update();
		frameArrow.update();

		limit();

		len = 0;
		for(Component c : components)
			len += c.getHeight();

		animation.setMax(len);

		Gui.drawRect(this.x, this.y, this.x + this.width, this.y + this.barHeight, ClickGuiModule.header.getColor().getRGB());

		FontManager.drawStringWithShadow(this.category.name, (this.x + 3), (this.y + 3.5f), 0xFFFFFFFF);

		if(GuiUtil.mouseOver(getX() + getWidth() - 15, getY(), getX() + getWidth(), getY() + 15, mouseX, mouseY))
			RenderUtils2D.drawRect(getX() + getWidth() - 15, getY(), getX() + getWidth(), getY() + 15, 0x70000000);

		if(ClickGuiModule.rainbow.isEnabled())
			RenderUtils2D.drawGradientRect(this.x, this.y + (this.barHeight - 1), this.x + this.width, this.y + this.barHeight, ColorUtil.rainbowWave(4, 1, 1, 0), ColorUtil.rainbowWave(4, 1, 1, 150), false);

		glPushMatrix();
		glColor3f(255, 255, 255);
		Minecraft.getMinecraft().getTextureManager().bindTexture(new ResourceLocation("radeon", "textures/line.png"));
		RenderUtils2D.drawModalRectWithCustomSizedTexture((getX() + getWidth() - 12), (getY() + 3), 0, 0, 9, 9, 9, 9);
		glTranslatef(((getX() + getWidth() - 12) + 4.5f), (getY() + 3) + 4.5f, 0);
		glRotated(frameArrow.getValue(), 0, 0, 1);
		glTranslatef(-(((getX() + getWidth() - 12) + 4.5f)), -((getY() + 3) + 4.5f), 0);
		RenderUtils2D.drawModalRectWithCustomSizedTexture((getX() + getWidth() - 12), (getY() + 3), 0, 0, 9, 9, 9, 9);
		glPopMatrix();

		if(!this.components.isEmpty()) {
			if(animation.getValue() < animation.getMax()) {
				glPushMatrix();
				glPushAttrib(GL11.GL_SCISSOR_BIT);
				{
					RenderUtils2D.scissor(x, y + this.barHeight - 1, 88, animation.getValue());
					glEnable(GL_SCISSOR_TEST);
				}
			}
			for(Component component : components) {
				component.renderComponent(mouseX, mouseY);
			}
			if(animation.getValue() < animation.getMax()) {
				glDisable(GL_SCISSOR_TEST);
				glPopAttrib();
				glPopMatrix();
			}
		}
	}

	public void limit() {
		if(ClickGuiModule.limit.isEnabled()) {
			if(x < 0)
				x = 0;
			if(y + 13 > DisplayUtils.getDisplayHeight())
				y = DisplayUtils.getDisplayHeight() - 13;
			if(x + 88 > DisplayUtils.getDisplayWidth())
				x = DisplayUtils.getDisplayWidth() - 88;
		}
	}
	
	public void refresh() {
		int off = this.barHeight;
		for(Component comp : components) {
			comp.setOff(off);
			off += comp.getHeight();
		}
	}
	
	public int getX() {
		return x;
	}
	
	public int getY() {
		return y;
	}
	
	public int getWidth() {
		return width;
	}
	
	public void updatePosition(int mouseX, int mouseY) {
		if(this.isDragging) {
			this.setX(mouseX - dragX);
			this.setY(mouseY - dragY);
		}
	}
	
	public boolean isWithinHeader(int x, int y) {
		if(x >= this.x && x <= this.x + this.width && y >= this.y && y <= this.y + this.barHeight) {
			return true;
		}
		return false;
	}
	
}
