package cf.radeon.clickgui.component.components.sub;

import cf.radeon.clickgui.component.Component;
import cf.radeon.clickgui.component.components.Button;
import cf.radeon.managers.FontManager;
import cf.radeon.module.modules.client.ClickGuiModule;
import cf.radeon.module.modules.client.Colours;
import cf.radeon.module.settings.ColourPicker;
import cf.radeon.utils.render.Colour;
import cf.radeon.utils.render.RenderUtils2D;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.GL11;

import java.awt.Color;

import static org.lwjgl.opengl.GL11.*;

public class ColourComponent extends Component {

    public boolean open;
    private boolean hovered;
    private ColourPicker op;
    private Button parent;
    public double offset;
    private int x;
    private double y;

    private Color finalColor;
    boolean pickingColor = false;
    boolean pickingHue = false;
    boolean pickingAlpha = false;

    public ColourComponent(ColourPicker setting, Button button, double offset) {
        this.op = setting;
        this.parent = button;
        this.x = button.parent.getX() + button.parent.getWidth();
        this.y = button.parent.getY() + button.offset;
        this.offset = offset;

        float[] hsbColor = Color.RGBtoHSB(setting.getValue().getRed(), setting.getValue().getGreen(), setting.getValue().getBlue(), null);
    }

    @Override
    public void renderComponent(int mouseX, int mouseY) {
        RenderUtils2D.drawRect(parent.parent.getX() + 2, parent.parent.getY() + offset, parent.parent.getX() + parent.parent.getWidth(), parent.parent.getY() + offset + 12, this.hovered ? ClickGuiModule.hovered.getColor().getRGB() : ClickGuiModule.background.getColor().getRGB());
        RenderUtils2D.drawRect(parent.parent.getX(), parent.parent.getY() + offset, parent.parent.getX() + 2, parent.parent.getY() + offset + 12 + (open ? 12 * 7 : 0), ClickGuiModule.background.getColor().getRGB());
        RenderUtils2D.drawRect(parent.parent.getX() + 2, parent.parent.getY() + offset + 12, parent.parent.getX() + parent.parent.getWidth(), parent.parent.getY() + offset + getHeight(), this.hovered ? ClickGuiModule.hovered.getColor().getRGB() : ClickGuiModule.background.getColor().getRGB());

        if(open) {
            drawPicker(op,
                    (parent.parent.getX() + 4), (parent.parent.getY() + offset + 12),
                    (parent.parent.getX() + 4), parent.parent.getY() + offset + 63,
                    (parent.parent.getX() + 4), parent.parent.getY() + offset + 75, mouseX, mouseY);
            glPushMatrix();
            glScaled(0.5, 0.5, 0.5);
            FontManager.drawStringWithShadow("Rainbow", (parent.parent.getX() + 7) * 2, (float) (parent.parent.getY() + offset + 12 * 7 + 5) * 2, op.getRainbow() ? new Color(op.getColor().getRed(), op.getColor().getGreen(), op.getColor().getBlue(), 255).getRGB() : -1);
            glPopMatrix();

            RenderUtils2D.drawRect(parent.parent.getX() + 3, parent.parent.getY() + offset + 12, parent.parent.getX() + 4, parent.parent.getY() + offset + 12 * 8, ClickGuiModule.header.getColor().getRGB());
        }

        GL11.glPushMatrix();
        GL11.glScaled(0.5, 0.5, 0.5);
        FontManager.drawStringWithShadow(op.getName(), (parent.parent.getX() + 7) * 2, (float) ((parent.parent.getY() + offset + 2) * 2 + 4), -1);
        GL11.glPopMatrix();

        RenderUtils2D.drawRect(parent.parent.getX() + parent.parent.getWidth() - 15, parent.parent.getY() + offset + 1, parent.parent.getX() + parent.parent.getWidth() - 5, parent.parent.getY() + offset + 11, new Color(op.getColor().getRed(), op.getColor().getGreen(), op.getColor().getBlue(), 255).getRGB());
    }

    @Override
    public void mouseClicked(int mouseX, int mouseY, int button) {
        if(isMouseOnButton(mouseX, mouseY) && button == 1 && this.parent.open) {
            for (Component comp : parent.parent.getComponents()) {
                if (comp instanceof Button) {
                    if (((Button) comp).open) {
                        for (Component comp2 : ((Button) comp).subcomponents) {
                            if (comp2 instanceof ColourComponent) {
                                if (((ColourComponent) comp2).open && comp2 != this) {
                                    this.parent.parent.refresh();
                                }
                            }
                        }
                    }
                }
            }
            open = (!open);
            this.parent.parent.refresh();
        }

        if(open)
            doRainbow(mouseX, mouseY, button);
    }

    @Override
    public void setOff(int newOff) {
        offset = newOff;
    }

    @Override
    public int getHeight() {
        return (open ? 12 * 8 : 12);
    }

    @Override
    public void updateComponent(int mouseX, int mouseY) {
        this.hovered = isMouseOnButton(mouseX, mouseY);
        this.y = parent.parent.getY() + offset;
        this.x = parent.parent.getX();
    }

    @Override
    public void mouseReleased(int mouseX, int mouseY, int mouseButton) {
        pickingColor = false;
        pickingHue = false;
        pickingAlpha = false;
    }

    public boolean mouseOver(double minX, double minY, double maxX, double maxY, int mX, int mY) {
        return mX >= minX && mY >= minY && mX <= maxX && mY <= maxY;
    }

    public boolean isMouseOnButton(double x, double y) {
        if(x > this.x && x < this.x + 88 && y > this.y && y < this.y + 12 + (open ? 12 * 7 : 0)) {
            return true;
        }
        return false;
    }

    /*
    * @author WP3
     */
    public void drawPicker(ColourPicker subColor, double pickerX, double pickerY, double hueSliderX, double hueSliderY, double alphaSliderX, double alphaSliderY, int mouseX, int mouseY) {
        float[] color = new float[] {
                0, 0, 0, 0
        };

        try {
            color = new float[] {Color.RGBtoHSB(subColor.getColor().getRed(), subColor.getColor().getGreen(), subColor.getColor().getBlue(), null)[0], Color.RGBtoHSB(subColor.getColor().getRed(), subColor.getColor().getGreen(), subColor.getColor().getBlue(), null)[1], Color.RGBtoHSB(subColor.getColor().getRed(), subColor.getColor().getGreen(), subColor.getColor().getBlue(), null)[2], subColor.getColor().getAlpha() / 255f};
        } catch (Exception ignored) {}

        float pickerWidth = 83;
        float pickerHeight = 50;
        float hueSliderWidth = 83;
        float hueSliderHeight = 11;
        float alphaSliderWidth = 83;
        float alphaSliderHeight = 11;

        if (!pickingColor && !pickingHue && !pickingAlpha) {
            if (Mouse.isButtonDown(0) && mouseOver(pickerX, pickerY, pickerX + pickerWidth, pickerY + pickerHeight, mouseX, mouseY)) {
                pickingColor = true;
            } else if (Mouse.isButtonDown(0) && mouseOver(hueSliderX, hueSliderY, hueSliderX + hueSliderWidth, hueSliderY + hueSliderHeight, mouseX, mouseY)) {
                pickingHue = true;
            } else if (Mouse.isButtonDown(0) && mouseOver(alphaSliderX, alphaSliderY, alphaSliderX + alphaSliderWidth, alphaSliderY + alphaSliderHeight, mouseX, mouseY))
                pickingAlpha = true;
        }

        if (pickingHue) {
            float restrictedY = (float) Math.min(Math.max(hueSliderX, mouseX), hueSliderX + hueSliderWidth);
            color[0] = (restrictedY - (float) hueSliderX) / hueSliderWidth;
            color[0] = Math.min(1, color[0]);
        }

        if (pickingAlpha) {
            float restrictedX = (float) Math.min(Math.max(alphaSliderX, mouseX), alphaSliderX + alphaSliderWidth);
            color[3] = 1 - (restrictedX - (float) alphaSliderX) / alphaSliderWidth;
        }

        if (pickingColor) {
            float restrictedX = (float) Math.min(Math.max(pickerX, mouseX), pickerX + pickerWidth);
            float restrictedY = (float) Math.min(Math.max(pickerY, mouseY), pickerY + pickerHeight);
            color[1] = (restrictedX - (float) pickerX) / pickerWidth;
            color[2] = 1 - (restrictedY - (float) pickerY) / pickerHeight;
            color[2] = (float) Math.max(0.04000002, color[2]);
            color[1] = (float) Math.max(0.022222223, color[1]);
        }

        int selectedColor = Color.HSBtoRGB(color[0], 1.0f, 1.0f);

        float selectedRed = (selectedColor >> 16 & 0xFF) / 255.0f;
        float selectedGreen = (selectedColor >> 8 & 0xFF) / 255.0f;
        float selectedBlue = (selectedColor & 0xFF) / 255.0f;

        RenderUtils2D.drawPickerBase(pickerX, pickerY, pickerWidth, pickerHeight, selectedRed, selectedGreen, selectedBlue, 255);

        drawHueSlider(hueSliderX, hueSliderY, hueSliderWidth, hueSliderHeight, color[0]);

        int cursorX = (int) (pickerX + color[1] * pickerWidth);
        int cursorY = (int) ((pickerY + pickerHeight) - color[2] * pickerHeight);

        RenderUtils2D.drawRectMC(cursorX - 2, cursorY - 2, cursorX + 2, cursorY + 2, Colours.colourInt);

        finalColor = alphaIntegrate(new Color(Color.HSBtoRGB(color[0], color[1], color[2])), color[3]);

        drawAlphaSlider(alphaSliderX, alphaSliderY, alphaSliderWidth, alphaSliderHeight, finalColor.getRed() / 255f, finalColor.getGreen() / 255f, finalColor.getBlue() / 255f, color[3]);

        this.op.setValue(new Colour(finalColor));
    }

    public static Color alphaIntegrate(Color color, float alpha) {
        float red = (float) color.getRed() / 255;
        float green = (float) color.getGreen() / 255;
        float blue = (float) color.getBlue() / 255;
        return new Color(red, green, blue, alpha);
    }

    public void drawHueSlider(double x, double y, double width, double height, float hue) {
        int step = 0;
        if (height > width) {
            RenderUtils2D.drawRect(x, y, x + width, y + 4, 0xFFFF0000);
            y += 4;

            for (int colorIndex = 0; colorIndex < 6; colorIndex++) {
                int previousStep = Color.HSBtoRGB((float) step / 6, 1.0f, 1.0f);
                int nextStep = Color.HSBtoRGB((float) (step + 1) / 6, 1.0f, 1.0f);
                RenderUtils2D.drawGradientRect(x, y + step * (height / 6f), x + width, y + (step + 1) * (height / 6f), previousStep, nextStep, false);
                step++;
            }
            int sliderMinY = (int) (y + height*hue) - 4;
            RenderUtils2D.drawRect(x, sliderMinY - 1, x + width, sliderMinY + 1,-1);
        } else {
            for (int colorIndex = 0; colorIndex < 6; colorIndex++) {
                int previousStep = Color.HSBtoRGB((float) step / 6, 1.0f, 1.0f);
                int nextStep = Color.HSBtoRGB((float) (step + 1) / 6, 1.0f, 1.0f);
                RenderUtils2D.gradient(x + step * (width / 6), y, x + (step + 1) * (width / 6), y + height, previousStep, nextStep, true);
                step++;
            }

            int sliderMinX = (int) (x + (width * hue));
            RenderUtils2D.drawRect(sliderMinX - 0.5, y, sliderMinX + 0.5, y + height, -1);
        }
    }

    public void drawAlphaSlider(double x, double y, float width, float height, float red, float green, float blue, float alpha) {
        boolean left = true;
        float checkerBoardSquareSize = height / 2;

        for (float squareIndex = -checkerBoardSquareSize; squareIndex < width; squareIndex += checkerBoardSquareSize) {
            if (!left) {
                RenderUtils2D.drawRect(x + squareIndex, y, x + squareIndex + checkerBoardSquareSize, y + height, 0xFFFFFFFF);
                RenderUtils2D.drawRect(x + squareIndex, y + checkerBoardSquareSize, x + squareIndex + checkerBoardSquareSize, y + height, 0xFF909090);

                if (squareIndex < width - checkerBoardSquareSize) {
                    double minX = x + squareIndex + checkerBoardSquareSize;
                    double maxX = Math.min(x + width, x + squareIndex + checkerBoardSquareSize * 2);
                    RenderUtils2D.drawRect(minX, y, maxX, y + height, 0xFF909090);
                    RenderUtils2D.drawRect(minX, y + checkerBoardSquareSize, maxX, y + height,0xFFFFFFFF);
                }
            }

            left = !left;
        }

        RenderUtils2D.drawLeftGradientRect(x, y, x + width, y + height, new Color(red, green, blue, 1).getRGB(), 0);
        int sliderMinX = (int) (x + width - (width * alpha));
        RenderUtils2D.drawRect(sliderMinX - 0.5, y, sliderMinX + 0.5, y + height, -1);
    }

    public void doRainbow(int mouseX, int mouseY, int mouseButton) {
        if(this.open && mouseButton == 0 && mouseOver((parent.parent.getX()), parent.parent.getY() + offset + 12 * 7 + 3, (parent.parent.getX() + parent.parent.getWidth()), parent.parent.getY() + offset + 12 * 7 + 10, mouseX, mouseY)) {
            this.op.setRainbow(!this.op.getRainbow());
        }
    }
}
