package cf.radeon.clickgui;

import java.io.IOException;
import java.util.ArrayList;

import cf.radeon.Radeon;
import cf.radeon.clickgui.component.Component;
import cf.radeon.clickgui.component.Frame;
import cf.radeon.clickgui.component.components.Button;
import cf.radeon.clickgui.component.components.sub.SliderComponent;
import cf.radeon.gui.GuiUtil;
import cf.radeon.module.Category;
import cf.radeon.module.Module;
import cf.radeon.module.modules.client.ClickGuiModule;
import cf.radeon.utils.render.RenderUtils2D;
import me.wolfsurge.api.TextUtil;
import net.minecraft.client.gui.GuiScreen;
import org.lwjgl.input.Mouse;

import static org.lwjgl.opengl.GL11.*;

public class ClickGui extends GuiScreen {

	public static ArrayList<Frame> frames;
	public static int color = -1;
	
	public ClickGui() {
		frames = new ArrayList<>();
		int frameX = 5;
		for(Category category : Category.values()) {
			Frame frame = new Frame(category);
			try {
				frame.setX(Radeon.config.clickGUIConfig.getInt(frame.category.name() + "X"));
				frame.setY(Radeon.config.clickGUIConfig.getInt(frame.category.name() + "Y"));
				frame.animation.setReversed(!Radeon.config.clickGUIConfig.getBoolean(frame.category.name() + "_EXPANDED"));
				frame.frameArrow.setReversed(!frame.animation.isReversed());
			} catch (NullPointerException e) {
				frame.setX(frameX);
				frame.setY(20);
				frame.animation.setReversed(false);
			}
			frames.add(frame);
			frameX += frame.getWidth() + 1;
		}
	}

	public void reset() {
		int frameX = 5;
		for(Frame f : frames) {
			f.setX(frameX);
			f.setY(20);
			frameX += 90;
		}
	}

	@Override
	public void drawScreen(int mouseX, int mouseY, float partialTicks) {
		glPushMatrix();
		if(ClickGuiModule.darken.isEnabled()) this.drawDefaultBackground();

		boolean doRenderText = false;
		String renderText = "";

		for(Frame frame : frames) {
			frame.renderFrame(this.fontRenderer, mouseX, mouseY);
			frame.updatePosition(mouseX, mouseY);
			for(Component comp : frame.getComponents()) {
				comp.updateComponent(mouseX, mouseY);
				if(comp instanceof Button && GuiUtil.mouseOver(frame.getX(), frame.getY() + ((Button) comp).offset, frame.getX() + frame.getWidth(), frame.getY() + ((Button) comp).offset + 10, mouseX, mouseY)) {
					renderText = ((Button) comp).mod.description;
					doRenderText = frame.animation.getValue() == frame.animation.getMax();
				}
			}
		}

		if(doRenderText) {
			RenderUtils2D.drawBorderedRect(mouseX + 5, mouseY - 15, mouseX + 5 + TextUtil.getStringWidth(renderText) + 4, mouseY - 1, 1, ClickGuiModule.background.getColor().getRGB(), ClickGuiModule.header.getColor().getRGB(), false);
			glPushMatrix();
			TextUtil.drawStringWithShadow(renderText, (mouseX + 7), (mouseY - 14), -1);
			glPopMatrix();
		}

		// scrolling
		int dWheel = Mouse.getDWheel();
		if (dWheel < 0) {
			for (Frame f : frames) {
				f.setY((f.getY() + (13 / 2)));
			}
		} else if (dWheel > 0) {
			for (Frame f : frames) {
				f.setY((f.getY() - (13 / 2)));
			}
		}

		GuiUtil.renderButtons(mouseX, mouseY);
		glPopMatrix();
	}
	
	@Override
    protected void mouseClicked(final int mouseX, final int mouseY, final int mouseButton) throws IOException {
		for(Frame frame : frames) {
			if(GuiUtil.mouseOver(frame.getX() + frame.getWidth() - 13, frame.getY(), frame.getX() + frame.getWidth(), frame.getY() + 15, mouseX, mouseY) || frame.isWithinHeader(mouseX, mouseY) && mouseButton == 1) {
				frame.animation.setMax(frame.len);
				frame.animation.setReversed(!frame.animation.isReversed());
				frame.frameArrow.setReversed(!frame.frameArrow.isReversed());
			} else if(frame.isWithinHeader(mouseX, mouseY) && mouseButton == 0) {
				frame.setDrag(true);
				frame.dragX = mouseX - frame.getX();
				frame.dragY = mouseY - frame.getY();
			}

			if(!frame.getComponents().isEmpty() && frame.animation.getValue() == frame.animation.getMax()) { // frame.animation.getValue() == frame.animation.getMax()
				for(Component component : frame.getComponents()) {
					component.mouseClicked(mouseX, mouseY, mouseButton);
				}
			}
		}

		if(mouseButton == 0 || mouseButton == 1) {
			GuiUtil.handleButtons(mouseX, mouseY);
		}
	}

	@Override
	public void onGuiClosed() {
		Radeon.config.saveClickGUIConfig();
		for(Module m : Radeon.moduleManager.getModules())
			Radeon.config.saveModConfig(m);
	}

	@Override
	protected void keyTyped(char typedChar, int keyCode) {
		for(Frame frame : frames) {
			if(frame.animation.getValue() == frame.animation.getMax() && keyCode != 1) {
				for(Component component : frame.getComponents()) {
					component.keyTyped(typedChar, keyCode);
				}
			}
		}
		if (keyCode == 1) {
            this.mc.displayGuiScreen(null);
        }
	}

	@Override
    protected void mouseReleased(int mouseX, int mouseY, int state) {
		for(Frame frame : frames) {
			frame.setDrag(false);
		}
		for(Frame frame : frames) {
			if(!frame.getComponents().isEmpty()) {
				for(Component component : frame.getComponents()) {
					component.mouseReleased(mouseX, mouseY, state);

					if(component instanceof SliderComponent)
						((SliderComponent) component).dragging = false;
				}
			}
		}
	}
	
	@Override
	public boolean doesGuiPauseGame() {
		return false;
	}
}
