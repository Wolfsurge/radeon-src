package cf.radeon.event.impl;

import cf.radeon.event.Event;

public class CameraClipEvent extends Event {}