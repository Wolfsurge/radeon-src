package cf.radeon.event.impl;

import cf.radeon.event.Event;
import net.minecraft.entity.Entity;

/**
 * @author olliem5
 */

public final class TotemPopEvent extends Event {
    public final Entity entity;

    public TotemPopEvent(Entity entity) {
        this.entity = entity;
    }

    public Entity getEntity() {
        return entity;
    }
}