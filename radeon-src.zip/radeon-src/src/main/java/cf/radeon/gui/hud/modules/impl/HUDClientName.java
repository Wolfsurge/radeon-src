package cf.radeon.gui.hud.modules.impl;

import cf.radeon.Radeon;
import cf.radeon.gui.hud.modules.HUDMod;
import cf.radeon.module.modules.client.Colours;
import cf.radeon.module.modules.hud.ClientName;
import cf.radeon.utils.render.RenderUtils2D;
import me.wolfsurge.api.TextUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.opengl.GL11;

public class HUDClientName extends HUDMod {

	public HUDClientName() {
		super("Client Name", 0, 0, Radeon.moduleManager.getModule("ClientName"));
	}	

	@Override
	public void draw() {
		if(ClientName.mode.is("Image")) {
			GL11.glPushMatrix();
			GL11.glColor3f(255, 255, 255); // reset colour
			ResourceLocation rl = new ResourceLocation("radeon", "textures/logo.png");
			Minecraft.getMinecraft().getTextureManager().bindTexture(rl);
			RenderUtils2D.drawModalRectWithCustomSizedTexture(getX(), getY(), 0, 0, 245 / 4, 140 / 4, 245 / 4, 140 / 4);
			GL11.glPopMatrix();
		} else if(ClientName.mode.is("Text")) {
			TextUtil.drawStringWithShadow(Radeon.NAME + " " + Radeon.VERSION, getX(), getY(), Colours.colourInt);
		}

		super.draw();
	}
	
	@Override
	public void renderDummy(int mouseX, int mouseY) {	
		super.renderDummy(mouseX, mouseY);
		
		drag.setHeight(getHeight());
		drag.setWidth(getWidth());

		if(ClientName.mode.is("Image")) {
			GL11.glPushMatrix();
			GL11.glClearColor(0, 0, 0, 255);
			ResourceLocation rl = new ResourceLocation("radeon", "textures/logo.png");
			Minecraft.getMinecraft().getTextureManager().bindTexture(rl);
			RenderUtils2D.drawModalRectWithCustomSizedTexture(getX(), getY(), 0, 0, 245 / 4, 140 / 4, 245 / 4, 140 / 4);
			GL11.glPopMatrix();
		} else if(ClientName.mode.is("Text")) {
			TextUtil.drawStringWithShadow(Radeon.NAME + " " + Radeon.VERSION, getX(), getY(), Colours.colourInt);
		}
	}
	
	@Override
	public int getWidth() {
		return ClientName.mode.is("Image") ? 245 / 4 : TextUtil.getStringWidth(Radeon.NAME + " " + Radeon.VERSION);
	}
	
	@Override
	public float getHeight() {
		return ClientName.mode.is("Image") ? 140 / 4 : 11;
	}
	
}
