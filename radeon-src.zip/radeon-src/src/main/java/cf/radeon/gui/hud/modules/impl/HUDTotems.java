package cf.radeon.gui.hud.modules.impl;

import cf.radeon.Radeon;
import cf.radeon.gui.hud.modules.HUDMod;
import cf.radeon.module.modules.client.Colours;
import me.wolfsurge.api.TextUtil;
import net.minecraft.init.Items;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.ItemStack;
import net.minecraft.util.NonNullList;

public class HUDTotems extends HUDMod {

	public HUDTotems() {
		super("Totems", 0, 185, Radeon.moduleManager.getModule("Totems"));
	}	

	public int getTotems() {
		if(nullCheck())
			return 0;

		NonNullList<ItemStack> inv;
		ItemStack offhand = mc.player.getItemStackFromSlot(EntityEquipmentSlot.OFFHAND);

		int inventoryIndex;

		inv = mc.player.inventory.mainInventory;

		int totems = 0;

		for(inventoryIndex = 0; inventoryIndex < inv.size(); inventoryIndex++) {
			if(inv.get(inventoryIndex).getItem() == Items.TOTEM_OF_UNDYING) {
				totems++;
			}
		}

		if(offhand.getItem() == Items.TOTEM_OF_UNDYING) {
			totems++;
		}

		return totems;
	}

	@Override
	public void draw() {
		TextUtil.drawStringWithShadow("Totems: " + getTotems(), getX() + 1, getY(), Colours.colourInt);
		
		super.draw();
	}
	
	@Override
	public void renderDummy(int mouseX, int mouseY) {	
		super.renderDummy(mouseX, mouseY);
		
		drag.setHeight(getHeight());
		drag.setWidth(getWidth());
		
		TextUtil.drawStringWithShadow("Totems: " + getTotems(), getX() + 1, getY(), this.parent.enabled ? Colours.colourInt : 0xFF900000);
	}
	
	@Override
	public int getWidth() {
		return TextUtil.getStringWidth("Totems: " + getTotems());
	}
	
	@Override
	public float getHeight() {
		return 11;
	}
	
}
