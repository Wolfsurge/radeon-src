package cf.radeon.gui.mainmenu;

import cf.radeon.Radeon;
import cf.radeon.managers.FontManager;
import cf.radeon.utils.render.RenderUtils2D;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.text.TextFormatting;
import org.lwjgl.opengl.GL11;

public class MainMenuHook {
	
	public static void render(int mouseX, int mouseY) {
		Radeon.discordManager.update("In Main Menu");

		ResourceLocation rl = new ResourceLocation("radeon", "textures/logo.png");
		Minecraft.getMinecraft().getTextureManager().bindTexture(rl);

		GL11.glPushMatrix();
		GL11.glScaled(0.35, 0.35, 0);
		RenderUtils2D.drawModalRectWithCustomSizedTexture(0, 0, 0, 0, 350, 200, 350, 200);
		GL11.glPopMatrix();
	}
}
