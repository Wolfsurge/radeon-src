package cf.radeon.gui.hud.modules.impl;

import cf.radeon.Radeon;
import cf.radeon.gui.hud.modules.HUDMod;
import cf.radeon.module.modules.client.Colours;
import me.wolfsurge.api.TextUtil;
import net.minecraft.util.text.TextFormatting;

public class HUDCoords extends HUDMod {

	public HUDCoords() {
		super("Coordinates", 0, 30, Radeon.moduleManager.getModule("Coordinates"));
	}	

	@Override
	public void draw() {
		TextUtil.drawStringWithShadow("XYZ " + TextFormatting.WHITE + mc.player.getPosition().x + " " + mc.player.getPosition().y + " " + mc.player.getPosition().z, getX() + 1, getY(), Colours.colourInt);
		
		super.draw();
	}
	
	@Override
	public void renderDummy(int mouseX, int mouseY) {	
		super.renderDummy(mouseX, mouseY);
		drag.setHeight(getHeight());
		drag.setWidth(getWidth());
		
		TextUtil.drawStringWithShadow("XYZ " + TextFormatting.WHITE + mc.player.getPosition().x + " " + mc.player.getPosition().y + " " + mc.player.getPosition().z, getX() + 1, getY(), this.parent.enabled ? Colours.colourInt : 0xFF900000);
	}
	
	@Override
	public int getWidth() {
		try {
			return TextUtil.getStringWidth("XYZ " + TextFormatting.WHITE + mc.player.getPosition().x + " " + mc.player.getPosition().y + " " + mc.player.getPosition().z);
		} catch(NullPointerException e) {
			return 0;
		}
	}
	
	@Override
	public float getHeight() {
		return 11;
	}
	
}
