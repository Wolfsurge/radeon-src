package cf.radeon.gui.hud.modules.impl;

import cf.radeon.Radeon;
import cf.radeon.gui.hud.modules.HUDMod;
import cf.radeon.managers.TickManager;
import cf.radeon.module.modules.client.Colours;
import me.wolfsurge.api.TextUtil;

public class HUDTPS extends HUDMod {

	public HUDTPS() {
		super("TPS", 0, 50, Radeon.moduleManager.getModule("TPS"));
	}	

	@Override
	public void draw() {
		TextUtil.drawStringWithShadow("TPS: " + Radeon.tickManager.getTPS(TickManager.TPS.CURRENT), getX() + 1, getY(), Colours.colourInt);
		
		super.draw();
	}
	
	@Override
	public void renderDummy(int mouseX, int mouseY) {	
		super.renderDummy(mouseX, mouseY);
		
		drag.setHeight(getHeight());
		drag.setWidth(getWidth());
		
		TextUtil.drawStringWithShadow("TPS: " + Radeon.tickManager.getTPS(TickManager.TPS.CURRENT), getX() + 1, getY(), this.parent.enabled ? Colours.colourInt : 0xFF900000);
	}
	
	@Override
	public int getWidth() {
		try {
			return TextUtil.getStringWidth("TPS: " + Radeon.tickManager.getTPS(TickManager.TPS.CURRENT));
		} catch (NullPointerException e) {
			return 0;
		}
	}
	
	@Override
	public float getHeight() {
		return 11;
	}
	
}
