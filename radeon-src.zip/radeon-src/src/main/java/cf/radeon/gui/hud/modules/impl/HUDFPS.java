package cf.radeon.gui.hud.modules.impl;

import cf.radeon.Radeon;
import cf.radeon.gui.hud.modules.HUDMod;
import cf.radeon.module.modules.client.Colours;
import me.wolfsurge.api.TextUtil;

public class HUDFPS extends HUDMod {

	public HUDFPS() {
		super("FPS", 0, 20, Radeon.moduleManager.getModule("FPS"));
	}	

	@Override
	public void draw() {
		TextUtil.drawStringWithShadow("FPS: " + mc.getDebugFPS(), getX() + 1, getY(), Colours.colourInt);
		
		super.draw();
	}
	
	@Override
	public void renderDummy(int mouseX, int mouseY) {	
		super.renderDummy(mouseX, mouseY);
		
		drag.setHeight(getHeight());
		drag.setWidth(getWidth());
		
		TextUtil.drawStringWithShadow("FPS: " + mc.getDebugFPS(), getX() + 1, getY(), this.parent.enabled ? Colours.colourInt : 0xFF900000);
	}
	
	@Override
	public int getWidth() {
		return TextUtil.getStringWidth("FPS: " + mc.getDebugFPS());
	}
	
	@Override
	public float getHeight() {
		return 11;
	}
	
}
