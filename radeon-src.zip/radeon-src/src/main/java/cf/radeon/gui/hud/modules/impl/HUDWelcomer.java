package cf.radeon.gui.hud.modules.impl;

import cf.radeon.Radeon;
import cf.radeon.gui.hud.modules.HUDMod;
import cf.radeon.module.modules.client.Colours;
import me.wolfsurge.api.TextUtil;

public class HUDWelcomer extends HUDMod {

	public HUDWelcomer() {
		super("Welcomer", 100, 0, Radeon.moduleManager.getModule("Welcomer"));
	}	

	@Override
	public void draw() {
		TextUtil.drawStringWithShadow("Welcome to Radeon, " + mc.getSession().getUsername() + "!", getX(), getY(), Colours.colourInt);
		
		super.draw();
	}
	
	@Override
	public void renderDummy(int mouseX, int mouseY) {	
		super.renderDummy(mouseX, mouseY);
		
		drag.setHeight(getHeight());
		drag.setWidth(getWidth());
		
		TextUtil.drawStringWithShadow("Welcome to Radeon, " + mc.getSession().getUsername() + "!", getX(), getY(), this.parent.enabled ? Colours.colourInt : 0xFF900000);
	}
	
	@Override
	public int getWidth() {
		return TextUtil.getStringWidth("Welcome to Radeon, " + mc.getSession().getUsername() + "!");
	}
	
	@Override
	public float getHeight() {
		return 11;
	}
	
}
