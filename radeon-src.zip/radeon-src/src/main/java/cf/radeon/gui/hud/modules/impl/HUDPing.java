package cf.radeon.gui.hud.modules.impl;

import cf.radeon.Radeon;
import cf.radeon.gui.hud.modules.HUDMod;
import cf.radeon.module.modules.client.Colours;
import me.wolfsurge.api.TextUtil;

public class HUDPing extends HUDMod {

	public HUDPing() {
		super("Ping", 0, 40, Radeon.moduleManager.getModule("Ping"));
	}	

	@Override
	public void draw() {
		TextUtil.drawStringWithShadow("Ping: " + this.getPing(), getX() + 1, getY(), Colours.colourInt);
		
		super.draw();
	}
	
	@Override
	public void renderDummy(int mouseX, int mouseY) {
		super.renderDummy(mouseX, mouseY);
		
		drag.setHeight(getHeight());
		drag.setWidth(getWidth());
		
		TextUtil.drawStringWithShadow("Ping: " + this.getPing(), getX() + 1, getY(), this.parent.enabled ? Colours.colourInt : 0xFF900000);
	}
	
	private static int getPing() {
        int p = -1;
        
        if (mc.player == null || mc.getConnection() == null || mc.getConnection().getPlayerInfo(mc.player.getName()) == null) {
            p = -1;
        } else {
            p = mc.getConnection().getPlayerInfo(mc.player.getName()).getResponseTime();
        }
        
        return p;
    }
	
	@Override
	public int getWidth() {
		return TextUtil.getStringWidth("Ping: " + this.getPing());
	}
	
	@Override
	public float getHeight() {
		return 11;
	}
	
}
