package cf.radeon.managers;

import cf.radeon.event.Event;
import cf.radeon.event.impl.OnUpdateWalkingPlayerEvent;
import cf.radeon.event.impl.PacketEvent;
import cf.radeon.packet.PlayerPacket;
import cf.radeon.utils.other.CollectionUtil;
import me.wolfsurge.api.util.Globals;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import me.zero.alpine.type.EventPriority;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.util.math.Vec2f;
import net.minecraft.util.math.Vec3d;
import net.minecraftforge.fml.common.gameevent.TickEvent;

import java.util.ArrayList;
import java.util.List;

public enum PlayerPacketManager implements Globals {

    INSTANCE;

    private final List<PlayerPacket> packets = new ArrayList<>();

    private Vec3d prevServerSidePosition = Vec3d.ZERO;
    private Vec3d serverSidePosition = Vec3d.ZERO;

    private Vec2f prevServerSideRotation = Vec2f.ZERO;
    private Vec2f serverSideRotation = Vec2f.ZERO;
    private Vec2f clientSidePitch = Vec2f.ZERO;

    @SuppressWarnings("unused")
    @EventHandler
    private final Listener<OnUpdateWalkingPlayerEvent> onUpdateWalkingPlayerEventListener = new Listener<>(event -> {
        if (event.getEra() != Event.Era.PERI || packets.isEmpty()) return;

        PlayerPacket packet = CollectionUtil.maxOrNull(packets, PlayerPacket::getPriority);

        if (packet != null) {
            event.cancel();
            event.apply(packet);
        }

        packets.clear();
    });

    @SuppressWarnings("unused")
    @EventHandler
    private final Listener<PacketEvent.PostSend> postSendListener = new Listener<>(event -> {
        if (event.isCancelled()) return;

        Packet<?> rawPacket = event.getPacket();
        EntityPlayerSP player = mc.player;

        if (player != null && rawPacket instanceof CPacketPlayer) {
            CPacketPlayer packet = (CPacketPlayer) rawPacket;

            if (packet.moving) {
                serverSidePosition = new Vec3d(packet.x, packet.y, packet.z);
            }

            if (packet.rotating) {
                serverSideRotation = new Vec2f(packet.yaw, packet.pitch);
                player.rotationYawHead = packet.yaw;
            }
        }
    }, EventPriority.LOWEST);

    @SuppressWarnings("unused")
    @EventHandler
    private final Listener<TickEvent.ClientTickEvent> tickEventListener = new Listener<>(event -> {
        if (event.phase != TickEvent.Phase.START) return;

        prevServerSidePosition = serverSidePosition;
        prevServerSideRotation = serverSideRotation;
    });

    public void addPacket(PlayerPacket packet) {
        packets.add(packet);
    }

    public Vec3d getPrevServerSidePosition() {
        return prevServerSidePosition;
    }

    public Vec3d getServerSidePosition() {
        return serverSidePosition;
    }

    public Vec2f getPrevServerSideRotation() {
        return prevServerSideRotation;
    }

    public Vec2f getServerSideRotation() {
        return serverSideRotation;
    }
}
