package cf.radeon.managers;

import cf.radeon.Radeon;
import cf.radeon.module.Category;
import cf.radeon.module.Module;
import cf.radeon.module.modules.client.ClickGuiModule;
import cf.radeon.module.modules.client.Colours;
import cf.radeon.module.modules.client.CustomFont;
import cf.radeon.module.modules.client.Social;
import cf.radeon.module.modules.combat.*;
import cf.radeon.module.modules.exploit.*;
import cf.radeon.module.modules.hud.*;
import cf.radeon.module.modules.misc.*;
import cf.radeon.module.modules.movement.*;
import cf.radeon.module.modules.render.*;
import net.minecraft.client.Minecraft;
import net.minecraftforge.client.event.*;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.*;
import org.lwjgl.input.Keyboard;
import java.util.ArrayList;
import java.util.Collections;

public class ModuleManager {

    public static ArrayList<Module> modules = new ArrayList<>();

    public ModuleManager() {
        modules = new ArrayList<Module>();
        MinecraftForge.EVENT_BUS.register(this);
        init();

        Radeon.logger.info("Initialized Modules");
    }

    public void init() {
    	modules.add(new Aura());
    	modules.add(new Surround());
        modules.add(new AutoCrystal());
        modules.add(new Criticals());
        modules.add(new AutoCrystalRewrite());
        modules.add(new AutoCrystalRewrite2());
        // modules.add(new PistonAura());
        modules.add(new SelfTrap());
        modules.add(new Offhand());
        modules.add(new HoleFill());
        // modules.add(new HoleBot());
        modules.add(new Cevbreaker());
        modules.add(new BowSpam());
        modules.add(new AutoXP());
        modules.add(new AutoWeb());
        modules.add(new AutoTrap());
        modules.add(new AutoGapple());
        modules.add(new AutoCreeper());
        modules.add(new AutoCity());
        modules.add(new AutoArmor());
        modules.add(new AnvilAura());
    	
        modules.add(new ElytraFlight());
        modules.add(new Velocity());
        modules.add(new Step());
        modules.add(new Sprint());
        modules.add(new Speed());
        modules.add(new ReverseStep());
        modules.add(new PhaseFly());
        modules.add(new NoSlow());
        modules.add(new NoRotate());
        modules.add(new NoFall());
        modules.add(new Flight());

        modules.add(new BurrowESP());
        modules.add(new Brightness());
        modules.add(new BlockHighlight());
        modules.add(new Chams());
        modules.add(new CustomFOV());
        modules.add(new CustomWorld());
        modules.add(new ESP());
        modules.add(new HoleESP());
        modules.add(new PositionESP());
        modules.add(new StorageESP());
        modules.add(new Trajectories());
        modules.add(new Tracers());
        modules.add(new Nametags());
        modules.add(new ViewModel());
        modules.add(new NoRender());
        modules.add(new Xray());
        modules.add(new Notifications());

        modules.add(new Blink());
        modules.add(new BuildHeight());
        modules.add(new Burrow());
        modules.add(new BurrowBypass());
        modules.add(new InstantBurrow());
        modules.add(new LiquidInteract());
        modules.add(new NoBreakReset());
        modules.add(new NoComCrasher());
        modules.add(new NoGlitchBlocks());
        modules.add(new PacketMine());
        modules.add(new Portals());
        modules.add(new ServerSploit());
        modules.add(new SpeedMine());
        modules.add(new ThunderHack());
        modules.add(new TimerModule());
        modules.add(new XCarry());

        modules.add(new ClickGuiModule());
        modules.add(new Colours());
        modules.add(new CustomFont());
        modules.add(new Social());

        modules.add(new AntiPacketKick());
        modules.add(new AutoEZ());
        modules.add(new MCF());
        modules.add(new ChatSuffix());
        modules.add(new AutoLog());
        modules.add(new AutoRespawn());
        modules.add(new ChatTweaks());
        modules.add(new FakePlayer());
        modules.add(new FastUse());
        modules.add(new Freecam());
        modules.add(new MiddleClickPearl());
        modules.add(new NoChat());
        modules.add(new Scaffold());
        modules.add(new ChatPrefix());
        modules.add(new EChestFarmer());

        // HUD Shite
        modules.add(new HUD());
        modules.add(new Armour());
        modules.add(new ArrayListModule());
        modules.add(new ClientName());
        modules.add(new Coordinates());
        modules.add(new FPS());
        modules.add(new Inventory());
        modules.add(new Ping());
        modules.add(new Totems());
        modules.add(new TPS());
        modules.add(new Welcomer());

        Collections.shuffle(modules);

        Radeon.config.loadModConfig();
        System.out.println(modules.size());
    }

    public Module getModule(String name) {
		for(Module m : modules) {
			if(m.getName().equalsIgnoreCase(name)) {
				return m;
			}
		}
		
		return null;
	}
    
    public static Module getModuleByName(String name) {
		for(Module m : modules) {
			if(m.getName().equalsIgnoreCase(name)) {
				return m;
			}
		}
		
		return null;
	}
    
    @SubscribeEvent // Checks if module's keybind is pressed, if it is, toggles it.
    public void onKey(InputEvent.KeyInputEvent event) {
        if(Keyboard.getEventKeyState()) {
            for(Module m : modules) {
                if(m.getKey() == Keyboard.getEventKey() && m.getKey() > 1) {
                    m.toggle();
                }
            }
        }
    }

    @SubscribeEvent // Called every client tick
    public void onUpdate(TickEvent.ClientTickEvent event) {
        if(Minecraft.getMinecraft().player != null && Minecraft.getMinecraft().world != null) {
            for(Module m : modules) {
                if(m.enabled) {
                    m.onUpdate();
                }
                m.onNonToggledUpdate();
            }
        }
    }

    @SubscribeEvent // Called when the world is rendered.
    public void onRenderWorld(RenderWorldLastEvent event) {
        if(Minecraft.getMinecraft().player != null && Minecraft.getMinecraft().world != null) {
            for(Module m : modules) {
                if(m.enabled) {
                    m.onRenderWorld();
                }
            }
        }
    }

    @SubscribeEvent // Called when the GUI is rendered.
    public void onRenderGUI(RenderGameOverlayEvent event) {
        if(event.getType() != RenderGameOverlayEvent.ElementType.TEXT)
            return;

        if(Minecraft.getMinecraft().player != null && Minecraft.getMinecraft().world != null) {
            for(Module m : modules) {
                if(m.enabled) {
                    m.onRenderGUI();
                }
            }
        }
    }
    
    @SubscribeEvent
	public void onFastTick(TickEvent event) {
		onFastUpdate();
	}
    
    @SubscribeEvent
	public void onServerTick(TickEvent.ServerTickEvent event) {
		onServerUpdate();
	}
    
    public void onFastUpdate() {
    	try {
    		for(Module m : modules) {
    			if (m.isEnabled())
    				m.onFastUpdate();
			}
		} catch(Exception e) {}
	}
    
    public void onServerUpdate() {
    	try {
			for(Module m : modules) {
				if(m.isEnabled())
					m.onServerUpdate();
			}
		} catch(Exception e) {}
	}


    public ArrayList<Module> getModulesInCategory(Category cat) {
        ArrayList<Module> mods = new ArrayList<Module>();
        for(Module m : modules) {
            if(m.category == cat) {
                mods.add(m);
            }
        }
        return mods;
    }

    public ArrayList<Module> getModules() {
        return modules;
    }

    public boolean isModuleEnabled(String name) {
    	for(Module m : modules) {
    		if(m.getName().equalsIgnoreCase(name))
    			return m.isEnabled();
    	}
    	
    	return false;
    }
}
