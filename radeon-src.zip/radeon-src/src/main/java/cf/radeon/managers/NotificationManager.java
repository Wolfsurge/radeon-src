package cf.radeon.managers;

import cf.radeon.module.modules.render.Notifications;
import cf.radeon.notifications.Notification;

import java.util.concurrent.LinkedBlockingQueue;

public class NotificationManager {

	private static LinkedBlockingQueue<Notification> pendingNotifications = new LinkedBlockingQueue<>();
	private static Notification currentNotification = null;

	public void addToQueue(Notification notification) {
		// this is to prevent extreme lag and mass notifications
		if(Notifications.mode.is("PC") || Notifications.mode.is("Chat"))
			notification.render();
		else
			pendingNotifications.add(notification);
	}

	public void update() {
		if (currentNotification != null && currentNotification.animate.getValue() <= 0) {
			currentNotification = null;
		}

		if (currentNotification == null && !pendingNotifications.isEmpty()) {
			currentNotification = pendingNotifications.poll();
			currentNotification.render();
		}

	}

	public void render() {
		update();

		if (currentNotification != null)
			currentNotification.render();
	}
}
