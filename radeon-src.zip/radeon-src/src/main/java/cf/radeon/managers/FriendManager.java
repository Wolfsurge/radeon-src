package cf.radeon.managers;

import java.util.ArrayList;
import java.util.List;

import cf.radeon.Radeon;
import cf.radeon.friends.Friend;

public class FriendManager {

	public static List<Friend> friends;

	public FriendManager(){
		friends = new ArrayList<>();
		
		Radeon.logger.info("Initialized Friend Manager");
	}

	public static List<String> getFriendsByName() {
		ArrayList<String> friendsName = new ArrayList<>();
		friends.forEach(friend -> friendsName.add(friend.getName()));

		return friendsName;
	}

	public static boolean isFriend(String name) {
		for (Friend f : friends) {
			if (f.getName().equalsIgnoreCase(name)) {
				return true;
			}
		}
		
		return false;
	}

	public static boolean toggleFriend(String name) {
		if(isFriend(name)) {
			removeFriend(name);
			return false;
		} else {
			addFriend(name);
			return true;
		}
	}

	public static boolean isEnemy(String name) {
		return (isFriend(name) ? false : true);
	}

	public static Friend getFriendByName(String name) {
		Friend fr = null;
		for (Friend f : friends) {
			if (f.getName().equalsIgnoreCase(name)) {
				fr = f;
			}
		}

		return fr;
	}

	public static void addFriend(String name) {
		friends.add(new Friend(name));
		
		Radeon.config.saveFriendConfig();
	}

	public static void removeFriend(String name) {
		friends.remove(getFriendByName(name));

		Radeon.config.saveFriendConfig();
	}
	
	public static void clearFriends() {
		friends.clear();
	}
}