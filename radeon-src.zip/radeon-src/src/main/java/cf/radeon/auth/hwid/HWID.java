package cf.radeon.auth.hwid;

import java.security.MessageDigest;

public class HWID {
	public static String getHWID() throws Exception {
		String result = "";
		final String main = System.getenv("PROCESSOR_IDENTIFIER") + System.getenv("COMPUTERNAME") + System.getProperty("user.name").trim();
		final byte[] bytes = main.getBytes("UTF-8");
		final MessageDigest messageDigest = MessageDigest.getInstance("MD5");
		final byte[] md5 = messageDigest.digest(bytes);
		for (final byte b : md5) {
			result += Integer.toHexString((b & 0xFF) | 0x300).substring(0, 3);
		}
		return result.toLowerCase();
	}
}
