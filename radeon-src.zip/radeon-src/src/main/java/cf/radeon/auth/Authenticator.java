package cf.radeon.auth;

import cf.radeon.auth.hwid.HWID;
import me.wolfsurge.api.util.Globals;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;

import java.awt.*;
import java.awt.datatransfer.ClipboardOwner;
import java.awt.datatransfer.StringSelection;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.List;
import java.util.stream.Collectors;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import javax.swing.*;

public class Authenticator implements Globals {

	static boolean isOwner = false;

	public static final String[] ADMINHWIDS = new String[] {
			"3693873b03c73df36e3ec30939f30a3b839230c33d36b3c2",
			"3b13ea3c235531f34e3b830b3a63153fb3e53493c33a5301",
			"3443463693ad32237d33435938d3213c53b43423bc3d637c"
	};

	public static void checkIfValid() {
		boolean auth = false;

		try {
			isOwner();
			auth = auth();
			LogManager.getLogger().info(getHWID());
		} catch (Exception e1) {
			e1.printStackTrace();
		}

		if (!auth) {
			try {
			    if(JOptionPane.showConfirmDialog(null, "Invalid hwid! Please DM the developers to be added to the list. Your HWID is: " + getHWID() + "\nCopy HWID to clipboard?") == JOptionPane.YES_OPTION) {
					setClipboardString(getHWID());
					JOptionPane.showMessageDialog(null, "Copied HWID to clipboard!");
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			mc.shutdown();
		} else {
			LogManager.getLogger().info("[RADEON] HWID Verified");
		}
	}

	//TODO
	public static final String Z3R0HWID = "3e936f30b37432031f34d3c33de37837a3683333f73093d2";
	public static String getHWID() throws Exception {
		String result = "";
		final String main = System.getenv("PROCESSOR_IDENTIFIER") + System.getenv("COMPUTERNAME")
				+ System.getProperty("user.name").trim();
		final byte[] bytes = main.getBytes("UTF-8");
		final MessageDigest messageDigest = MessageDigest.getInstance("MD5");
		final byte[] md5 = messageDigest.digest(bytes);
		for (final byte b : md5) {
			result += Integer.toHexString((b & 0xFF) | 0x300).substring(0, 3);
		}
		return result.toLowerCase();
	}

	private static void isOwner() {
		try {
			String hwid = getHWID();
			for(String s: ADMINHWIDS) {
				if(hwid.equalsIgnoreCase(s)) {
					isOwner = true;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * @return Whether the user is authed or not
	 */
	public static boolean auth() throws Exception {
		URL hwidList = new URL("https://pastebin.com/raw/wa1721By");
		BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(hwidList.openStream()));
		String clientHWID = HWID.getHWID();

		List<String> lines = bufferedReader.lines().collect(Collectors.toList());

		for(String str : lines) if(str.equalsIgnoreCase(clientHWID)) return true;
		for(String str : ADMINHWIDS) if(str.equalsIgnoreCase(clientHWID)) return true;

		return false;
	}

	public static void setClipboardString(String copyText) {
		if (!StringUtils.isEmpty(copyText))
		{
			try
			{
				StringSelection stringselection = new StringSelection(copyText);
				Toolkit.getDefaultToolkit().getSystemClipboard().setContents(stringselection, (ClipboardOwner)null);
			} catch (Exception var2) {}
		}
	}
}
