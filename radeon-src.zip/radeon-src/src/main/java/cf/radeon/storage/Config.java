package cf.radeon.storage;

import java.awt.Color;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import cf.radeon.Radeon;
import cf.radeon.clickgui.ClickGui;
import cf.radeon.clickgui.component.Frame;
import cf.radeon.friends.Friend;
import cf.radeon.managers.FriendManager;
import cf.radeon.managers.ModuleManager;
import cf.radeon.module.Module;
import cf.radeon.gui.hud.HudConfig;
import cf.radeon.gui.hud.modules.HUDMod;
import cf.radeon.module.modules.misc.FakePlayer;
import cf.radeon.module.modules.misc.Freecam;
import cf.radeon.module.settings.*;
import cf.radeon.utils.render.Colour;

public class Config {

	public File configFolder = new File("Radeon");
	public File hudFolder = new File("Radeon/HUD");
	public File moduleFolder = new File("Radeon/Modules");
	public File hudParentFolder = new File("Radeon/HUD/ParentModules");
	public File clickGuiFolder = new File("Radeon/ClickGUI");
	public File miscFolder = new File("Radeon/Misc");
	
	public Configuration hudConfig;
	public Configuration moduleConfig;
	public Configuration clickGUIConfig;
	
	public Configuration hudConfigToSave = ConfigurationAPI.newConfiguration(new File("Radeon/HUD/HudConfiguration.json"));
	public Configuration moduleConfigToSave;
	public Configuration clickGUIConfigToSave = ConfigurationAPI.newConfiguration(new File("Radeon/ClickGUI/ClickGUI.json"));

	public void saveHudConfig() {	
		if(!configFolder.exists()) {
			configFolder.mkdirs();
		}
		
		if(!hudFolder.exists()) {
			hudFolder.mkdirs();
		}
		
		for(HUDMod m : Radeon.hudManager.hudMods) {
			hudConfigToSave.set(m.name.toLowerCase() + "X", m.getX());
			hudConfigToSave.set(m.name.toLowerCase() + "Y", m.getY());
			hudConfigToSave.set(m.name.toLowerCase() + "Enabled", m.parent.enabled);
		}

		if(HudConfig.frames != null) for(Frame f : HudConfig.frames) { hudConfigToSave.set(f.category.name() + "X", f.getX()); hudConfigToSave.set(f.category.name() + "Y", f.getY()); }
		
		try {
			hudConfigToSave.save();
		} catch (IOException e) {
		}		
	}
	
	public void loadHUDConfig() {
		if(!configFolder.exists()) {
			configFolder.mkdirs();
		}
		
		if(!hudFolder.exists()) {
			hudFolder.mkdirs();
		}
		
		try {
			hudConfig = ConfigurationAPI.loadExistingConfiguration(new File("Radeon/HUD/HudConfiguration.json"));
		} catch (IOException e) {}
	}
	
	public void saveModConfig(Module m) {
		if(!configFolder.exists()) {
			configFolder.mkdirs();
		}
		
		if(!moduleFolder.exists()) {
			moduleFolder.mkdirs();
		}

		if(!hudParentFolder.exists()) {
			hudParentFolder.mkdirs();
		}

		if(m instanceof FakePlayer || m instanceof Freecam)
			return;

		if(m.isHudParent)
			moduleConfigToSave = ConfigurationAPI.newConfiguration(new File("Radeon/HUD/ParentModules" + m.name + ".json"));
		else
			moduleConfigToSave = ConfigurationAPI.newConfiguration(new File("Radeon/Modules/" + m.name + ".json"));

		moduleConfigToSave.setBool(m.name, m.isEnabled());
		
		for(Setting s : m.settings) {
			try {
				if(s instanceof BooleanSetting) {
					moduleConfigToSave.set("Bool_" + s.name, ((BooleanSetting) s).enabled);
				}
				
				if(s instanceof NumberSetting) {
					moduleConfigToSave.set("Num_" + s.name, ((NumberSetting) s).value);
				}
				
				if(s instanceof ModeSetting) {
					moduleConfigToSave.set("Mode_" + s.name, ((ModeSetting) s).index);
				}
				
				if(s instanceof KeybindSetting) {
					moduleConfigToSave.set("Key_" + s.getName(), ((KeybindSetting) s).getKeyCode());
				}
				
				if(s instanceof ColourPicker) {
					moduleConfigToSave.set("Col_" + s.getName() + " R", ((ColourPicker) s).getColor().getRed());
					moduleConfigToSave.set("Col_" + s.getName() + " G", ((ColourPicker) s).getColor().getGreen());
					moduleConfigToSave.set("Col_" + s.getName() + " B", ((ColourPicker) s).getColor().getBlue());
					moduleConfigToSave.set("Col_" + s.getName() + " A", ((ColourPicker) s).getColor().getAlpha());
					moduleConfigToSave.set("Col_" + s.getName() + " Rainbow", ((ColourPicker) s).getRainbow());
				}

				if(s instanceof StringSetting) {
					moduleConfigToSave.set("Str_" + s.getName(), ((StringSetting) s).getText());
				}
			} catch(Exception e) {}
		}
		
		try {
			moduleConfigToSave.save();
		} catch (IOException e) {
			e.printStackTrace();
		}	
	}
	
	public void loadModConfig() {
		if(!configFolder.exists()) {
			configFolder.mkdirs();
		}
		
		if(!moduleFolder.exists()) {
			moduleFolder.mkdirs();
		}

		if(!hudParentFolder.exists()) {
			hudParentFolder.mkdirs();
		}

		for(Module m : ModuleManager.modules) {
			try {
				if(m instanceof FakePlayer || m instanceof Freecam)
					continue;

				if(!m.isHudParent)
					moduleConfig = ConfigurationAPI.loadExistingConfiguration(new File("Radeon/Modules/" + m.name + ".json"));
				else
					moduleConfig = ConfigurationAPI.loadExistingConfiguration(new File("Radeon/HUD/ParentModules" + m.name + ".json"));

				m.enabled = (boolean) moduleConfig.get(m.name);
				
				if(m.enabled) {
					try {
						m.enable();
					} catch (Exception e) {}
				}
				
				for(Setting s : m.settings) {
					try {
						if (s instanceof BooleanSetting) {
							((BooleanSetting) s).setEnabled(moduleConfig.getBoolean("Bool_" + s.getName()));
						}

						if (s instanceof NumberSetting) {
							((NumberSetting) s).setValue(moduleConfig.getDouble("Num_" + s.getName(), ((NumberSetting) s).defaultValue));
						}

						if (s instanceof ModeSetting) {
							((ModeSetting) s).index = (int) moduleConfig.get("Mode_" + s.name);
						}

						if (s instanceof KeybindSetting) {
							((KeybindSetting) s).setKeyCode((int) moduleConfig.getDouble("Key_" + s.getName(), (double) ((KeybindSetting) s).defaultCode));
						}

						if (s instanceof ColourPicker) {
							Color c = new Color((int) moduleConfig.get("Col_" + s.getName() + " R"), (int) moduleConfig.get("Col_" + s.getName() + " G"), (int) moduleConfig.get("Col_" + s.getName() + " B"), (int) moduleConfig.get("Col_" + s.getName() + " A"));
							((ColourPicker) s).setValue(new Colour(c));
							((ColourPicker) s).setRainbow(moduleConfig.getBoolean("Col_" + s.getName() + " Rainbow"));
						}

						if (s instanceof StringSetting) {
							((StringSetting) s).setText((String) moduleConfig.get("Str_" + s.getName()));
						}
					} catch (Exception e) {}
				}
			} catch (IOException e) {e.printStackTrace();} catch (NumberFormatException e) {e.printStackTrace();} catch (NullPointerException e) {e.printStackTrace();}
		}
	}
	
	public void saveClickGUIConfig() {	
		if(!configFolder.exists()) {
			configFolder.mkdirs();
		}
		
		if(!clickGuiFolder.exists()) {
			clickGuiFolder.mkdirs();
		}
		
		for(Frame f : ClickGui.frames) {
			clickGUIConfigToSave.set(f.category.name() + "X", f.getX());
			clickGUIConfigToSave.set(f.category.name() + "Y", f.getY());
			clickGUIConfigToSave.set(f.category.name() + "_EXPANDED", !f.animation.isReversed());
		}
		
		try {
			clickGUIConfigToSave.save();
		} catch (IOException ignored) {}
	}
	
	public void loadClickGUIConfig() {
		if(!configFolder.exists())
			configFolder.mkdirs();
		
		if(!clickGuiFolder.exists())
			clickGuiFolder.mkdirs();
		
		try {
			clickGUIConfig = ConfigurationAPI.loadExistingConfiguration(new File("Radeon/ClickGUI/ClickGUI.json"));
		} catch (Exception ignored) {}
	}
	
	public void saveFriendConfig() {	
		if(!configFolder.exists())
			configFolder.mkdirs();
		
		if(!miscFolder.exists())
			miscFolder.mkdirs();
		
		File file = new File(miscFolder + "/Friends.radeon");
		if(!file.exists()) {
			try {
				file.createNewFile();
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		}
		
		try {
			PrintWriter pw = new PrintWriter(miscFolder + "/Friends.radeon");
			for(Friend str : FriendManager.friends) {
				pw.println(str.getName());
			}
			pw.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}
	
	public void loadFriendConfig() {
		if(!configFolder.exists()) {
			configFolder.mkdirs();
		}
		
		if(!miscFolder.exists()) {
			miscFolder.mkdirs();
		}
		
		ArrayList<String> lines = new ArrayList<>();
		
		try {
			BufferedReader reader = new BufferedReader(new FileReader(miscFolder + "/Friends.radeon"));
			String line = reader.readLine();
			while(line != null) {
				lines.add(line);
				line = reader.readLine();
			}
			reader.close();
		} catch (Exception ignored) {}
		
		for(String str : lines) {
			FriendManager.addFriend(str);
			Radeon.logger.info("Added friend: " + str);
		}
	}
	
	public void saveMisc() {
		if(!configFolder.exists()) {
			configFolder.mkdirs();
		}
		
		if(!miscFolder.exists()) {
			miscFolder.mkdirs();
		}
	}
	
	public void loadMisc() {
		if(!configFolder.exists()) {
			configFolder.mkdirs();
		}
		
		if(!miscFolder.exists()) {
			miscFolder.mkdirs();
		}
	}

	public void saveAll() {
		saveHudConfig();
		saveClickGUIConfig();
		saveFriendConfig();
		saveMisc();
		for(Module m : Radeon.moduleManager.getModules())
			saveModConfig(m);
	}
}
