package cf.radeon.notifications;

public enum NotificationType {
    INFO, WARN, ERROR
}
