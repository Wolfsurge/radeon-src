package cf.radeon.notifications;

import cf.radeon.Radeon;
import cf.radeon.animation.Animate;
import cf.radeon.animation.Easing;
import cf.radeon.managers.FontManager;
import cf.radeon.module.modules.render.Notifications;
import cf.radeon.utils.render.ColorUtil;
import cf.radeon.utils.render.RenderUtils2D;
import javafx.scene.transform.Scale;
import me.wolfsurge.api.util.Globals;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.util.text.TextFormatting;

import java.awt.*;

import static org.lwjgl.opengl.GL11.*;

public class Notification implements Globals {

    String title, message;
    NotificationType type;
    public boolean hasShown = false; // prevent lag

    public Animate animate = new Animate();

    public Notification(String title, String message, NotificationType type) {
        this.title = title;
        this.message = message;
        this.type = type;
        hasShown = false;
        animate.setMin(0).setMax(300).setSpeed(150).setValue(1).setEase(Easing.EXPO_IN_OUT).setReversed(false);
    }

    public void render() {
        animate.update();
        if (Notifications.mode.is("PC")) {
            try {
                SystemTray tray = SystemTray.getSystemTray();
                Image image = Toolkit.getDefaultToolkit().createImage("nah");

                TrayIcon trayIcon = new TrayIcon(image, "Radeon " + Radeon.VERSION);
                trayIcon.setImageAutoSize(true);
                trayIcon.setToolTip("Radeon " + Radeon.VERSION);
                tray.add(trayIcon);
                trayIcon.displayMessage(title, message, getFromType(this.type));
                hasShown = true;
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        } else if (Notifications.mode.is("Chat")) {
            if(!hasShown)
                mc.player.sendMessage(new TextComponentString(TextFormatting.GRAY + "[" + getFromTypeTF(type) + title + TextFormatting.GRAY + "] " + message));
            hasShown = true;
        } else if (Notifications.mode.is("Render")) {
            ScaledResolution sr = new ScaledResolution(mc);
            glPushMatrix();
            glPushAttrib(GL_SCISSOR_BIT);
            {
                RenderUtils2D.scissor(sr.getScaledWidth() / 2 - 150, 50, animate.getValue(), 40);
                glEnable(GL_SCISSOR_TEST);
            }

            int col = Color.GREEN.getRGB();
            if (type == NotificationType.WARN)
                col = new Color(238, 210, 2).getRGB();
            else if (type == NotificationType.ERROR)
                col = Color.RED.getRGB();

            RenderUtils2D.drawRect(sr.getScaledWidth() / 2 - 150, 50, sr.getScaledWidth() / 2 + 150, 90, 0x90000000);
            RenderUtils2D.drawRect(sr.getScaledWidth() / 2 - 150, 88, sr.getScaledWidth() / 2 + 150, 90, col);

            FontManager.drawStringWithShadow(title, sr.getScaledWidth() / 2 - 145, 60, -1);

            glScaled(0.5, 0.5, 0);
            FontManager.drawStringWithShadow(message, (sr.getScaledWidth() / 2 - 145) * 2, 75 * 2, -1);

            if (animate.getValue() == animate.getMax())
                animate.setReversed(true);

            if (animate.getValue() == 0)
                hasShown = true;

            glDisable(GL_SCISSOR_TEST);
            glPopAttrib();
            glPopMatrix();
        }
    }

    public TextFormatting getFromTypeTF(NotificationType typeIn) {
        if(typeIn == NotificationType.INFO)
            return TextFormatting.GREEN;
        else if(typeIn == NotificationType.WARN)
            return TextFormatting.GOLD;
        else if(typeIn == NotificationType.ERROR)
            return TextFormatting.DARK_RED;
        else
            return TextFormatting.GREEN;
    }

    public TrayIcon.MessageType getFromType(NotificationType typeIn) {
        if(typeIn == NotificationType.INFO)
            return TrayIcon.MessageType.INFO;
        else if(typeIn == NotificationType.WARN)
            return TrayIcon.MessageType.WARNING;
        else if(typeIn == NotificationType.ERROR)
            return TrayIcon.MessageType.ERROR;
        else
            return TrayIcon.MessageType.INFO;
    }

}
