package cf.radeon.command.impl;

import cf.radeon.command.Command;
import cf.radeon.utils.other.ChatUtil;

public final class EchoCommand extends Command {
    public EchoCommand() {
        super("Echo", "Echos something to the console", "echo/say/tell [message]", "echo", "say", "tell");
    }

    @Override
    public void onCommand(String[] args, String command) {
        if (args.length == 0) return;

        StringBuilder stringBuilder = new StringBuilder();

        for (String string : args) {
            stringBuilder.append(string).append(" ");
        }

        ChatUtil.addChatMessage(stringBuilder.toString());
    }
}
