package cf.radeon.command.impl;

import cf.radeon.command.Command;
import cf.radeon.utils.other.ChatUtil;

import java.awt.*;
import java.io.File;

public final class FolderCommand extends Command {
    public FolderCommand() {
        super("Folder", "Opens your config folder", "folder/open", "folder", "open");
    }

    @Override
    public void onCommand(String[] args, String command) {
        try {
            Desktop.getDesktop().open(new File("Radeon"));
        } catch (Exception exception) {
            ChatUtil.addChatMessage("Opening your config folder failed.");
        }

        ChatUtil.addChatMessage("Opened your config folder!");
    }
}

