package cf.radeon.command.impl;

import cf.radeon.command.Command;
import cf.radeon.managers.CommandManager;
import cf.radeon.utils.other.ChatUtil;
import com.mojang.realmsclient.gui.ChatFormatting;

public class HelpCommand extends Command {

    public HelpCommand() {
        super("Help", "Displays help for the client", "help", "help", "?");
    }

    @Override
    public void onCommand(String[] args, String command) {
        ChatUtil.addChatMessage("Radeon client help");

        ChatUtil.addChatMessage("-------------------");

        for(Command c: CommandManager.commands) {
            ChatUtil.addChatMessage(ChatFormatting.BOLD + CommandManager.prefix + c.getAliases().get(0) + ChatFormatting.RESET + ChatFormatting.WHITE + " " + c.getDescription());
        }

    }

}
