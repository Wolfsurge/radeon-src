package cf.radeon.command.impl;

import cf.radeon.Radeon;
import cf.radeon.command.Command;
import cf.radeon.module.Module;
import cf.radeon.utils.other.ChatUtil;
import com.mojang.realmsclient.gui.ChatFormatting;

public final class DrawnCommand extends Command {
    public DrawnCommand() {
        super("Drawn", "Makes a module drawn on the ArrayList", "drawn/d [module name]", "drawn", "d");
    }

    @Override
    public void onCommand(String[] args, String command) {
        if (args.length == 0) return;

        for (String string : args) {
            for (Module module : Radeon.moduleManager.getModules()) {
                if (module.getName().equalsIgnoreCase(string) && !module.visible.isEnabled()) {
                    ChatUtil.addChatMessage(ChatFormatting.AQUA + module.getName() + ChatFormatting.RESET + " is now " + ChatFormatting.GREEN + "DRAWN");
                    module.visible.enabled = true;
                } else if (module.getName().equalsIgnoreCase(string) && module.visible.isEnabled()) {
                    ChatUtil.addChatMessage(ChatFormatting.AQUA + module.getName() + ChatFormatting.RESET + " is now " + ChatFormatting.RED + "HIDDEN");
                    module.visible.enabled = false;
                }
            }
        }
    }
}
