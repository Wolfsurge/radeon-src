package cf.radeon.command.impl;

import cf.radeon.Radeon;
import cf.radeon.command.Command;
import cf.radeon.module.Module;
import cf.radeon.utils.other.ChatUtil;
import com.mojang.realmsclient.gui.ChatFormatting;

public final class ToggleCommand extends Command {
    public ToggleCommand() {
        super("Toggle", "Toggles a specified module.", "toggle [module name]", "toggle");
    }

    @Override
    public void onCommand(String[] args, String command) {
        if (args.length == 0) return;

        for (String string : args) {
            for (Module module : Radeon.moduleManager.getModules()) {
                if (module.getName().equalsIgnoreCase(string)) {
                    module.toggle();

                    if (module.isEnabled()) {
                        ChatUtil.addChatMessage(ChatFormatting.AQUA + module.getName() + ChatFormatting.RESET + " is now " + ChatFormatting.GREEN + "ENABLED");
                    } else {
                        ChatUtil.addChatMessage(ChatFormatting.AQUA + module.getName() + ChatFormatting.RESET + " is now " + ChatFormatting.RED + "DISABLED");
                    }
                }
            }
        }
    }
}
