package cf.radeon.command.impl;

import cf.radeon.Radeon;
import cf.radeon.command.Command;
import cf.radeon.utils.other.ChatUtil;

public final class ConfigCommand extends Command {
    public ConfigCommand() {
        super("Config", "Saves or loads your config", "config/c [save/load]", "config", "c");
    }

    @Override
    public void onCommand(String[] args, String command) {
        if (args.length == 0) return;

        for (String string : args) {
            if (string.equalsIgnoreCase("save")) {
                Radeon.config.saveAll();

                ChatUtil.addChatMessage("Saved your config!");
            }
        }
    }
}
