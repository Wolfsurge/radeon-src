package cf.radeon.command.impl;

import cf.radeon.Radeon;
import cf.radeon.command.Command;
import cf.radeon.module.Module;
import cf.radeon.utils.other.ChatUtil;
import com.mojang.realmsclient.gui.ChatFormatting;

public final class ModulesCommand extends Command {
    public ModulesCommand() {
        super("Modules", "Lists all the client's modules", "modules/mods", "modules", "mods");
    }

    @Override
    public void onCommand(String[] args, String command) {
        for (Module module : Radeon.moduleManager.getModules()) {
            ChatUtil.addChatMessage(ChatFormatting.AQUA + module.getName() + " " + ChatFormatting.GRAY + ": " + ChatFormatting.WHITE + module.description);
        }
    }
}
