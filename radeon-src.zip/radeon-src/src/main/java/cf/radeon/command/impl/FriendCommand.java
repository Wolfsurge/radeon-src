package cf.radeon.command.impl;

import cf.radeon.command.Command;
import cf.radeon.managers.FriendManager;
import cf.radeon.utils.other.ChatUtil;

public class FriendCommand extends Command {

    public FriendCommand() {
        super("Friend", "Add or remove a friend.", ".friend [username]", "friend", "f");
    }

    @Override
    public void onCommand(String[] args, String command) {
        if(args.length == 0) {
            ChatUtil.addChatMessage("You need some arguments... try .friend username to add them");
        } else if(args.length == 1) {
            String ign = args[0];
            boolean added = FriendManager.toggleFriend(ign);

            ChatUtil.addChatMessage((added ? "Added" : "Removed") + " " + ign + " from the friendlist");
        } else {
            String one = args[0];
            String two = args[1];

            if(one.equalsIgnoreCase("add")) {
                FriendManager.addFriend(two);
            } else if(one.equalsIgnoreCase("remove") || one.equalsIgnoreCase("delete") || one.equalsIgnoreCase("rem") || one.equalsIgnoreCase("del")) {
                FriendManager.removeFriend(two);
            }
        }
    }
}
