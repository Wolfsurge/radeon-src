package cf.radeon.command.impl;

import cf.radeon.Radeon;
import cf.radeon.command.Command;
import cf.radeon.utils.other.ChatUtil;
import com.mojang.realmsclient.gui.ChatFormatting;

public final class PrefixCommand extends Command {
    public PrefixCommand() {
        super("Prefix", "Changes the command prefix", "prefix [new prefix]", "prefix");
    }

    @Override
    public void onCommand(String[] args, String command) {
        if (args.length == 0) {
            ChatUtil.addChatMessage("Please specify a prefix");
            return;
        }

        Radeon.commandManager.prefix = args[0];

        ChatUtil.addChatMessage("Set the clients chat prefix to " + ChatFormatting.AQUA + args[0] + ChatFormatting.RESET + ".");
    }
}
