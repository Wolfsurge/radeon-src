package cf.radeon.command.impl;

import cf.radeon.command.Command;
import cf.radeon.managers.ModuleManager;
import cf.radeon.utils.other.ChatUtil;
import com.mojang.realmsclient.gui.ChatFormatting;
import org.lwjgl.input.Keyboard;

public final class BindCommand extends Command {
    public BindCommand() {
        super("Bind", "Binds a module to a specified key", "bind/b [module] [key]", "bind", "b");
    }

    @Override
    public void onCommand(String[] args, String command) {
        if (args.length == 0) {
            ChatUtil.addChatMessage("Please specify a module.");
            return;
        }

        if (args.length == 1) {
            ChatUtil.addChatMessage("Please specify a key.");
            return;
        }

        if (ModuleManager.getModuleByName(args[0]) == null) {
            ChatUtil.addChatMessage("Could not find module " + ChatFormatting.AQUA + args[0] + ChatFormatting.RESET + ".");
            return;
        }

        ModuleManager.getModuleByName(args[0]).keyCode.setKeyCode(Keyboard.getKeyIndex(args[1].toUpperCase()));
        ChatUtil.addChatMessage("Bound " + ChatFormatting.AQUA + ModuleManager.getModuleByName(args[0]).getName() + ChatFormatting.RESET + " to " + ChatFormatting.GREEN + args[1].toUpperCase() + ChatFormatting.RESET + ".");
    }
}
