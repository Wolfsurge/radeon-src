package cf.radeon.packet;

import cf.radeon.module.Module;
import net.minecraft.util.math.Vec2f;
import net.minecraft.util.math.Vec3d;

public class PlayerPacket {

    private int priority;

    private Vec3d position;
    private Vec2f rotation;

    public PlayerPacket(Module module, Vec2f rotation) {
        this(module, null, rotation);
    }

    public PlayerPacket(Module module, Vec3d position) {
        this(module, position, null);
    }

    public PlayerPacket(Module module, Vec3d position, Vec2f rotation) {
        this(1, position, rotation);
    }

    private PlayerPacket(int priority, Vec3d position, Vec2f rotation) {
        this.priority = priority;
        this.position = position;
        this.rotation = rotation;
    }

    public int getPriority() {
        return priority;
    }

    public Vec3d getPosition() {
        return position;
    }

    public Vec2f getRotation() {
        return rotation;
    }
}
