package cf.radeon.discord;

import cf.radeon.Radeon;
import club.minnced.discord.rpc.DiscordEventHandlers;
import club.minnced.discord.rpc.DiscordRPC;
import club.minnced.discord.rpc.DiscordRichPresence;
import me.wolfsurge.api.util.Globals;

public class DiscordManager implements Globals {

    private static final DiscordRPC discordPresence = DiscordRPC.INSTANCE;
    private static final DiscordRichPresence richPresence = new DiscordRichPresence();
    private static final DiscordEventHandlers presenceHandlers = new DiscordEventHandlers();

    private static Thread presenceThread;

    public static void startPresence() {
        discordPresence.Discord_Initialize("921109520636317716", presenceHandlers, true, "");
        richPresence.startTimestamp = System.currentTimeMillis() / 1000L;
        discordPresence.Discord_UpdatePresence(richPresence);

        presenceThread = new Thread(() -> {
            while (!Thread.currentThread().isInterrupted()) {
                try {
                    richPresence.largeImageKey = "large";
                    richPresence.largeImageText = Radeon.NAME;
                    if(!Radeon.hasFinishedLoading) {
                        richPresence.state = "Loading Radeon Version " + Radeon.VERSION;
                    } else {
                        richPresence.state = "Radeon Client v" + Radeon.VERSION;
                    }
                    discordPresence.Discord_UpdatePresence(richPresence);
                    Thread.sleep(3000);
                } catch (Exception ignored) {}
            }
        });

        presenceThread.start();
    }

    public static void update(String arg) {
        richPresence.details = arg;
    }

    public static void doInitPhase() {
        richPresence.largeImageKey = "large";
        richPresence.largeImageText = Radeon.NAME;
        richPresence.state = "Using Radeon Client version " + Radeon.VERSION;
        discordPresence.Discord_UpdatePresence(richPresence);
    }

    public static void interruptPresence() {
        if (presenceThread != null && !presenceThread.isInterrupted()) {
            presenceThread.interrupt();
        }

        discordPresence.Discord_Shutdown();
        discordPresence.Discord_ClearPresence();
    }
}
