package cf.radeon.animation;

public class Delta { public static int DELTATIME; }
