package cf.radeon;

import cf.radeon.auth.Authenticator;
import cf.radeon.clickgui.ClickGui;
import cf.radeon.discord.DiscordManager;
import cf.radeon.managers.*;
import cf.radeon.module.Module;
import cf.radeon.utils.render.BlurUtil;
import org.apache.logging.log4j.Logger;
import me.wolfsurge.api.gui.font.FontUtil;
import cf.radeon.storage.Config;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLPostInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import me.zero.alpine.EventManager;
import java.io.IOException;

@Mod(modid = Radeon.MODID, name = Radeon.MODNAME, version = Radeon.VERSION)
public class Radeon {
    public static final String MODID = "radeon";
    public static final String MODNAME = "Radeon";
    public static final String VERSION = "1.2";
    
    public static String NAME = "Radeon Client";

    public static Logger logger;
    public static EventManager EVENT_BUS = new EventManager();
    public static boolean hasFinishedLoading = false; // For Discord RPC

    public static BlurUtil blurManager;
    public static ModuleManager moduleManager;
    public static ClickGui clickGui;
    public static cf.radeon.managers.EventManager eventManager;
    public static HudManager hudManager;
    public static Config config;
    public static FriendManager friendManager;
    public static CommandManager commandManager;
    public static TickManager tickManager;
    public static NotificationManager notificationManager;
    public static DiscordManager discordManager;
    public static RotationManager rotationManager;

    @Mod.EventHandler
    public void preInit(FMLPreInitializationEvent event) throws IOException {
        logger = event.getModLog();
        Authenticator.checkIfValid();

        discordManager = new DiscordManager();
        DiscordManager.startPresence();
    }

    @Mod.EventHandler
    public void init(FMLPostInitializationEvent event) {
        MinecraftForge.EVENT_BUS.register(this);
        FontUtil.bootstrap();
        config = new Config();
        config.loadHUDConfig();
        config.loadClickGUIConfig();
        blurManager = new BlurUtil();
        moduleManager = new ModuleManager();
        clickGui = new ClickGui();
        eventManager = new cf.radeon.managers.EventManager();
        hudManager = new HudManager();
        friendManager = new FriendManager();
        config.loadFriendConfig();
        commandManager = new CommandManager();
        config.loadMisc();
        notificationManager = new NotificationManager();
        tickManager = new TickManager();
        rotationManager = new RotationManager();
        FontManager.load();
        hasFinishedLoading = true;
        logger.info("\n\n\nRadeon Initialized!\n\n");
    }

    public static void shutdown() {
        config.saveHudConfig();
        config.saveClickGUIConfig();
        config.saveFriendConfig();
        config.saveMisc();
        for(Module m : moduleManager.getModules())
            config.saveModConfig(m);
    }
}