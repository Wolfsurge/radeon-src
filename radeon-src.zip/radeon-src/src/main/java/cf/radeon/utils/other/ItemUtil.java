package cf.radeon.utils.other;

import java.util.Iterator;
import me.wolfsurge.api.util.Globals;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemShield;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;
import net.minecraft.item.ItemTool;

public class ItemUtil implements Globals {

	public static int getItemFromHotbar(Item item) {
		int slot = -1;

		for (int i = 0; i < 9; ++i) {
			ItemStack stack = ItemUtil.mc.player.inventory.getStackInSlot(i);

			if (stack.getItem() == item) {
				slot = i;
			}
		}

		return slot;
	}

	public static int getItemSlot(Class clss) {
		int itemSlot = -1;

		for (int i = 45; i > 0; --i) {
			if (ItemUtil.mc.player.inventory.getStackInSlot(i).getItem().getClass() == clss) {
				itemSlot = i;
				break;
			}
		}

		return itemSlot;
	}

	public static int getItemSlot(Item item) {
		int itemSlot = -1;

		for (int i = 45; i > 0; --i) {
			if (ItemUtil.mc.player.inventory.getStackInSlot(i).getItem().equals(item)) {
				itemSlot = i;
				break;
			}
		}

		return itemSlot;
	}

	public static int getItemCount(Item item) {
		int count = 0;
		int size = ItemUtil.mc.player.inventory.mainInventory.size();

		for (int offhandStack = 0; offhandStack < size; ++offhandStack) {
			ItemStack itemStack = (ItemStack) ItemUtil.mc.player.inventory.mainInventory.get(offhandStack);

			if (itemStack.getItem() == item) {
				count += itemStack.getCount();
			}
		}

		ItemStack itemstack = ItemUtil.mc.player.getHeldItemOffhand();

		if (itemstack.getItem() == item) {
			count += itemstack.getCount();
		}

		return count;
	}

	public static boolean isArmorLow(EntityPlayer player, int durability) {
		Iterator iterator = player.inventory.armorInventory.iterator();

		ItemStack piece;

		do {
			if (!iterator.hasNext()) {
				return false;
			}

			piece = (ItemStack) iterator.next();
		} while (piece != null && getDamageInPercent(piece) >= (float) durability);

		return true;
	}

	public static int getItemDamage(ItemStack stack) {
		return stack.getMaxDamage() - stack.getItemDamage();
	}

	public static float getDamageInPercent(ItemStack stack) {
		float green = ((float) stack.getMaxDamage() - (float) stack.getItemDamage()) / (float) stack.getMaxDamage();
		float red = 1.0F - green;

		return (float) (100 - (int) (red * 100.0F));
	}

	public static int getRoundedDamage(ItemStack stack) {
		return (int) getDamageInPercent(stack);
	}

	public static boolean hasDurability(ItemStack stack) {
		Item item = stack.getItem();

		return item instanceof ItemArmor || item instanceof ItemSword || item instanceof ItemTool || item instanceof ItemShield;
	}
}
