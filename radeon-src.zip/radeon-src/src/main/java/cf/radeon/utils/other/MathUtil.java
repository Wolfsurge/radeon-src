package cf.radeon.utils.other;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Random;

/**
 * @author olliem5
 * @author linustouchtips
 */

public final class MathUtil {
	public static double roundNumber(double number, int scale) {
		BigDecimal bigDecimal = new BigDecimal(number);
		bigDecimal = bigDecimal.setScale(scale, RoundingMode.HALF_UP);

		return bigDecimal.doubleValue();
	}

	public static double roundAvoid(double number, int places) {
		double scale = Math.pow(10, places);
		return Math.round(number * scale) / scale;
	}

	public static int getRandomInt(int min, int max) {
		Random r = new Random();
		int index = r.nextInt(max - min) + min;
		return index;
	}

	public static double getRandomInRange(double min, double max) {
		Random random = new Random();
		double range = max - min;
		double scaled = random.nextDouble() * range;
		if (scaled > max) {
			scaled = max;
		}
		double shifted = scaled + min;

		if (shifted > max) {
			shifted = max;
		}
		return shifted;
	}
	public static double roundDouble(final double value, final int places) {
		if (places < 0) {
			throw new IllegalArgumentException();
		}
		BigDecimal bd = new BigDecimal(value);
		bd = bd.setScale(places, RoundingMode.HALF_UP);
		return bd.doubleValue();
	}
	public static float roundFloat(final float value, final int places) {
		if (places < 0) {
			throw new IllegalArgumentException();
		}
		BigDecimal bd = new BigDecimal(value);
		bd = bd.setScale(places, RoundingMode.HALF_UP);
		return bd.floatValue();
	}
}
