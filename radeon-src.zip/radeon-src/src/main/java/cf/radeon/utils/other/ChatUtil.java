package cf.radeon.utils.other;

import cf.radeon.Radeon;
import net.minecraft.client.Minecraft;
import net.minecraft.util.text.TextComponentString;

public class ChatUtil {
	
	static Minecraft mc = Minecraft.getMinecraft();
	
	public static void addChatMessage(String message) {
		message = "\2479" + Radeon.NAME + "\247  > " + message;
		
		Minecraft.getMinecraft().player.sendMessage(new TextComponentString(message));
	}

}
