package cf.radeon.utils.render;

import org.lwjgl.opengl.GL11;

import java.awt.Color;

public class ColorUtil {
    public static Color getBlendedColor(float percentage) {
        return getBlendedColor(percentage, 255);
    }

    public static Color getBlendedColor(float percentage, int alpha) {
        if (percentage < 0.5) {
            return interpolate(Color.RED, Color.YELLOW, percentage / 0.5, alpha);
        }
        else {
            //return interpolate(Color.YELLOW, lime, (percentage - 0.5) / 0.5);
            return interpolate(Color.YELLOW, Color.GREEN, (percentage - 0.5) / 0.5, alpha);
        }
    }

    private static Color interpolate(Color color1, Color color2, double fraction, int alpha) {
        double r = interpolate(color1.getRed(), color2.getRed(), fraction);
        double g = interpolate(color1.getGreen(), color2.getGreen(), fraction);
        double b = interpolate(color1.getBlue(), color2.getBlue(), fraction);
        return new Color((int) Math.round(r), (int) Math.round(g), (int) Math.round(b), alpha);
    }

    private static double interpolate(double d1, double d2, double fraction) {
        return d1 + (d2 - d1) * fraction;
    }

    public static Color shadeColour(Color color, int precent) {
        int r = (color.getRed() * (100 + precent) / 100);
        int g = (color.getGreen() * (100 + precent) / 100);
        int b = (color.getBlue() * (100 + precent) / 100);
        return new Color(r,g,b);
    }

    public static int shadeColour(int color, int precent) {
        int r = (((color & 0xFF0000) >> 16) * (100 + precent) / 100);
        int g = (((color & 0xFF00) >> 8) * (100 + precent) / 100);
        int b = ((color & 0xFF) * (100 + precent) / 100);
        return new Color(r,g,b).hashCode();
    }

    public static Color releasedDynamicRainbow(final int delay, int alpha) {
        double rainbowState = Math.ceil((System.currentTimeMillis() + delay) / 20.0);
        rainbowState %= 360.0;

        Color c = Color.getHSBColor((float) (rainbowState / 360.0), 1f, 1f);
        return new Color(c.getRed(), c.getGreen(), c.getBlue(), alpha);
    }

    public static void hexColor(int hexColor) {
        float red = (float) (hexColor >> 16 & 0xFF) / 255.0f;
        float green = (float) (hexColor >> 8 & 0xFF) / 255.0f;
        float blue = (float) (hexColor & 0xFF) / 255.0f;
        float alpha = (float) (hexColor >> 24 & 0xFF) / 255.0f;
        GL11.glColor4f(red, green, blue, alpha);
    }

    public static Color getSinState(final Color c1, final double delay, final int a, final type t) {
        double sineState;
        sineState = Math.sin(2400 - System.currentTimeMillis() / delay) * Math.sin(2400 - System.currentTimeMillis() / delay);
        float[] hsb = Color.RGBtoHSB(c1.getRed(), c1.getGreen(), c1.getBlue(), null);
        Color c = null;
        switch (t) {
            case HUE:
                sineState /= hsb[0];
                sineState = Math.min(1.0, sineState);
                c = Color.getHSBColor((float) sineState, 1f, 1f);
                break;
            case SATURATION:
                sineState /= hsb[1];
                sineState = Math.min(1.0, sineState);
                c = Color.getHSBColor(hsb[0], (float) sineState, 1f);
                break;
            case BRIGHTNESS:
                sineState /= hsb[2];
                sineState = Math.min(1.0, sineState);
                c = Color.getHSBColor(hsb[0], 1f, (float) sineState);
                break;
            case SPECIAL:
                sineState /= hsb[1];
                sineState = Math.min(1.0, sineState);
                c = Color.getHSBColor(hsb[0], 1f, (float) sineState);
                break;
        }
        return new Color(c.getRed(), c.getGreen(), c.getBlue(), a);
    }

    public static Color getSinState(final Color c1, final Color c2, final double delay, final int a) {
        double sineState;
        sineState = Math.sin(2400 - System.currentTimeMillis() / delay) * Math.sin(2400 - System.currentTimeMillis() / delay);
        float[] hsb = Color.RGBtoHSB(c1.getRed(), c1.getGreen(), c1.getBlue(), null);
        float[] hsb2 = Color.RGBtoHSB(c2.getRed(), c2.getGreen(), c2.getBlue(), null);
        Color c;
        sineState /= hsb[0];
        sineState *= sineState/hsb2[0];
        sineState = Math.min(1.0, sineState);
        c = Color.getHSBColor((float) sineState, 1f, 1f);

        return new Color(c.getRed(), c.getGreen(), c.getBlue(), a);
    }


    public enum type {
        HUE,
        SATURATION,
        BRIGHTNESS,
        SPECIAL
    }
    
    public static int rainbow(int delay) {
		double rainbowState = Math.ceil((System.currentTimeMillis() + delay) / 20.0);
		rainbowState %= 360;
		return Color.getHSBColor((float) (rainbowState / 360.0f), (float) 0.5, (float) 1).getRGB();
	}
	
	public static int rainbowVibrant(int delay) {
		double rainbowState = Math.ceil((System.currentTimeMillis() + delay) / 20.0);
		rainbowState %= 360;
		return Color.getHSBColor((float) (rainbowState / 360.0f), (float) 1, (float) 1).getRGB();
	}
	
	public static int rainbowWave(float seconds, float saturation, float brightness, int index) {
		float hue = ((System.currentTimeMillis() + index) % (int)(seconds * 1000) / (float)(seconds * 1000));
		int color = Color.HSBtoRGB(hue, saturation, brightness);
		return color;
	}
    
}
