package cf.radeon.utils.render;

import me.wolfsurge.api.util.Globals;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import org.lwjgl.opengl.GL11;

import java.awt.*;

import static org.lwjgl.opengl.GL11.*;

/**
 * @author olliem5
 * @author linustouchtips
 */

public final class RenderUtil3D implements Globals {



    public static void drawRect(double d, double e, double f, double g, int color)
    {
        GL11.glDisable(GL11.GL_DEPTH_TEST);
        GL11.glEnable(GL11.GL_BLEND);
        GL11.glDisable(GL11.GL_TEXTURE_2D);
        GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
        GL11.glDepthMask(true);
        GL11.glEnable(GL11.GL_LINE_SMOOTH);
        GL11.glHint(GL11.GL_LINE_SMOOTH_HINT, GL11.GL_NICEST);
        GL11.glHint(GL11.GL_POLYGON_SMOOTH_HINT, GL11.GL_NICEST);
        Gui.drawRect((int)d, (int)e, (int)f, (int)g, color);
        GL11.glEnable(GL11.GL_TEXTURE_2D);
        GL11.glDisable(GL11.GL_BLEND);
        GL11.glEnable(GL11.GL_DEPTH_TEST);
        GL11.glDisable(GL11.GL_LINE_SMOOTH);
        GL11.glHint(GL11.GL_LINE_SMOOTH_HINT, GL11.GL_DONT_CARE);
        GL11.glHint(GL11.GL_POLYGON_SMOOTH_HINT, GL11.GL_DONT_CARE);
    }

    public static void drawFilledCircle(double x, double y, double r, int c)
    {
        float f = (c >> 24 & 0xFF) / 255.0f;
        float f2 = (c >> 16 & 0xFF) / 255.0f;
        float f3 = (c >> 8 & 0xFF) / 255.0f;
        float f4 = (c & 0xFF) / 255.0f;
        GL11.glEnable(GL11.GL_BLEND);
        GL11.glDisable(GL11.GL_TEXTURE_2D);
        GL11.glEnable(GL11.GL_LINE_SMOOTH);
        GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
        GL11.glColor4f(f2, f3, f4, f);
        GL11.glBegin(GL11.GL_TRIANGLE_FAN);

        for (int i = 0; i <= 360; ++i)
        {
            double x2 = Math.sin(i * 3.141592653589793 / 180.0) * r;
            double y2 = Math.cos(i * 3.141592653589793 / 180.0) * r;
            GL11.glVertex2d(x + x2, y + y2);
        }

        GL11.glEnd();
        GL11.glDisable(GL11.GL_LINE_SMOOTH);
        GL11.glEnable(GL11.GL_TEXTURE_2D);
        GL11.glDisable(GL11.GL_BLEND);
    }

    public static void drawCornerRectangle(double x, double y, double w, double h, double cornerSize, int colr)
    {
        drawFilledCircle(x + cornerSize, y + cornerSize, cornerSize, colr); // top left
        drawFilledCircle(x + w - cornerSize, y + cornerSize, cornerSize, colr); // top right
        drawFilledCircle(x + cornerSize, y + h - cornerSize, cornerSize, colr); // bottom left
        drawFilledCircle(x + w - cornerSize, y + h - cornerSize, cornerSize, colr); // bottom right
        drawRect(x + cornerSize, y, x - cornerSize + w, y + h, colr); // tall boie
        drawRect(x, y + cornerSize, x + w, y - cornerSize + h, colr); // long boie
    }

    public static void drawCornerRectangleFromPos(double x1, double y1, double x2, double y2, double cornerSize, int color)
    {
        drawFilledCircle(x1 + cornerSize, y1 + cornerSize, cornerSize, color);
        drawFilledCircle(x2 - cornerSize, y1 + cornerSize, cornerSize, color);
        drawFilledCircle(x1 + cornerSize, y2 - cornerSize, cornerSize, color);
        drawFilledCircle(x2 - cornerSize, y2 - cornerSize, cornerSize, color);
        drawRect(x1 + cornerSize, y1, x2 - cornerSize, y2, color);
        drawRect(x1, y1 + cornerSize, x2, y2 - cornerSize, color);
    }

    public static void draw2dEsp(Entity e)
    {
        double x = e.lastTickPosX + (e.posX - e.lastTickPosX) * mc.timer.renderPartialTicks - mc.getRenderManager().renderPosX;
        double y = e.lastTickPosY + (e.posY - e.lastTickPosY) * mc.timer.renderPartialTicks - mc.getRenderManager().renderPosY;
        double z = e.lastTickPosZ + (e.posZ - e.lastTickPosZ) * mc.timer.renderPartialTicks - mc.getRenderManager().renderPosZ;

        // if (e.hurtTime != 0) {
        // color = Color.RED;
        // }
        GL11.glPushMatrix();
        GL11.glTranslated(x, y - 0.2D, z);
        GL11.glScalef(0.03F, 0.03F, 0.03F);

        GL11.glRotated(-mc.getRenderManager().playerViewY, 0.0D, 1.0D, 0.0D);
        GL11.glDisable(GL11.GL_DEPTH_TEST);

        drawRect(-21, 0, -22, 74, 0xffff0000); // right
        drawRect(21, 0, 22, 74, -1); // left
        drawRect(-21, 0, 22, 4, -1);
        drawRect(-21, 71, 22, 74, -1);
        GL11.glEnable(GL11.GL_DEPTH_TEST);
        GL11.glPopMatrix();
    }

    public static void prepareGL() {
        GlStateManager.pushMatrix();
        GlStateManager.enableBlend();
        GlStateManager.disableDepth();
        GlStateManager.tryBlendFuncSeparate(770, 771, 0, 1);
        GlStateManager.disableTexture2D();
        GlStateManager.depthMask(false);

        GL11.glEnable(GL_LINE_SMOOTH);
        GL11.glHint(GL_LINE_SMOOTH_HINT, GL_NICEST);
    }

    public static void releaseGL() {
        GL11.glDisable(GL_LINE_SMOOTH);

        GlStateManager.depthMask(true);
        GlStateManager.enableDepth();
        GlStateManager.enableTexture2D();
        GlStateManager.disableBlend();
        GlStateManager.popMatrix();
    }

    public static AxisAlignedBB generateBB(long x, long y, long z) {
        BlockPos blockPos = new BlockPos(x, y, z);

        return new AxisAlignedBB(blockPos.getX() - mc.getRenderManager().viewerPosX, blockPos.getY() - mc.getRenderManager().viewerPosY, blockPos.getZ() - mc.getRenderManager().viewerPosZ, blockPos.getX() + 1 - mc.getRenderManager().viewerPosX, blockPos.getY() + (1) - mc.getRenderManager().viewerPosY, blockPos.getZ() + 1 - mc.getRenderManager().viewerPosZ);
    }

    public static void draw(BlockPos blockPos, boolean box, boolean outline, double boxHeight, double outlineHeight, Color colour) {
        AxisAlignedBB axisAlignedBB = generateBB(blockPos.getX(), blockPos.getY(), blockPos.getZ());

        prepareGL();

        if (box) {
            drawFilledBox(axisAlignedBB, boxHeight, colour.getRed() / 255.0f, colour.getGreen() / 255.0f, colour.getBlue() / 255.0f, colour.getAlpha() / 255.0f);
        }

        if (outline) {
            drawBoundingBox(axisAlignedBB, outlineHeight, colour.getRed() / 255.0f, colour.getGreen() / 255.0f, colour.getBlue() / 255.0f, colour.getAlpha() / 255.0f);
        }

        releaseGL();
    }

    /**
     * Below has been taken and modified from RenderGlobal
     * @see net.minecraft.client.renderer.RenderGlobal
     */

    public static void drawBoundingBox(BufferBuilder bufferBuilder, double minX, double minY, double minZ, double maxX, double maxY, double maxZ, float red, float green, float blue, float alpha) {
        bufferBuilder.pos(minX, minY, minZ).color(red, green, blue, 0.0F).endVertex();
        bufferBuilder.pos(minX, minY, minZ).color(red, green, blue, alpha).endVertex();
        bufferBuilder.pos(maxX, minY, minZ).color(red, green, blue, alpha).endVertex();
        bufferBuilder.pos(maxX, minY, maxZ).color(red, green, blue, alpha).endVertex();
        bufferBuilder.pos(minX, minY, maxZ).color(red, green, blue, alpha).endVertex();
        bufferBuilder.pos(minX, minY, minZ).color(red, green, blue, alpha).endVertex();
        bufferBuilder.pos(minX, maxY, minZ).color(red, green, blue, alpha).endVertex();
        bufferBuilder.pos(maxX, maxY, minZ).color(red, green, blue, alpha).endVertex();
        bufferBuilder.pos(maxX, maxY, maxZ).color(red, green, blue, alpha).endVertex();
        bufferBuilder.pos(minX, maxY, maxZ).color(red, green, blue, alpha).endVertex();
        bufferBuilder.pos(minX, maxY, minZ).color(red, green, blue, alpha).endVertex();
        bufferBuilder.pos(minX, maxY, maxZ).color(red, green, blue, 0.0f).endVertex();
        bufferBuilder.pos(minX, minY, maxZ).color(red, green, blue, alpha).endVertex();
        bufferBuilder.pos(maxX, maxY, maxZ).color(red, green, blue, 0.0f).endVertex();
        bufferBuilder.pos(maxX, minY, maxZ).color(red, green, blue, alpha).endVertex();
        bufferBuilder.pos(maxX, maxY, minZ).color(red, green, blue, 0.0f).endVertex();
        bufferBuilder.pos(maxX, minY, minZ).color(red, green, blue, alpha).endVertex();
        bufferBuilder.pos(maxX, minY, minZ).color(red, green, blue, 0.0f).endVertex();
    }

    public static void addChainedFilledBoxVertices(BufferBuilder bufferBuilder, double x1, double y1, double z1, double x2, double y2, double z2, float red, float green, float blue, float alpha) {
        bufferBuilder.pos(x1, y1, z1).color(red, green, blue, alpha).endVertex();
        bufferBuilder.pos(x1, y1, z1).color(red, green, blue, alpha).endVertex();
        bufferBuilder.pos(x1, y1, z1).color(red, green, blue, alpha).endVertex();
        bufferBuilder.pos(x1, y1, z2).color(red, green, blue, alpha).endVertex();
        bufferBuilder.pos(x1, y2, z1).color(red, green, blue, alpha).endVertex();
        bufferBuilder.pos(x1, y2, z2).color(red, green, blue, alpha).endVertex();
        bufferBuilder.pos(x1, y2, z2).color(red, green, blue, alpha).endVertex();
        bufferBuilder.pos(x1, y1, z2).color(red, green, blue, alpha).endVertex();
        bufferBuilder.pos(x2, y2, z2).color(red, green, blue, alpha).endVertex();
        bufferBuilder.pos(x2, y1, z2).color(red, green, blue, alpha).endVertex();
        bufferBuilder.pos(x2, y1, z2).color(red, green, blue, alpha).endVertex();
        bufferBuilder.pos(x2, y1, z1).color(red, green, blue, alpha).endVertex();
        bufferBuilder.pos(x2, y2, z2).color(red, green, blue, alpha).endVertex();
        bufferBuilder.pos(x2, y2, z1).color(red, green, blue, alpha).endVertex();
        bufferBuilder.pos(x2, y2, z1).color(red, green, blue, alpha).endVertex();
        bufferBuilder.pos(x2, y1, z1).color(red, green, blue, alpha).endVertex();
        bufferBuilder.pos(x1, y2, z1).color(red, green, blue, alpha).endVertex();
        bufferBuilder.pos(x1, y1, z1).color(red, green, blue, alpha).endVertex();
        bufferBuilder.pos(x1, y1, z1).color(red, green, blue, alpha).endVertex();
        bufferBuilder.pos(x2, y1, z1).color(red, green, blue, alpha).endVertex();
        bufferBuilder.pos(x1, y1, z2).color(red, green, blue, alpha).endVertex();
        bufferBuilder.pos(x2, y1, z2).color(red, green, blue, alpha).endVertex();
        bufferBuilder.pos(x2, y1, z2).color(red, green, blue, alpha).endVertex();
        bufferBuilder.pos(x1, y2, z1).color(red, green, blue, alpha).endVertex();
        bufferBuilder.pos(x1, y2, z1).color(red, green, blue, alpha).endVertex();
        bufferBuilder.pos(x1, y2, z2).color(red, green, blue, alpha).endVertex();
        bufferBuilder.pos(x2, y2, z1).color(red, green, blue, alpha).endVertex();
        bufferBuilder.pos(x2, y2, z2).color(red, green, blue, alpha).endVertex();
        bufferBuilder.pos(x2, y2, z2).color(red, green, blue, alpha).endVertex();
        bufferBuilder.pos(x2, y2, z2).color(red, green, blue, alpha).endVertex();
    }

    public static void renderFilledBox(double minX, double minY, double minZ, double maxX, double maxY, double maxZ, double height, float red, float green, float blue, float alpha) {
        Tessellator tessellator = Tessellator.getInstance();

        BufferBuilder bufferbuilder = tessellator.getBuffer();
        bufferbuilder.begin(5, DefaultVertexFormats.POSITION_COLOR);

        addChainedFilledBoxVertices(bufferbuilder, minX, minY, minZ, maxX, maxY + height, maxZ, red, green, blue, alpha);

        tessellator.draw();
    }

    public static void renderBoundingBox(double minX, double minY, double minZ, double maxX, double maxY, double maxZ, double height, float red, float green, float blue, float alpha) {
        Tessellator tessellator = Tessellator.getInstance();

        BufferBuilder bufferbuilder = tessellator.getBuffer();
        bufferbuilder.begin(3, DefaultVertexFormats.POSITION_COLOR);

        drawBoundingBox(bufferbuilder, minX, minY, minZ, maxX, maxY + height, maxZ, red, green, blue, alpha);

        tessellator.draw();
    }

    public static void drawFilledBox(AxisAlignedBB axisAlignedBB, double height, float red, float green, float blue, float alpha) {
        renderFilledBox(axisAlignedBB.minX, axisAlignedBB.minY, axisAlignedBB.minZ, axisAlignedBB.maxX, axisAlignedBB.maxY, axisAlignedBB.maxZ, height, red, green, blue, alpha);
    }

    public static void drawBoundingBox(AxisAlignedBB axisAlignedBB, double height, float red, float green, float blue, float alpha) {
        renderBoundingBox(axisAlignedBB.minX, axisAlignedBB.minY, axisAlignedBB.minZ, axisAlignedBB.maxX, axisAlignedBB.maxY, axisAlignedBB.maxZ, height, red, green, blue, alpha);
    }
}
