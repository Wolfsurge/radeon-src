package cf.radeon.utils.player;

import java.text.DecimalFormat;
import me.wolfsurge.api.util.Globals;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.MathHelper;

public final class MotionUtil implements Globals {
    private static final float roundedForward = getRoundedMovementInput(mc.player.movementInput.moveForward);
    private static final float roundedStrafing = getRoundedMovementInput(mc.player.movementInput.moveStrafe);

    public static boolean isMoving() {
        return (mc.player.moveForward != 0.0f || mc.player.moveStrafing != 0.0f);
    }

    final static DecimalFormat Formatter = new DecimalFormat("#.#");

    public static float getSpeedInKM()
    {
        final double deltaX = mc.player.posX - mc.player.prevPosX;
        final double deltaZ = mc.player.posZ - mc.player.prevPosZ;

        float l_Distance = MathHelper.sqrt(deltaX * deltaX + deltaZ * deltaZ);

        double l_KMH = Math.floor(( l_Distance/1000.0f ) / ( 0.05f/3600.0f ));

        String l_Formatter = Formatter.format(l_KMH);

        if (!l_Formatter.contains("."))
            l_Formatter += ".0";

        return Float.valueOf(l_Formatter);
    }

    public static double calcMoveYaw(float yawIn) {
        float moveForward = roundedForward;

        float strafe = 90.0f * roundedStrafing;

        if (moveForward != 0.0f) {
            strafe *= moveForward * 0.5f;
        } else {
            strafe *= 1.0f;
        }

        float yaw = yawIn - strafe;
        if (moveForward < 0.0f) {
            yaw -= 180.0f;
        } else {
            yaw -= 0.0f;
        }

        return Math.toRadians(yaw);
    }

    private static float getRoundedMovementInput(float input) {
        if (input > 0.0f) {
            input = 1.0f;
        } else if (input < 0.0f) {
            input = -1.0f;
        } else {
            input = 0.0f;
        }

        return input;
    }

    public static void setMoveSpeed(double speed, float stepHeight) {
        Entity currentMover = mc.player.isRiding() ? mc.player.getRidingEntity() : mc.player;

        if (currentMover != null) {
            float forward = mc.player.movementInput.moveForward;
            float strafe = mc.player.movementInput.moveStrafe;
            float yaw = mc.player.rotationYaw;

            if (!MotionUtil.isMoving()) {
                currentMover.motionX = 0;
                currentMover.motionZ = 0;
            }

            else if (forward != 0) {
                if (strafe >= 1) {
                    yaw += (float) (forward > 0 ? -45 : 45);
                    strafe = 0;
                }

                else if (strafe <= -1) {
                    yaw += (float) (forward > 0 ? 45 : -45);
                    strafe = 0;
                }

                if (forward > 0)
                    forward = 1;

                else if (forward < 0)
                    forward = -1;
            }

            double sin = Math.sin(Math.toRadians(yaw + 90));
            double cos = Math.cos(Math.toRadians(yaw + 90));

            currentMover.motionX = (double) forward * speed * cos + (double) strafe * speed * sin;
            currentMover.motionZ = (double) forward * speed * sin - (double) strafe * speed * cos;
            currentMover.stepHeight = stepHeight;

            if (!MotionUtil.isMoving()) {
                currentMover.motionX = 0;
                currentMover.motionZ = 0;
            }
        }
    }

    public static double[] getMoveSpeed(double speed) {
        float forward = mc.player.movementInput.moveForward;
        float strafe = mc.player.movementInput.moveStrafe;
        float yaw = mc.player.rotationYaw;

        if (!MotionUtil.isMoving()) {
            return new double[] { 0, 0 };
        }

        else if (forward != 0) {
            if (strafe >= 1) {
                yaw += (float) (forward > 0 ? -45 : 45);
                strafe = 0;
            }

            else if (strafe <= -1) {
                yaw += (float) (forward > 0 ? 45 : -45);
                strafe = 0;
            }

            if (forward > 0)
                forward = 1;

            else if (forward < 0)
                forward = -1;
        }

        double sin = Math.sin(Math.toRadians(yaw + 90));
        double cos = Math.cos(Math.toRadians(yaw + 90));

        double motionX = (double) forward * speed * cos + (double) strafe * speed * sin;
        double motionZ = (double) forward * speed * sin - (double) strafe * speed * cos;

        return new double[] {motionX, motionZ};
    }

    public static void stopMotion(double fall) {
        Entity currentMover = mc.player.isRiding() ? mc.player.getRidingEntity() : mc.player;

        if (currentMover != null) {
            currentMover.setVelocity(0, fall, 0);
        }
    }

    public static boolean hasMoved() {
        return Math.pow(mc.player.motionX, 2) + Math.pow(mc.player.motionY, 2) + Math.pow(mc.player.motionZ, 2) >= 9.0E-4;
    }
}
