package cf.radeon.utils.block.hole;

import me.wolfsurge.api.util.Globals;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3i;

public class Hole extends Vec3i implements Globals {
    private BlockPos blockPos;
    private boolean tall;
    private HoleTypes HoleType;

    public enum HoleTypes
    {
        None,
        Normal,
        Obsidian,
        Bedrock,
    }

    public Hole(int x, int y, int z, final BlockPos pos, HoleTypes p_Type)
    {
        super(x, y, z);
        blockPos = pos;
        SetHoleType(p_Type);
    }

    public Hole(int x, int y, int z, final BlockPos pos, HoleTypes p_Type, boolean tall)
    {
        super(x, y, z);
        blockPos = pos;
        this.tall = true;
        SetHoleType(p_Type);
    }

    public boolean isTall()
    {
        return tall;
    }

    public BlockPos GetBlockPos()
    {
        return blockPos;
    }

    /**
     * @return the holeType
     */
    public HoleTypes GetHoleType()
    {
        return HoleType;
    }

    /**
     * @param holeType the holeType to set
     */
    public void SetHoleType(HoleTypes holeType)
    {
        HoleType = holeType;
    }




    public static HoleTypes isBlockValid(IBlockState blockState, BlockPos blockPos)
    {
        if (blockState.getBlock() != Blocks.AIR)
            return HoleTypes.None;

        if (mc.world.getBlockState(blockPos.up()).getBlock() != Blocks.AIR)
            return HoleTypes.None;

        if (mc.world.getBlockState(blockPos.up(2)).getBlock() != Blocks.AIR) // ensure the area is
            // tall enough for
            // the player
            return HoleTypes.None;

        if (mc.world.getBlockState(blockPos.down()).getBlock() == Blocks.AIR)
            return HoleTypes.None;

        final BlockPos[] touchingBlocks = new BlockPos[]
                { blockPos.north(), blockPos.south(), blockPos.east(), blockPos.west() };

        boolean l_Bedrock = true;
        boolean l_Obsidian = true;

        int validHorizontalBlocks = 0;
        for (BlockPos touching : touchingBlocks)
        {
            final IBlockState touchingState = mc.world.getBlockState(touching);
            if ((touchingState.getBlock() != Blocks.AIR) && touchingState.isFullBlock())
            {
                validHorizontalBlocks++;

                if (touchingState.getBlock() != Blocks.BEDROCK && l_Bedrock)
                    l_Bedrock = false;

                if (!l_Bedrock)
                {
                    if (touchingState.getBlock() != Blocks.OBSIDIAN && touchingState.getBlock() != Blocks.BEDROCK)
                        l_Obsidian = false;
                }
            }
        }

        if (validHorizontalBlocks < 4)
            return HoleTypes.None;

        if (l_Bedrock)
            return HoleTypes.Bedrock;
        if (l_Obsidian)
            return HoleTypes.Obsidian;

        return HoleTypes.Normal;
    }

}