package cf.radeon.utils.combat;

import me.wolfsurge.api.util.Globals;
import net.minecraft.entity.player.EntityPlayer;

public class CombatUtil implements Globals {

    public static EntityPlayer getTarget(float range) {

        EntityPlayer bestTarget = null;
        float bestRange = 100;

        for(EntityPlayer p: mc.world.playerEntities) {
            if(!isValid(p)) continue;
            if(p.getDistance(mc.player) < bestRange) {
                bestTarget = p;
                bestRange = p.getDistance(mc.player);
            }
        }

        return bestTarget;
    }

    private static boolean isValid(EntityPlayer p) {
        if(p == null) return false;
        if(p == mc.player) return false;
        //TODO
        return true;
    }

}
