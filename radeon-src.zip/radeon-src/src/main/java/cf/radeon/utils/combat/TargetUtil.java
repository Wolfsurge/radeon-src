package cf.radeon.utils.combat;

import cf.radeon.managers.FriendManager;
import me.wolfsurge.api.util.Globals;
import net.minecraft.entity.player.EntityPlayer;

/**
 * @author olliem5
 */

public final class TargetUtil implements Globals {
    public static EntityPlayer getClosestPlayer(double range) {
        if (mc.world.getLoadedEntityList().size() == 0) return null;

        return mc.world.playerEntities.stream()
                .filter(entityPlayer -> entityPlayer != mc.player)
                .filter(entityPlayer -> !entityPlayer.isDead)
                .filter(entityPlayer -> mc.player.getDistance(entityPlayer) <= range)
                .filter(entityPlayer -> !FriendManager.isFriend(entityPlayer.getName()))
                .findFirst()
                .orElse(null);
    }


    public static EntityPlayer getClosestPlayer2(double range) {
        if (mc.world.getLoadedEntityList().size() == 0) return null;

        return mc.world.playerEntities.stream()
                .filter(entityPlayer -> entityPlayer != mc.player)
                .filter(entityPlayer -> entityPlayer.getHealth() > 0.0)
                .filter(entityPlayer -> entityPlayer.ticksExisted > 300)
                .filter(entityPlayer -> !entityPlayer.isDead)
                .filter(entityPlayer -> mc.player.getDistance(entityPlayer) <= range)
                .filter(entityPlayer -> !FriendManager.isFriend(entityPlayer.getName()))
                .findFirst()
                .orElse(null);
    }
}
