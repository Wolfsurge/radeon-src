package cf.radeon.module.modules.combat.crystal;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import me.wolfsurge.api.util.Globals;
import net.minecraft.block.Block;
import net.minecraft.block.BlockAir;
import net.minecraft.block.BlockDeadBush;
import net.minecraft.block.BlockFire;
import net.minecraft.block.BlockLiquid;
import net.minecraft.block.BlockSnow;
import net.minecraft.block.BlockTallGrass;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityEnderCrystal;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.item.EntityXPOrb;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.network.play.client.CPacketAnimation;
import net.minecraft.network.play.client.CPacketEntityAction;
import net.minecraft.network.play.client.CPacketPlayerTryUseItemOnBlock;
import net.minecraft.network.play.client.CPacketEntityAction.Action;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

public class BlockUtil implements Globals {

    private static boolean unshift = false;
    public static final Vec3d[] antiDropOffsetList = new Vec3d[] { new Vec3d(0.0D, -2.0D, 0.0D)};
    public static final Vec3d[] platformOffsetList = new Vec3d[] { new Vec3d(0.0D, -1.0D, 0.0D), new Vec3d(0.0D, -1.0D, -1.0D), new Vec3d(0.0D, -1.0D, 1.0D), new Vec3d(-1.0D, -1.0D, 0.0D), new Vec3d(1.0D, -1.0D, 0.0D)};
    public static final Vec3d[] legOffsetList = new Vec3d[] { new Vec3d(-1.0D, 0.0D, 0.0D), new Vec3d(1.0D, 0.0D, 0.0D), new Vec3d(0.0D, 0.0D, -1.0D), new Vec3d(0.0D, 0.0D, 1.0D)};
    public static final Vec3d[] offsetList = new Vec3d[] { new Vec3d(1.0D, 1.0D, 0.0D), new Vec3d(-1.0D, 1.0D, 0.0D), new Vec3d(0.0D, 1.0D, 1.0D), new Vec3d(0.0D, 1.0D, -1.0D), new Vec3d(0.0D, 2.0D, 0.0D)};
    public static final Vec3d[] antiStepOffsetList = new Vec3d[] { new Vec3d(-1.0D, 2.0D, 0.0D), new Vec3d(1.0D, 2.0D, 0.0D), new Vec3d(0.0D, 2.0D, 1.0D), new Vec3d(0.0D, 2.0D, -1.0D)};
    public static final Vec3d[] antiScaffoldOffsetList = new Vec3d[] { new Vec3d(0.0D, 3.0D, 0.0D)};

    public static boolean placeBlock(BlockPos pos) {
        Block block = BlockUtil.mc.world.getBlockState(pos).getBlock();
        EnumFacing direction = calcSide(pos);

        if (direction == null) {
            return false;
        } else {
            boolean activated = block.onBlockActivated(BlockUtil.mc.world, pos, BlockUtil.mc.world.getBlockState(pos), BlockUtil.mc.player, EnumHand.MAIN_HAND, direction, 0.0F, 0.0F, 0.0F);

            if (activated) {
                BlockUtil.mc.player.connection.sendPacket(new CPacketEntityAction(BlockUtil.mc.player, Action.START_SNEAKING));
            }

            BlockUtil.mc.player.connection.sendPacket(new CPacketPlayerTryUseItemOnBlock(pos.offset(direction), direction.getOpposite(), EnumHand.MAIN_HAND, 0.5F, 0.5F, 0.5F));
            BlockUtil.mc.player.connection.sendPacket(new CPacketAnimation(EnumHand.MAIN_HAND));
            if (activated || BlockUtil.unshift) {
                BlockUtil.mc.player.connection.sendPacket(new CPacketEntityAction(BlockUtil.mc.player, Action.STOP_SNEAKING));
                BlockUtil.unshift = false;
            }

            return true;
        }
    }

    public static EnumFacing calcSide(BlockPos pos) {
        EnumFacing[] aenumfacing = EnumFacing.values();
        int i = aenumfacing.length;

        for (int j = 0; j < i; ++j) {
            EnumFacing side = aenumfacing[j];
            IBlockState offsetState = BlockUtil.mc.world.getBlockState(pos.offset(side));
            boolean activated = offsetState.getBlock().onBlockActivated(BlockUtil.mc.world, pos, offsetState, BlockUtil.mc.player, EnumHand.MAIN_HAND, side, 0.0F, 0.0F, 0.0F);

            if (activated) {
                BlockUtil.mc.getConnection().sendPacket(new CPacketEntityAction(BlockUtil.mc.player, Action.START_SNEAKING));
                BlockUtil.unshift = true;
            }

            if (offsetState.getBlock().canCollideCheck(offsetState, false) && !offsetState.getMaterial().isReplaceable()) {
                return side;
            }
        }

        return null;
    }

    public static boolean canPlaceCrystal(BlockPos blockPos, boolean check, boolean newVer) {
        BlockPos boost = blockPos.up();
        BlockPos boost2 = boost.up();

        if (BlockUtil.mc.world.getBlockState(blockPos).getBlock() != Blocks.BEDROCK && BlockUtil.mc.world.getBlockState(blockPos).getBlock() != Blocks.OBSIDIAN) {
            return false;
        } else if ((BlockUtil.mc.world.getBlockState(boost2).getBlock() == Blocks.AIR || newVer) && BlockUtil.mc.world.getBlockState(boost).getBlock() == Blocks.AIR) {
            Iterator iterator = BlockUtil.mc.world.getEntitiesWithinAABB(Entity.class, new AxisAlignedBB(boost)).iterator();

            Entity entity;

            while (iterator.hasNext()) {
                entity = (Entity) iterator.next();
                if (!entity.isDead && !(entity instanceof EntityEnderCrystal)) {
                    return false;
                }
            }

            if (check) {
                iterator = BlockUtil.mc.world.getEntitiesWithinAABB(Entity.class, new AxisAlignedBB(boost2)).iterator();

                while (iterator.hasNext()) {
                    entity = (Entity) iterator.next();
                    if (!entity.isDead && !(entity instanceof EntityEnderCrystal)) {
                        return false;
                    }
                }
            }

            return true;
        } else {
            return false;
        }
    }

    public static List getUntrappedBlocksExtended(int extension, EntityPlayer player, boolean antiScaffold, boolean antiStep, boolean legs, boolean platform, boolean antiDrop, boolean raytrace) {
        ArrayList placeTargets = new ArrayList();

        if (extension == 1) {
            placeTargets.addAll(targets(player.getPositionVector(), antiScaffold, antiStep, legs, platform, antiDrop, raytrace));
        } else {
            int removeList = 1;
            List blockBlocks = getBlockBlocks(player);
            int vec3d = blockBlocks.size();

            for (int pos = 0; pos < vec3d; ++pos) {
                Vec3d vec3d1 = (Vec3d) blockBlocks.get(pos);

                if (removeList > extension) {
                    break;
                }

                placeTargets.addAll(targets(vec3d1, antiScaffold, antiStep, legs, platform, antiDrop, raytrace));
                ++removeList;
            }
        }

        ArrayList arraylist = new ArrayList();
        Iterator iterator = placeTargets.iterator();

        Vec3d vec3d;

        while (iterator.hasNext()) {
            vec3d = (Vec3d) iterator.next();
            BlockPos blockpos = new BlockPos(vec3d);

            if (isPositionPlaceable(blockpos, raytrace) == -1) {
                arraylist.add(vec3d);
            }
        }

        iterator = arraylist.iterator();

        while (iterator.hasNext()) {
            vec3d = (Vec3d) iterator.next();
            placeTargets.remove(vec3d);
        }

        return placeTargets;
    }

    public static boolean isTrapped(EntityPlayer player, boolean antiScaffold, boolean antiStep, boolean legs, boolean platform, boolean antiDrop) {
        return getUntrappedBlocks(player, antiScaffold, antiStep, legs, platform, antiDrop).size() == 0;
    }

    public static boolean isTrappedExtended(int extension, EntityPlayer player, boolean antiScaffold, boolean antiStep, boolean legs, boolean platform, boolean antiDrop, boolean raytrace) {
        return getUntrappedBlocksExtended(extension, player, antiScaffold, antiStep, legs, platform, antiDrop, raytrace).size() == 0;
    }

    public static List getBlockBlocks(Entity entity) {
        ArrayList vec3ds = new ArrayList();
        AxisAlignedBB bb = entity.getEntityBoundingBox();
        double y = entity.posY;
        double minX = round(bb.minX, 0);
        double minZ = round(bb.minZ, 0);
        double maxX = round(bb.maxX, 0);
        double maxZ = round(bb.maxZ, 0);

        if (minX != maxX) {
            vec3ds.add(new Vec3d(minX, y, minZ));
            vec3ds.add(new Vec3d(maxX, y, minZ));
            if (minZ != maxZ) {
                vec3ds.add(new Vec3d(minX, y, maxZ));
                vec3ds.add(new Vec3d(maxX, y, maxZ));
                return vec3ds;
            }
        } else if (minZ != maxZ) {
            vec3ds.add(new Vec3d(minX, y, minZ));
            vec3ds.add(new Vec3d(minX, y, maxZ));
            return vec3ds;
        }

        vec3ds.add(entity.getPositionVector());
        return vec3ds;
    }

    public static Vec3d[] convertVec3ds(Vec3d vec3d, Vec3d[] input) {
        Vec3d[] output = new Vec3d[input.length];

        for (int i = 0; i < input.length; ++i) {
            output[i] = vec3d.add(input[i]);
        }

        return output;
    }

    public static List targets(Vec3d vec3d, boolean antiScaffold, boolean antiStep, boolean legs, boolean platform, boolean antiDrop, boolean raytrace) {
        ArrayList placeTargets = new ArrayList();

        if (antiDrop) {
            Collections.addAll(placeTargets, convertVec3ds(vec3d, BlockUtil.antiDropOffsetList));
        }

        if (platform) {
            Collections.addAll(placeTargets, convertVec3ds(vec3d, BlockUtil.platformOffsetList));
        }

        if (legs) {
            Collections.addAll(placeTargets, convertVec3ds(vec3d, BlockUtil.legOffsetList));
        }

        Collections.addAll(placeTargets, convertVec3ds(vec3d, BlockUtil.offsetList));
        if (antiStep) {
            Collections.addAll(placeTargets, convertVec3ds(vec3d, BlockUtil.antiStepOffsetList));
        } else {
            List vec3ds = getUnsafeBlocksFromVec3d(vec3d, 2, false);

            if (vec3ds.size() == 4) {
                int size = vec3ds.size();
                int i = 0;

                label34:
                while (i < size) {
                    Vec3d vector = (Vec3d) vec3ds.get(i);
                    BlockPos position = (new BlockPos(vec3d)).add(vector.x, vector.y, vector.z);

                    switch (isPositionPlaceable(position, raytrace)) {
                        case -1:
                        case 1:
                        case 2:
                            ++i;
                            break;

                        case 0:
                        default:
                            break label34;

                        case 3:
                            placeTargets.add(vec3d.add(vector));
                            break label34;
                    }
                }
            }
        }

        if (antiScaffold) {
            Collections.addAll(placeTargets, convertVec3ds(vec3d, BlockUtil.antiScaffoldOffsetList));
        }

        return placeTargets;
    }

    public static boolean canBlockBeSeen(BlockPos pos) {
        return BlockUtil.mc.world.rayTraceBlocks(new Vec3d(BlockUtil.mc.player.posX, BlockUtil.mc.player.posY + (double) BlockUtil.mc.player.getEyeHeight(), BlockUtil.mc.player.posZ), new Vec3d((double) pos.getX(), (double) pos.getY() + (double) BlockUtil.mc.player.getEyeHeight(), BlockUtil.mc.player.posZ), false, true, false) == null;
    }

    public static List getSphere(float radius, boolean ignoreAir) {
        ArrayList sphere = new ArrayList();
        BlockPos pos = new BlockPos(BlockUtil.mc.player.getPositionVector());
        int posX = pos.getX();
        int posY = pos.getY();
        int posZ = pos.getZ();
        int radiuss = (int) radius;

        for (int x = posX - radiuss; (float) x <= (float) posX + radius; ++x) {
            for (int z = posZ - radiuss; (float) z <= (float) posZ + radius; ++z) {
                for (int y = posY - radiuss; (float) y < (float) posY + radius; ++y) {
                    double dist = (double) ((posX - x) * (posX - x) + (posZ - z) * (posZ - z) + (posY - y) * (posY - y));

                    if (dist < (double) (radius * radius)) {
                        BlockPos position = new BlockPos(x, y, z);

                        if (BlockUtil.mc.world.getBlockState(position).getBlock() != Blocks.AIR || !ignoreAir) {
                            sphere.add(position);
                        }
                    }
                }
            }
        }

        return sphere;
    }

    public static List getUnsafeBlocks(Entity entity, int height, boolean floor) {
        return getUnsafeBlocksFromVec3d(entity.getPositionVector(), height, floor);
    }

    public static List getPossibleSides(BlockPos pos) {
        ArrayList facings = new ArrayList();
        EnumFacing[] aenumfacing = EnumFacing.values();
        int i = aenumfacing.length;

        for (int j = 0; j < i; ++j) {
            EnumFacing side = aenumfacing[j];
            BlockPos neighbour = pos.offset(side);

            if (BlockUtil.mc.world.getBlockState(neighbour).getBlock().canCollideCheck(BlockUtil.mc.world.getBlockState(neighbour), false)) {
                IBlockState blockState = BlockUtil.mc.world.getBlockState(neighbour);

                if (!blockState.getMaterial().isReplaceable()) {
                    facings.add(side);
                }
            }
        }

        return facings;
    }

    public static Vec3d[] getHelpingBlocks(Vec3d vec3d) {
        return new Vec3d[] { new Vec3d(vec3d.x, vec3d.y - 1.0D, vec3d.z), new Vec3d(vec3d.x != 0.0D ? vec3d.x * 2.0D : vec3d.x, vec3d.y, vec3d.x != 0.0D ? vec3d.z : vec3d.z * 2.0D), new Vec3d(vec3d.x == 0.0D ? vec3d.x + 1.0D : vec3d.x, vec3d.y, vec3d.x == 0.0D ? vec3d.z : vec3d.z + 1.0D), new Vec3d(vec3d.x == 0.0D ? vec3d.x - 1.0D : vec3d.x, vec3d.y, vec3d.x == 0.0D ? vec3d.z : vec3d.z - 1.0D), new Vec3d(vec3d.x, vec3d.y + 1.0D, vec3d.z)};
    }

    public static BlockPos[] toBlockPos(Vec3d[] vec3ds) {
        BlockPos[] list = new BlockPos[vec3ds.length];

        for (int i = 0; i < vec3ds.length; ++i) {
            list[i] = new BlockPos(vec3ds[i]);
        }

        return list;
    }

    public static Vec3d[] getUnsafeBlockArray(Vec3d vec3d, int height, boolean floor) {
        List list = getUnsafeBlocksFromVec3d(vec3d, height, floor);
        Vec3d[] array = new Vec3d[list.size()];

        return (Vec3d[]) list.toArray(array);
    }

    public static boolean isSafe(Entity entity, int height, boolean floor) {
        return getUnsafeBlocks(entity, height, floor).size() == 0;
    }

    public static boolean areVec3dsAligned(Vec3d vec3d1, Vec3d vec3d2) {
        return areVec3dsAlignedRetarded(vec3d1, vec3d2);
    }

    public static boolean areVec3dsAlignedRetarded(Vec3d vec3d1, Vec3d vec3d2) {
        BlockPos pos1 = new BlockPos(vec3d1);
        BlockPos pos2 = new BlockPos(vec3d2.x, vec3d1.y, vec3d2.z);

        return pos1.equals(pos2);
    }

    public static int isPositionPlaceable(BlockPos pos, boolean entityCheck) {
        Block block = BlockUtil.mc.world.getBlockState(pos).getBlock();

        if (!(block instanceof BlockAir) && !(block instanceof BlockLiquid) && !(block instanceof BlockTallGrass) && !(block instanceof BlockFire) && !(block instanceof BlockDeadBush) && !(block instanceof BlockSnow)) {
            return 0;
        } else {
            List possibleSides;
            int size;
            int i;

            if (entityCheck) {
                possibleSides = BlockUtil.mc.world.getEntitiesWithinAABB(Entity.class, new AxisAlignedBB(pos));
                size = possibleSides.size();

                for (i = 0; i < size; ++i) {
                    Entity side = (Entity) possibleSides.get(i);

                    if (!(side instanceof EntityItem) && !(side instanceof EntityXPOrb)) {
                        return 1;
                    }
                }
            }

            possibleSides = getPossibleSides(pos);
            size = possibleSides.size();

            for (i = 0; i < size; ++i) {
                EnumFacing enumfacing = (EnumFacing) possibleSides.get(i);

                if (canBeClicked(pos.offset(enumfacing))) {
                    return 3;
                }
            }

            return 2;
        }
    }

    public static boolean canBeClicked(BlockPos pos) {
        return BlockUtil.mc.world.getBlockState(pos).getBlock().canCollideCheck(BlockUtil.mc.world.getBlockState(pos), false);
    }

    public static BlockPos getRoundedBlockPos(Entity entity) {
        return new BlockPos(roundVec(entity.getPositionVector(), 0));
    }

    public static Vec3d roundVec(Vec3d vec3d, int places) {
        return new Vec3d(round(vec3d.x, places), round(vec3d.y, places), round(vec3d.z, places));
    }

    public static double round(double value, int places) {
        if (places < 0) {
            throw new IllegalArgumentException();
        } else {
            BigDecimal bd = BigDecimal.valueOf(value);

            bd = bd.setScale(places, RoundingMode.FLOOR);
            return bd.doubleValue();
        }
    }

    public static List getUntrappedBlocks(EntityPlayer player, boolean antiScaffold, boolean antiStep, boolean legs, boolean platform, boolean antiDrop) {
        ArrayList vec3ds = new ArrayList();

        if (!antiStep && getUnsafeBlocks(player, 2, false).size() == 4) {
            vec3ds.addAll(getUnsafeBlocks(player, 2, false));
        }

        for (int i = 0; i < getTrapOffsets(antiScaffold, antiStep, legs, platform, antiDrop).length; ++i) {
            Vec3d vector = getTrapOffsets(antiScaffold, antiStep, legs, platform, antiDrop)[i];
            BlockPos targetPos = (new BlockPos(player.getPositionVector())).add(vector.x, vector.y, vector.z);
            Block block = BlockUtil.mc.world.getBlockState(targetPos).getBlock();

            if (block instanceof BlockAir || block instanceof BlockLiquid || block instanceof BlockTallGrass || block instanceof BlockFire || block instanceof BlockDeadBush || block instanceof BlockSnow) {
                vec3ds.add(vector);
            }
        }

        return vec3ds;
    }

    public static List getUnsafeBlocksFromVec3d(Vec3d pos, int height, boolean floor) {
        ArrayList vec3ds = new ArrayList();
        Vec3d[] avec3d = getOffsets(height, floor);
        int i = avec3d.length;

        for (int j = 0; j < i; ++j) {
            Vec3d vector = avec3d[j];
            BlockPos targetPos = (new BlockPos(pos)).add(vector.x, vector.y, vector.z);
            Block block = BlockUtil.mc.world.getBlockState(targetPos).getBlock();

            if (block instanceof BlockAir || block instanceof BlockLiquid || block instanceof BlockTallGrass || block instanceof BlockFire || block instanceof BlockDeadBush || block instanceof BlockSnow) {
                vec3ds.add(vector);
            }
        }

        return vec3ds;
    }

    public static List getOffsetList(int y, boolean floor) {
        ArrayList offsets = new ArrayList();

        offsets.add(new Vec3d(-1.0D, (double) y, 0.0D));
        offsets.add(new Vec3d(1.0D, (double) y, 0.0D));
        offsets.add(new Vec3d(0.0D, (double) y, -1.0D));
        offsets.add(new Vec3d(0.0D, (double) y, 1.0D));
        if (floor) {
            offsets.add(new Vec3d(0.0D, (double) (y - 1), 0.0D));
        }

        return offsets;
    }

    public static Vec3d[] getOffsets(int y, boolean floor) {
        List offsets = getOffsetList(y, floor);
        Vec3d[] array = new Vec3d[offsets.size()];

        return (Vec3d[]) offsets.toArray(array);
    }

    public static Vec3d[] getTrapOffsets(boolean antiScaffold, boolean antiStep, boolean legs, boolean platform, boolean antiDrop) {
        List offsets = getTrapOffsetsList(antiScaffold, antiStep, legs, platform, antiDrop);
        Vec3d[] array = new Vec3d[offsets.size()];

        return (Vec3d[]) offsets.toArray(array);
    }

    public static List getTrapOffsetsList(boolean antiScaffold, boolean antiStep, boolean legs, boolean platform, boolean antiDrop) {
        ArrayList offsets = new ArrayList(getOffsetList(1, false));

        offsets.add(new Vec3d(0.0D, 2.0D, 0.0D));
        if (antiScaffold) {
            offsets.add(new Vec3d(0.0D, 3.0D, 0.0D));
        }

        if (antiStep) {
            offsets.addAll(getOffsetList(2, false));
        }

        if (legs) {
            offsets.addAll(getOffsetList(0, false));
        }

        if (platform) {
            offsets.addAll(getOffsetList(-1, false));
            offsets.add(new Vec3d(0.0D, -1.0D, 0.0D));
        }

        if (antiDrop) {
            offsets.add(new Vec3d(0.0D, -2.0D, 0.0D));
        }

        return offsets;
    }
}
