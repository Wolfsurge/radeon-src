package cf.radeon.module.modules.hud;

import cf.radeon.Radeon;
import cf.radeon.module.Category;
import cf.radeon.module.Module;
import cf.radeon.module.settings.BooleanSetting;
import cf.radeon.module.settings.ModeSetting;
import cf.radeon.module.settings.NumberSetting;
import cf.radeon.utils.render.ColorUtil;
import cf.radeon.utils.render.RenderUtils2D;
import me.wolfsurge.api.TextUtil;
import cf.radeon.module.modules.client.Colours;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.util.text.TextFormatting;
import org.lwjgl.opengl.GL11;

import java.util.ArrayList;
import java.util.Comparator;

public class ArrayListModule extends Module {

    public static ModeSetting anchor = new ModeSetting("Anchor", "Where the ArrayList is drawn", "B Right", "B Left", "T Left", "T Right");
    public static BooleanSetting rainbowWave = new BooleanSetting("RainbowWave", true);
    public static BooleanSetting outline = new BooleanSetting("Outline", true);
    public static BooleanSetting background = new BooleanSetting("Background", true);
    public static NumberSetting rainbowSpeed = new NumberSetting("Speed", 0.1, 4, 10, 0.1);

    public ArrayListModule() {
        super("ArrayList", "Displays the enabled modules on screen.", Category.HUD, true);
        this.addSettings(anchor, rainbowWave, background, rainbowSpeed);
    }

    public static void drawArrayList() {
        if(Radeon.moduleManager.getModule("ArrayList").isEnabled()) {
            int length = (background.isEnabled() ? 13 : 11);
            ScaledResolution sr = new ScaledResolution(Minecraft.getMinecraft());
            ArrayList<Module> enabledModules = new ArrayList<>();
            for (Module m : Radeon.moduleManager.getModules())
                if (m.isEnabled() && m.visible.isEnabled())
                    enabledModules.add(m);

            if(anchor.is("T Right")) {
                float xOffset = sr.getScaledWidth() - 2;
                float yOffset = 0;
                enabledModules.sort(Comparator.comparingInt(mod -> TextUtil.getStringWidth(getText((Module) mod))).reversed());

                int index = 0;
                int count = 0;
                for(Module m : enabledModules) {
                    int col = rainbowWave.isEnabled() ? ColorUtil.rainbowWave(rainbowSpeed.getFloatValue(), 1, 1, index) : Colours.colourInt;
                    if(background.isEnabled())
                        RenderUtils2D.drawRect(xOffset - 2 - TextUtil.getStringWidth(getText(m)), yOffset, xOffset + 2, yOffset + length, 0x90000000);

                    TextUtil.drawStringWithShadow(getText(m), xOffset - TextUtil.getStringWidth(getText(m)), yOffset, col);
                    yOffset += length;
                    index += 150;
                    count++;
                }
            } else if(anchor.is("B Right")) {
                float xOffset = sr.getScaledWidth() - 2;
                float yOffset = sr.getScaledHeight() - length;
                enabledModules.sort(Comparator.comparingInt(mod -> TextUtil.getStringWidth(getText((Module) mod))).reversed());

                int index = 0;
                int count = 0;
                for(Module m : enabledModules) {
                    int col = rainbowWave.isEnabled() ? ColorUtil.rainbowWave(rainbowSpeed.getFloatValue(), 1, 1, index) : Colours.colourInt;

                    if(background.isEnabled())
                        RenderUtils2D.drawRect(xOffset - 2 - TextUtil.getStringWidth(getText(m)), yOffset, xOffset + 2, yOffset + length, 0x90000000);

                    TextUtil.drawStringWithShadow(getText(m), xOffset - TextUtil.getStringWidth(getText(m)), yOffset + 0.5f, col);
                    yOffset -= length;
                    index += 150;
                    count++;
                }
            } else if(anchor.is("B Left")) {
                float xOffset = 2;
                float yOffset = sr.getScaledHeight() - length;
                enabledModules.sort(Comparator.comparingInt(mod -> TextUtil.getStringWidth(getText((Module) mod))).reversed());

                int index = 0;
                int count = 0;
                for(Module m : enabledModules) {
                    int col = rainbowWave.isEnabled() ? ColorUtil.rainbowWave(rainbowSpeed.getFloatValue(), 1, 1, index) : Colours.colourInt;

                    if(background.isEnabled())
                        RenderUtils2D.drawRect(xOffset - 2, yOffset, xOffset + 2 + TextUtil.getStringWidth(getText(m)), yOffset + length, 0x90000000);

                    TextUtil.drawStringWithShadow(getText(m), xOffset, yOffset + 0.5f, col);
                    yOffset -= length;
                    index += 150;
                    count++;
                }
            } else if(anchor.is("T Left")) {
                float xOffset = 0;
                float yOffset = 0;
                enabledModules.sort(Comparator.comparingInt(mod -> TextUtil.getStringWidth(getText((Module) mod))).reversed());

                int index = 0;
                int count = 0;
                for(Module m : enabledModules) {
                    int col = rainbowWave.isEnabled() ? ColorUtil.rainbowWave(rainbowSpeed.getFloatValue(), 1, 1, index) : Colours.colourInt;

                    if(background.isEnabled())
                        RenderUtils2D.drawRect(xOffset, yOffset, xOffset + TextUtil.getStringWidth(getText(m)) + 2, yOffset + length, 0x90000000);

                    TextUtil.drawStringWithShadow(getText(m), xOffset, yOffset, col);
                    yOffset += length;
                    index += 150;
                    count++;
                }
            }
        }
    }


    public static String getText(Module m) {
        return m.name + (m.getHUDData() == "" ? "" : " " + TextFormatting.GRAY + m.getHUDData());
    }
}
