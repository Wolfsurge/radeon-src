package cf.radeon.module.modules.hud;

import cf.radeon.Radeon;
import cf.radeon.module.Category;
import cf.radeon.module.Module;
import cf.radeon.module.settings.BooleanSetting;

public class HUD extends Module {

	BooleanSetting editorReset = new BooleanSetting("EditorReset", false);
	public static BooleanSetting blur = new BooleanSetting("Blur", true);

	public HUD() {
		super("HUD", "display the hud (required for hud to display!)", Category.HUD);
		this.addSettings(blur);
	}
	
	@Override
	public void onNonToggledUpdate() {
		if(editorReset.isEnabled()) {
			Radeon.hudManager.reset();
			editorReset.toggle();
		}
	}
}
