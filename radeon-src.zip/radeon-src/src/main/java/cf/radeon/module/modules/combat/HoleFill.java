package cf.radeon.module.modules.combat;

import cf.radeon.module.Category;
import cf.radeon.module.Module;
import cf.radeon.module.settings.BooleanSetting;
import cf.radeon.module.settings.ColourPicker;
import cf.radeon.module.settings.ModeSetting;
import cf.radeon.module.settings.NumberSetting;
import cf.radeon.utils.block.BlockUtil;
import cf.radeon.utils.block.hole.HoleUtil;
import cf.radeon.utils.combat.crystal.PlaceUtil;
import cf.radeon.utils.other.ChatUtil;
import cf.radeon.utils.player.InventoryUtil;
import cf.radeon.utils.player.PlayerUtil;
import cf.radeon.utils.render.Colour;
import cf.radeon.utils.render.RenderUtil3D;
import com.mojang.realmsclient.gui.ChatFormatting;
import net.minecraft.block.Block;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.util.math.BlockPos;
import org.lwjgl.opengl.GL11;

import java.util.List;
import java.util.stream.Collectors;

/**
 * @author olliem5
 *
 * TODO: Fix disable setting
 * TODO: Delay
 */

public final class HoleFill extends Module {
    public static final ModeSetting blockMode = new ModeSetting("Block", "The block to fill holes with", "Obsidian", "EnderChest", "Web");
    public static final NumberSetting holeRange = new NumberSetting("Hole Range", "The range to search for holes to fill in", 1, 3, 10, 1);
    public static final BooleanSetting disables = new BooleanSetting("Disables", "Disables the module when there are no holes to fill", true);

    public static final BooleanSetting rotate = new BooleanSetting("Rotate", "Allow for rotations", true);
    public static final ModeSetting rotateMode = new ModeSetting("Mode", "The mode to use for rotations", "Packet", "Legit");

    public static final BooleanSetting renderPlace = new BooleanSetting("Render", "Allows the block placements to be rendered", true);
    public static final ModeSetting renderMode = new ModeSetting("Render Mode", "The type of box to render", "Full", "Outline", "Box");
    public static final NumberSetting outlineWidth = new NumberSetting("Outline Width", "The width of the outline", 1.0, 2.0, 5.0, 0.5);
    public static final ColourPicker renderColour = new ColourPicker("Render Colour", "The colour for the block placements", new Colour(56, 202, 17, 188));

    public HoleFill() {
        super("HoleFill", "Fills holes around you with obsidian", Category.COMBAT);
        this.addSettings(
                blockMode,
                holeRange,
                disables,
                rotate,
                rotateMode,
                renderPlace,
                renderMode,
                outlineWidth,
                renderColour
        );
    }

    private int obsidianSlot;
    private int enderChestSlot;
    private int webSlot;

    private BlockPos blockToFill = null;

    @Override
    public void onEnable() {
        if (nullCheck()) return;

        obsidianSlot = InventoryUtil.getHotbarBlockSlot(Blocks.OBSIDIAN);
        enderChestSlot = InventoryUtil.getHotbarBlockSlot(Blocks.ENDER_CHEST);
        webSlot = InventoryUtil.getHotbarBlockSlot(Blocks.WEB);

        if (getBlockSlot() == -1) {
            ChatUtil.addChatMessage("No " + getBlockText() + ", " + ChatFormatting.RED + "Disabling!");
            this.disable();
        }
    }

    @Override
    public void onDisable() {
        if (nullCheck()) return;

        blockToFill = null;
    }

    public void onUpdate() {
        if (nullCheck()) return;

        List<BlockPos> holesToFill = getHolesToFill();
        BlockPos currentHoleToFill = null;

        for (BlockPos blockPos : holesToFill) {
            if (holesToFill.size() == 0) {
                if (disables.getValue()) {
                    ChatUtil.addChatMessage("No holes to fill, " + ChatFormatting.RED + "Disabling!");
                    this.toggle();
                }

                return;
            }

            currentHoleToFill = blockPos;
        }

        int oldInventorySlot = mc.player.inventory.currentItem;

        if (getBlockSlot() != -1) {
            mc.player.inventory.currentItem = getBlockSlot();
        }

        blockToFill = currentHoleToFill;

        if (mc.player.getHeldItemMainhand().getItem() == Item.getItemFromBlock(getBlockBlock()) && blockToFill != null) {
            PlaceUtil.placeBlock(blockToFill, rotate.getValue(), rotateMode.is("Packet"));
        }

        mc.player.inventory.currentItem = oldInventorySlot;
    }

    private String getBlockText() {
        switch (blockMode.getMode()) {
            case "Obsidian":
                return "Obsidian";
            case "EnderChest":
                return "Ender Chests";
            case "Web":
                return "Webs";
        }

        return "Obsidian";
    }

    private int getBlockSlot() {
        switch (blockMode.getMode()) {
            case "Obsidian":
                return obsidianSlot;
            case "EnderChest":
                return enderChestSlot;
            case "Web":
                return webSlot;
        }

        return obsidianSlot;
    }

    private Block getBlockBlock() {
        switch (blockMode.getMode()) {
            case "Obsidian":
                return Blocks.OBSIDIAN;
            case "EnderChest":
                return Blocks.ENDER_CHEST;
            case "Web":
                return Blocks.WEB;
        }

        return Blocks.OBSIDIAN;
    }

    public List<BlockPos> getHolesToFill() {
        return BlockUtil.getNearbyBlocks(mc.player, holeRange.getFloatValue(), false).stream()
                .filter(blockPos -> HoleUtil.isObsidianHole(blockPos) || HoleUtil.isBedrockHole(blockPos))
                .filter(blockPos -> !PlayerUtil.blockIntersectsPlayer(blockPos))
                .collect(Collectors.toList());
    }

    @Override
    public void onRenderWorld() {
        if (nullCheck()) return;

        if (renderPlace.getValue() && blockToFill != null) {
            GL11.glLineWidth(outlineWidth.getFloatValue());

            RenderUtil3D.draw(blockToFill, !renderMode.is("Outline"), !renderMode.is("Box"), 0, 0, renderColour.getColor());
        }
    }

    @Override
    public String getHUDData() {
        return blockMode.getMode();
    }

    public enum BlockModes {
        Obsidian,
        EnderChest,
        Web
    }
}
