package cf.radeon.module.modules.misc;

import cf.radeon.Radeon;
import cf.radeon.event.impl.TotemPopEvent;
import cf.radeon.module.Category;
import cf.radeon.module.Module;
import cf.radeon.module.modules.combat.AutoCrystal;
import cf.radeon.module.settings.BooleanSetting;
import cf.radeon.module.settings.NumberSetting;
import cf.radeon.module.settings.StringSetting;
import cf.radeon.utils.combat.CooldownUtil;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraftforge.event.entity.living.LivingDeathEvent;

public class AutoEZ extends Module {
	public static final BooleanSetting kills = new BooleanSetting("Kill", "Send message on kill.", true);
	public static final StringSetting kills_message = new StringSetting("Kill Message", "Use USERNAME as the ign", "USERNAME just got rekt by " + Radeon.NAME + " " + Radeon.VERSION);
	public static final NumberSetting kill_range = new NumberSetting("Death range", "the range a player has to be within to send the message.", 1.0, 9.0, 40.0, 1);
	public static final BooleanSetting ac_kill_target = new BooleanSetting("AutoCrystal target death", "Check if the person who died is the ac target.", false);

	public static final BooleanSetting pop = new BooleanSetting("Totem pop", "Send message on totem pop.", true);
	public static final StringSetting pop_message = new StringSetting("Pop Message", "Use USERNAME as the ign", "USERNAME why u popping???");
	public static final NumberSetting pop_range = new NumberSetting("pop range", "the range a player has to be within to send the message.", 1.0, 9.0, 40.0, 1);
	public static final BooleanSetting ac_pop_target = new BooleanSetting("AutoCrystal pop target", "Check if the person popping is the ac target.", false);

	public AutoEZ() {
		super("AutoEZ", "Says a message when u get a kill.", Category.MISC);
		this.addSettings(kills, kills_message, kill_range, ac_kill_target, pop, pop_message, pop_range, ac_pop_target);
	}

	@EventHandler
	private final Listener<TotemPopEvent> totemPopEventListener = new Listener<>(event -> {
		if (nullCheck())
			return;

		if(pop.getValue()) {
			if(!(event.getEntity() instanceof EntityPlayer)) return;

			if(event.getEntity().getDistance(mc.player) > pop_range.getDoubleValue()) {
				return;
			}

			if(ac_pop_target.getValue() && (AutoCrystal.playerTarget != event.getEntity())) {
				return;
			}

			mc.player.sendChatMessage(pop_message.getText().replaceAll("USERNAME", event.getEntity().getName()));
		}
	});
	
	public CooldownUtil timer = new CooldownUtil();

	@EventHandler
	private final Listener<LivingDeathEvent> livingDeathEventListener = new Listener<>(event -> {
		if (nullCheck())
			return;

		if(!timer.passed(50)) return;
		timer.reset();

		if(kills.getValue()) {

			if(!(event.getEntity() instanceof EntityPlayer)) return;

			if(event.getEntity().getDistance(mc.player) > kill_range.getDoubleValue()) {
				return;
			}

			if(ac_kill_target.getValue() && (AutoCrystal.playerTarget != event.getEntity())) {
				return;
			}


			String m = kills_message.getText().replaceAll("USERNAME", event.getEntity().getName());
			mc.player.sendChatMessage(m);
		}
	});
}
