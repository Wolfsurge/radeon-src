package cf.radeon.module.modules.movement;

import cf.radeon.event.impl.PacketEvent;
import cf.radeon.module.Category;
import cf.radeon.module.Module;
import cf.radeon.module.settings.BooleanSetting;
import cf.radeon.module.settings.NumberSetting;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.minecraft.network.play.server.SPacketEntityVelocity;
import net.minecraft.network.play.server.SPacketExplosion;

/**
 * @author olliem5
 */

public final class Velocity extends Module {
    public static final BooleanSetting velocity = new BooleanSetting("Velocity", "Allows for modification of player velocity", true);
    public static final NumberSetting velocityHorizontal = new NumberSetting("Horizontal", "Horizontal velocity knockback to take", 0.0f, 0.0f, 100.0f, 1);
    public static final NumberSetting velocityVeritcal = new NumberSetting("Vertical", "Vertical velocity knockback to take", 0.0f, 0.0f, 100.0f, 1);

    public static final BooleanSetting explosions = new BooleanSetting("Explosions", "Allows for modification of explosion velocity", true);
    public static final NumberSetting explosionsHorizontal = new NumberSetting("Horizontal", "Horizontal explosion knockback to take", 0.0f, 0.0f, 100.0f, 1);
    public static final NumberSetting explosionsVeritcal = new NumberSetting("Vertical", "Vertical explosion knockback to take", 0.0f, 0.0f, 100.0f, 1);

    public static final BooleanSetting noPush = new BooleanSetting("No Push", "Allows for modification of knockback via pushing", true);
    public static final BooleanSetting noPushLiquids = new BooleanSetting("Liquids", "Makes liquids not able to push you", true);
    public static final BooleanSetting noPushBlocks = new BooleanSetting("Blocks", "Makes blocks not be able to push you", true);

    public Velocity() {
        super("Velocity", "Modifies the knockback that you take", Category.MOVEMENT);
        this.addSettings(
                velocity,
                velocityHorizontal,
                velocityVeritcal,
                explosions,
                explosionsHorizontal,
                explosionsVeritcal,
                noPush,
                noPushLiquids,
                noPushBlocks
        );
    }

    @EventHandler
    private final Listener<PacketEvent.Receive> receiveListener = new Listener<>(event -> {
        if (nullCheck()) return;

        if (event.getPacket() instanceof SPacketEntityVelocity && velocity.getValue()) {
            SPacketEntityVelocity sPacketEntityVelocity = (SPacketEntityVelocity) event.getPacket();

            if (sPacketEntityVelocity.getEntityID() == mc.player.entityId) {
                if (velocityHorizontal.getFloatValue() == 0.0f && velocityVeritcal.getFloatValue() == 0.0f) {
                    event.cancel();
                } else {
                    sPacketEntityVelocity.motionX *= velocityHorizontal.getFloatValue() / 100f;
                    sPacketEntityVelocity.motionY *= velocityVeritcal.getFloatValue() / 100f;
                    sPacketEntityVelocity.motionZ *= velocityHorizontal.getFloatValue() / 100f;
                }
            }
        }

        if (event.getPacket() instanceof SPacketExplosion && explosions.getValue()) {
            SPacketExplosion sPacketExplosion = (SPacketExplosion) event.getPacket();

            if (explosionsHorizontal.getFloatValue() == 0.0f && explosionsVeritcal.getFloatValue() == 0.0f) {
                event.cancel();
            } else {
                sPacketExplosion.motionX *= explosionsHorizontal.getFloatValue() / 100f;
                sPacketExplosion.motionY *= explosionsVeritcal.getFloatValue() / 100f;
                sPacketExplosion.motionZ *= explosionsHorizontal.getFloatValue() / 100f;
            }
        }
    });

    @Override
    public String getHUDData() {
        return "H% " + velocityHorizontal.getIntValue() + " - " + explosionsHorizontal.getIntValue() + ", " + "V% " + velocityVeritcal.getIntValue() + " - " + explosionsVeritcal.getIntValue();
    }
}
