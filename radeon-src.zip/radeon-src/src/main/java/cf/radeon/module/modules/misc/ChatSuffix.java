package cf.radeon.module.modules.misc;

import cf.radeon.event.impl.PacketEvent;
import cf.radeon.managers.CommandManager;
import cf.radeon.module.Category;
import cf.radeon.module.Module;
import cf.radeon.module.settings.BooleanSetting;
import cf.radeon.module.settings.StringSetting;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.minecraft.network.play.client.CPacketChatMessage;

public final class ChatSuffix extends Module {

	public static final StringSetting msg = new StringSetting("MSG", "What the suffix will be", "Radeon Client");
	public static final StringSetting seperator = new StringSetting("Seperator", "What will seperate the suffix from the message", " | ");
	public static final BooleanSetting green = new BooleanSetting("Green", "Makes your suffix green", false);
	public static final BooleanSetting blue = new BooleanSetting("Blue", "Makes your suffix blue", false);

	public ChatSuffix() {
		super("ChatSuffix", "Cool feature", Category.MISC);
		this.addSettings(msg, seperator, green, blue);
	}

	@EventHandler
	public final Listener<PacketEvent.Send> sendListener = new Listener<>(event -> {
		if (nullCheck())
			return;

		if (event.getPacket() instanceof CPacketChatMessage) {
			CPacketChatMessage cPacketChatMessage = (CPacketChatMessage) event.getPacket();

			String string = cPacketChatMessage.getMessage();

			if (string.startsWith(CommandManager.prefix) || string.startsWith("/") || string.startsWith("#") | string.startsWith("%") || string.startsWith(".") || string.startsWith("*"))
				return;

			String suffix = seperator.getText() + msg.getText();

			if (blue.getValue()) {
				string += " `" + suffix;
			} else if (green.getValue()) {
				string += " >" + suffix;
			} else {
				string += suffix;
			}

			if (string.length() >= 256) {
				string = string.substring(0, 256);
			}

			cPacketChatMessage.message = string;
		}
	});
}
