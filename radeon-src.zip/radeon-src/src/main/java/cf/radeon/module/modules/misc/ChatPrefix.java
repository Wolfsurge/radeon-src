package cf.radeon.module.modules.misc;

import cf.radeon.event.impl.PacketEvent;
import cf.radeon.managers.CommandManager;
import cf.radeon.module.Category;
import cf.radeon.module.Module;
import cf.radeon.module.settings.StringSetting;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.minecraft.network.play.client.CPacketChatMessage;

public class ChatPrefix extends Module {

    StringSetting prefix = new StringSetting("Prefix", "What to put before your messages", ">>> ");

    public ChatPrefix() {
        super("ChatPrefix", "Puts something before your messages", Category.MISC);
        this.addSettings(prefix);
    }

    @EventHandler
    private final Listener<PacketEvent.Send> sendListener = new Listener<>(event -> {
       if(event.getPacket() instanceof CPacketChatMessage) {
           CPacketChatMessage packet = (CPacketChatMessage) event.getPacket();
           String string = packet.getMessage();

           if (string.startsWith(CommandManager.prefix) || string.startsWith("/") || string.startsWith("#") | string.startsWith("%") || string.startsWith(".") || string.startsWith("*"))
               return;

           String newM = prefix.getText() + string;
           packet.message = newM;
       }
    });

}
