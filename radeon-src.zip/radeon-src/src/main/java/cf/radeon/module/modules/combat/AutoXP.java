package cf.radeon.module.modules.combat;

import java.util.HashMap;
import java.util.Map;

import cf.radeon.module.Category;
import cf.radeon.module.Module;
import cf.radeon.module.settings.NumberSetting;
import cf.radeon.utils.other.ChatUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.inventory.ClickType;
import net.minecraft.item.ItemExpBottle;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3i;
import net.minecraft.world.World;


public class AutoXP extends Module {

    public static final NumberSetting delay = new NumberSetting("Delay", "The delay.", 12, 16, 24, 1);
    public static final NumberSetting dmg = new NumberSetting("Damage %", "The damage to mend at", 12, 60, 90, 1);


    private int mostDamagedSlot;
    private int mostDamage;
    private int lastSlot;
    private int counter;
    private int armorCount;
    private int wait;
    private int[] slots;
    private boolean shouldThrow;
    private boolean shouldArmor;

    public AutoXP() {
        super("AutoMend", "Automatically mends your armor.", Category.COMBAT);
        this.addSettings(delay, dmg);
    }


    @Override
    public void onEnable() {
        if(nullCheck()) return;
        this.mostDamage = -1;
        this.mostDamagedSlot = -1;
        this.shouldArmor = false;
        this.armorCount = 0;
        this.slots = new int[3];
        this.wait = 0;
        this.takeOffArmor();
    }

    @Override
    public void onDisable() {
        if(nullCheck()) return;
    }

    public static void lookAtBlock(final BlockPos blockToLookAt) {
        rotate(calculateLookAt(blockToLookAt.getX(), blockToLookAt.getY(), blockToLookAt.getZ(), (EntityPlayer)Minecraft.getMinecraft().player));
    }


    public static double[] calculateLookAt(final double px, final double py, final double pz, final EntityPlayer me) {
        double dirx = me.posX - px;
        double diry = me.posY - py;
        double dirz = me.posZ - pz;
        final double len = Math.sqrt(dirx * dirx + diry * diry + dirz * dirz);
        dirx /= len;
        diry /= len;
        dirz /= len;
        double pitch = Math.asin(diry);
        double yaw = Math.atan2(dirz, dirx);
        pitch = pitch * 180.0 / 3.141592653589793;
        yaw = yaw * 180.0 / 3.141592653589793;
        yaw += 90.0;
        return new double[] { yaw, pitch };
    }


    public static void rotate(final float yaw, final float pitch) {
        Minecraft.getMinecraft().player.rotationYaw = yaw;
        Minecraft.getMinecraft().player.rotationPitch = pitch;
    }

    public static void rotate(final double[] rotations) {
        Minecraft.getMinecraft().player.rotationYaw = (float)rotations[0];
        Minecraft.getMinecraft().player.rotationPitch = (float)rotations[1];
    }

    @Override
    public void onUpdate() {
        if (nullCheck() || mc.player == null || !this.isEnabled() || mc.currentScreen instanceof GuiContainer) {
            return;
        }
        if (this.shouldThrow) {
            lookAtBlock(new BlockPos((Vec3i)mc.player.getPosition().add(0, -1, 0)));
            mc.player.inventory.currentItem = this.findXP();
            mc.playerController.processRightClick((EntityPlayer)mc.player, (World)mc.world, EnumHand.MAIN_HAND);
            if (this.isRepaired() || this.counter > 40) {
                this.shouldThrow = false;
                this.shouldArmor = true;
                mc.player.inventory.currentItem = this.lastSlot;
                ChatUtil.addChatMessage("Done!");
            }
            ++this.counter;
        }
        if (this.shouldArmor) {
            if (this.wait >= this.delay.getIntValue()) {
                this.wait = 0;
                mc.playerController.windowClick(0, this.slots[this.armorCount], 0, ClickType.QUICK_MOVE, (EntityPlayer)mc.player);
                mc.playerController.updateController();
                ++this.armorCount;
                if (this.armorCount > 2) {
                    this.armorCount = 0;
                    this.shouldArmor = false;
                    this.disable();
                    return;
                }
            }
            ++this.wait;
        }
    }

    public int getMostDamagedSlot() {
        for (final Map.Entry<Integer, ItemStack> armorSlot : getArmor().entrySet()) {
            final ItemStack stack = armorSlot.getValue();
            if (stack.getItemDamage() > this.mostDamage) {
                this.mostDamage = stack.getItemDamage();
                this.mostDamagedSlot = armorSlot.getKey();
            }
        }
        return this.mostDamagedSlot;
    }

    public boolean isRepaired() {
        for (final Map.Entry<Integer, ItemStack> armorSlot : getArmor().entrySet()) {
            final ItemStack stack = armorSlot.getValue();
            if (armorSlot.getKey() == this.mostDamagedSlot) {
                final float percent = dmg.getIntValue() / 100.0f;
                final int dam = Math.round(stack.getMaxDamage() * percent);
                final int goods = stack.getMaxDamage() - stack.getItemDamage();
                return dam <= goods;
            }
        }
        return false;
    }

    public int findXP() {
        this.lastSlot = mc.player.inventory.currentItem;
        int slot = -1;
        for (int i = 0; i < 9; ++i) {
            final ItemStack stack = mc.player.inventory.getStackInSlot(i);
            if (stack != ItemStack.EMPTY && stack.getItem() instanceof ItemExpBottle) {
                slot = i;
                break;
            }
        }
        if (slot == -1) {
            ChatUtil.addChatMessage("You dont have XP in your hotbar.");
            this.disable();
            return 1;
        }
        return slot;
    }

    public boolean isSpace() {
        int spareSlots = 0;
        for (final Map.Entry<Integer, ItemStack> invSlot : getInventory().entrySet()) {
            final ItemStack stack = invSlot.getValue();
            if (stack.getItem() == Items.AIR) {
                this.slots[spareSlots] = invSlot.getKey();
                if (++spareSlots > 2) {
                    return true;
                }
                continue;
            }
        }
        return false;
    }

    public void takeOffArmor() {
        if (this.isSpace()) {
            this.getMostDamagedSlot();
            if (this.mostDamagedSlot != -1) {
                for (final Map.Entry<Integer, ItemStack> armorSlot : getArmor().entrySet()) {
                    if (armorSlot.getKey() != this.mostDamagedSlot) {
                        mc.playerController.windowClick(0, (int)armorSlot.getKey(), 0, ClickType.QUICK_MOVE, (EntityPlayer)mc.player);
                    }
                }
                this.counter = 0;
                this.shouldThrow = true;
                return;
            }
        }
        ChatUtil.addChatMessage("You need at least 3 inventory slots open!");
        this.disable();
    }

    private Map<Integer, ItemStack> getInventory() {
        return getInventorySlots(9, 44);
    }

    private Map<Integer, ItemStack> getArmor() {
        return getInventorySlots(5, 8);
    }

    private Map<Integer, ItemStack> getInventorySlots(int current, final int last) {
        final Map<Integer, ItemStack> fullInventorySlots = new HashMap<Integer, ItemStack>();
        while (current <= last) {
            fullInventorySlots.put(current, (ItemStack)mc.player.inventoryContainer.getInventory().get(current));
            ++current;
        }
        return fullInventorySlots;
    }
}
