package cf.radeon.module.modules.render;

import cf.radeon.module.Category;
import cf.radeon.module.Module;
import cf.radeon.module.settings.BooleanSetting;
import cf.radeon.module.settings.NumberSetting;
import net.minecraftforge.client.event.EntityViewRenderEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

/**
 * @author olliem5
 *
 * TODO: Make the FOV reset
 */

public final class CustomFOV extends Module {
    public static final BooleanSetting normalFOV = new BooleanSetting("Normal FOV", "Allows for modification of your normal FOV", true);
    public static final NumberSetting normalFOVAmount = new NumberSetting("Normal FOV Amount", "The value to set your normal FOV to", 0, 120, 250, 1);

    public static final BooleanSetting itemFOV = new BooleanSetting("Item FOV", "Allows for modification of your item FOV", true);
    public static final NumberSetting itemFOVAmount = new NumberSetting("Item FOV Amount", "The value to set your item FOV to", 0, 120, 250, 1);

    public CustomFOV() {
        super("CustomFOV", "Allows you to change your normal and item fov", Category.RENDER);
        this.addSettings(
                normalFOV,
                normalFOVAmount,
                itemFOV,
                itemFOVAmount
        );
    }

    public void onUpdate() {
        if (nullCheck()) return;

        if (normalFOV.getValue()) {
            mc.gameSettings.fovSetting = normalFOVAmount.getFloatValue();
        }
    }

    @SubscribeEvent
    public void onFOVModify(EntityViewRenderEvent.FOVModifier event) {
        if (nullCheck()) return;

        if (itemFOV.getValue()) {
            event.setFOV(itemFOVAmount.getFloatValue());
        }
    }
}
