package cf.radeon.module.modules.combat;

import cf.radeon.event.impl.PacketEvent;
import cf.radeon.module.Category;
import cf.radeon.module.Module;
import cf.radeon.module.settings.BooleanSetting;
import cf.radeon.module.settings.ModeSetting;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.minecraft.entity.item.EntityEnderCrystal;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.network.play.client.CPacketUseEntity;

import java.util.Objects;

/**
 * @author olliem5
 * @author linustouchtips
 */

public final class Criticals extends Module {
    public static final ModeSetting mode = new ModeSetting("Mode", "The way of achieving critical hits", "Bypass", "Packet", "Jump", "MiniJump");
    public static final BooleanSetting workOnCrystals = new BooleanSetting("Work on Crystals", "Allow critical attacks to happen when you hit a crystal", false);
    public static final BooleanSetting cancelInAir = new BooleanSetting("Cancel in Air", "Allow critical attacks to happen when you are in the air", false);
    public static final BooleanSetting cancelInLiquid = new BooleanSetting("Cancel in Liquid", "Allow critical attacks to happen when you are in liquid", false);

    public Criticals() {
        super("Criticals", "Makes every attack a critical hit", Category.COMBAT);
        this.addSettings(
                mode,
                workOnCrystals,
                cancelInAir,
                cancelInLiquid
        );
    }

    @EventHandler
    private final Listener<PacketEvent.Send> sendListener = new Listener<>(event -> {
        if (nullCheck()) return;

        if (event.getPacket() instanceof CPacketUseEntity) {
            CPacketUseEntity cPacketUseEntity = (CPacketUseEntity) event.getPacket();

            if (cPacketUseEntity.getAction() == CPacketUseEntity.Action.ATTACK && mc.player.onGround) {
                if (cPacketUseEntity.getEntityFromWorld(mc.world) instanceof EntityEnderCrystal && !workOnCrystals.getValue()) return;

                if (!mc.player.onGround && cancelInAir.getValue()) return;

                if (mc.player.inWater || mc.player.isInLava() && cancelInLiquid.getValue()) return;

                switch (mode.getMode()) {
                    case "Packet":
                        mc.player.connection.sendPacket(new CPacketPlayer.Position(mc.player.posX, mc.player.posY + 0.1f, mc.player.posZ, false));
                        mc.player.connection.sendPacket(new CPacketPlayer.Position(mc.player.posX, mc.player.posY, mc.player.posZ, false));
                        mc.player.connection.sendPacket(new CPacketPlayer());
                        mc.player.onCriticalHit(Objects.requireNonNull(cPacketUseEntity.getEntityFromWorld(mc.world)));
                        break;
                    case "Bypass":
                        mc.player.connection.sendPacket(new CPacketPlayer.Position(mc.player.posX, mc.player.posY + 0.1625, mc.player.posZ, false));
                        mc.player.connection.sendPacket(new CPacketPlayer.Position(mc.player.posX, mc.player.posY, mc.player.posZ, false));
                        mc.player.connection.sendPacket(new CPacketPlayer.Position(mc.player.posX, mc.player.posY + 4.0E-6, mc.player.posZ, false));
                        mc.player.connection.sendPacket(new CPacketPlayer.Position(mc.player.posX, mc.player.posY, mc.player.posZ, false));
                        mc.player.connection.sendPacket(new CPacketPlayer.Position(mc.player.posX, mc.player.posY + 1.0E-6, mc.player.posZ, false));
                        mc.player.connection.sendPacket(new CPacketPlayer.Position(mc.player.posX, mc.player.posY, mc.player.posZ, false));
                        mc.player.connection.sendPacket(new CPacketPlayer());
                        mc.player.onCriticalHit(Objects.requireNonNull(cPacketUseEntity.getEntityFromWorld(mc.world)));
                        break;
                    case "Jump":
                        mc.player.jump();
                        break;
                    case "MiniJump":
                        mc.player.jump();
                        mc.player.motionY = 0.25;
                        break;
                }
            }
        }
    });

    @Override
    public String getHUDData() {
        return mode.getMode();
    }
}
