package cf.radeon.module.modules.misc;

import cf.radeon.module.Category;
import cf.radeon.module.Module;
import cf.radeon.module.settings.BooleanSetting;
import cf.radeon.module.settings.ColourPicker;
import cf.radeon.module.settings.ModeSetting;
import cf.radeon.module.settings.NumberSetting;
import cf.radeon.utils.block.BlockUtil;
import cf.radeon.utils.block.PlacementUtil;
import cf.radeon.utils.other.RaytraceUtil;
import cf.radeon.utils.player.InventoryUtil;
import cf.radeon.utils.player.RotationUtil;
import cf.radeon.utils.render.RenderUtil3D;
import com.mojang.realmsclient.gui.ChatFormatting;
import net.minecraft.block.Block;
import net.minecraft.block.BlockEnderChest;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemPickaxe;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.network.play.client.CPacketPlayerTryUseItemOnBlock;
import net.minecraft.util.EnumActionResult;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.Rotation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec2f;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.input.Mouse;

import java.awt.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
* @author Wolfsurge
* @since 16/01/2022
*/

public class EChestFarmer extends Module {

    NumberSetting range = new NumberSetting("Range", "The range to search for Ender Chests", 1, 4, 7, 1);

    ModeSetting logic = new ModeSetting("Logic", "What logic to use", "P->B", "B->P");
    BooleanSetting place = new BooleanSetting("Place", "Whether to place Ender Chests", true);
    BooleanSetting antiAirPlace = new BooleanSetting("AntiAirPlace", "Do not place over air and water", true);


    BooleanSetting render = new BooleanSetting("Render", "Render an outline around the ender chests", true);
    ModeSetting renderMode = new ModeSetting("Render Mode", "The type of box to render", "Full", "Outline", "Box");
    NumberSetting renderHeight = new NumberSetting("Box Height", "The height of the box", -1.0, -0.7, 0.0, 0.1);
    NumberSetting outlineHeight = new NumberSetting("Outline Height", "The height of the outline", -1.0, -0.7, 0.0, 0.1);
    ColourPicker renderColour = new ColourPicker("Render Colour", "The colour for obsidian holes", new Color(234, 37, 58, 169));

    public EChestFarmer() {
        super("EChestFarmer", "Mines Ender Chests", Category.MISC);
        this.addSettings(range);
        this.addSettings(logic, place, antiAirPlace);
        this.addSettings(render, renderMode, renderHeight, outlineHeight, renderColour);
    }

    @Override
    public void onEnable() {
        PlacementUtil.onEnable();
    }

    @Override
    public void onDisable() {
        PlacementUtil.onDisable();
        mc.gameSettings.keyBindAttack.pressed = false;
        mc.gameSettings.keyBindUseItem.pressed = false;
    }

    @Override
    public void onRenderWorld() {
        if(nullCheck()) return;

        for(BlockPos pos : getEChests()) {
            RenderUtil3D.draw(pos, renderMode.getMode() != "Outline", renderMode.getMode() != "Box", renderHeight.getFloatValue(), outlineHeight.getFloatValue(), renderColour.getValue());
        }
    }

    @Override
    public void onUpdate() {
        if(nullCheck())
            return;

        switch (logic.getMode()) {
            case "P->B":
                if(place.isEnabled())
                    place();
                breakk();
                break;
            case "B->P":
                breakk();
                if(place.isEnabled())
                    place();
                break;
        }
    }

    void place() {
        if(getEChests().size() < 1) {
            mc.gameSettings.keyBindAttack.pressed = Mouse.isButtonDown(mc.gameSettings.keyBindAttack.getKeyCode());

            if(InventoryUtil.getBlockInHotbar(Blocks.ENDER_CHEST) > -1) {
                mc.gameSettings.keyBindUseItem.pressed = false;

                InventoryUtil.switchToSlot(new ItemBlock(Blocks.ENDER_CHEST));

                BlockPos plrPos = mc.player.getPosition();
                Vec3d placeVec = new Vec3d(plrPos.x + 1, plrPos.y, plrPos.z);

                switch (MathHelper.floor(mc.player.rotationYaw + 8.0f / 360.0f + 0.5)) {
                    case 0:
                    case 1:
                        placeVec = new Vec3d(plrPos.x, plrPos.y, plrPos.z + 1);
                    case 2:
                    case 3:
                        placeVec = new Vec3d(plrPos.x - 1, plrPos.y, plrPos.z);
                    case 4:
                    case 5:
                        placeVec = new Vec3d(plrPos.x, plrPos.y, plrPos.z - 1);
                    case 6:
                    case 7:
                        placeVec = new Vec3d(plrPos.x + 1, plrPos.y, plrPos.z);
                }

                BlockPos placePos = new BlockPos(placeVec);

                List<Block> shulkerList = new ArrayList<>();
                shulkerList.addAll(Arrays.asList(Blocks.WHITE_SHULKER_BOX,
                        Blocks.ORANGE_SHULKER_BOX,
                        Blocks.MAGENTA_SHULKER_BOX,
                        Blocks.LIGHT_BLUE_SHULKER_BOX,
                        Blocks.YELLOW_SHULKER_BOX,
                        Blocks.LIME_SHULKER_BOX,
                        Blocks.PINK_SHULKER_BOX,
                        Blocks.GRAY_SHULKER_BOX,
                        Blocks.SILVER_SHULKER_BOX,
                        Blocks.CYAN_SHULKER_BOX,
                        Blocks.PURPLE_SHULKER_BOX,
                        Blocks.BLUE_SHULKER_BOX,
                        Blocks.BROWN_SHULKER_BOX,
                        Blocks.GREEN_SHULKER_BOX,
                        Blocks.RED_SHULKER_BOX,
                        Blocks.BLACK_SHULKER_BOX
                        ));

                if(antiAirPlace.isEnabled() && (getBlock(placePos.down()) == Blocks.AIR || getBlock(placePos.down()) == Blocks.WATER || getBlock(placePos.down()) == Blocks.FLOWING_WATER || getBlock(placePos.down()) == Blocks.FLOWING_LAVA || getBlock(placePos.down()) == Blocks.LAVA
                        || getBlock(placePos.down()) == Blocks.CHEST || getBlock(placePos.down()) == Blocks.ENDER_CHEST || shulkerList.contains(getBlock(placePos.down()))))
                    return;

                Vec2f rotation = RotationUtil.getRotationTo(placeVec);
                mc.player.rotationYaw = rotation.x;
                mc.player.rotationPitch = rotation.y;

                InventoryUtil.switchToSlot(Blocks.ENDER_CHEST);
                EnumActionResult action = mc.playerController.processRightClickBlock(mc.player, mc.world, placePos, EnumFacing.DOWN, placeVec, EnumHand.MAIN_HAND);
            }
        }
    }

    void breakk() {
        if(!getEChests().isEmpty()) {
            BlockPos pos = getEChests().get(0);
            Vec3d vec = new Vec3d(pos.x + 0.5, pos.y + 0.5, pos.z + 0.5);
            Vec2f rotation = RotationUtil.getRotationTo(vec);

            if(mc.world.rayTraceBlocks(new Vec3d(mc.player.posX, mc.player.posY + mc.player.getEyeHeight(), mc.player.posZ), vec, false, true, false) == null)
                return;

            mc.player.rotationYaw = rotation.x;
            mc.player.rotationPitch = rotation.y;

            InventoryUtil.switchToSlot(ItemPickaxe.class);
            mc.gameSettings.keyBindAttack.pressed = InventoryUtil.isHolding(Items.DIAMOND_PICKAXE);
        } else {
            mc.gameSettings.keyBindAttack.pressed = Mouse.isButtonDown(mc.gameSettings.keyBindAttack.getKeyCode());
        }
    }

    List<BlockPos> getEChests() {
        List<BlockPos> toReturn = new ArrayList<>();

        for(BlockPos pos : BlockUtil.getNearbyBlocks(mc.player, range.getDoubleValue(), false)) {
            if(getBlock(pos) instanceof BlockEnderChest && pos.y == mc.player.getPosition().y) toReturn.add(pos);
        }

        return toReturn;
    }

    Block getBlock(BlockPos posIn) {
        return mc.world.getBlockState(posIn).getBlock();
    }

}
