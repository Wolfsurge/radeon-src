package cf.radeon.module.modules.combat;

import cf.radeon.module.Category;
import cf.radeon.module.Module;
import cf.radeon.module.settings.BooleanSetting;
import cf.radeon.module.settings.ColourPicker;
import cf.radeon.module.settings.ModeSetting;
import cf.radeon.module.settings.NumberSetting;
import cf.radeon.utils.combat.crystal.PlaceUtil;
import cf.radeon.utils.other.ChatUtil;
import cf.radeon.utils.player.InventoryUtil;
import cf.radeon.utils.player.PlayerUtil;
import cf.radeon.utils.render.Colour;
import cf.radeon.utils.render.RenderUtil3D;
import com.mojang.realmsclient.gui.ChatFormatting;
import net.minecraft.block.Block;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.opengl.GL11;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * @author olliem5
 */

public final class Surround extends Module {

    public static final ModeSetting placeMode = new ModeSetting("Place", "The style of surround to place", "Full", "Standard", "AntiCity");
    public static final ModeSetting disableMode = new ModeSetting("Disable", "When to disable the module", "Finish", "Jump", "Never");
    public static final ModeSetting blockMode = new ModeSetting("Block", "The block to surround with", "Obsidian", "EnderChest");

    public static final NumberSetting blocksPerTick = new NumberSetting("BPT", "Blocks per tick to place", 1, 1, 10, 1);
    public static final BooleanSetting centerPlayer = new BooleanSetting("Center Player", "Center the player on the block for better placements", true);

    public static final BooleanSetting rotate = new BooleanSetting("Rotate", "Allow for rotations", true);
    public static final ModeSetting rotateMode = new ModeSetting("Mode", "The mode to use for rotations", "Packet", "Legit");

    public static final BooleanSetting timeout = new BooleanSetting("Timeout", "Allows the module to timeout and disable", true);
    public static final NumberSetting timeoutTicks = new NumberSetting("Ticks", "Ticks that have to pass to timeout", 1.0, 15.0, 20.0, 1);

    public static final BooleanSetting renderPlace = new BooleanSetting("Render", "Allows the block placements to be rendered", true);
    public static final ModeSetting renderMode = new ModeSetting("Render Mode", "The type of box to render", "Full", "Outline", "Box");
    public static final NumberSetting outlineWidth = new NumberSetting("Outline Width", "The width of the outline", 1.0, 2.0, 5.0, 0.5);
    public static final ColourPicker renderColour = new ColourPicker("Render Colour", "The colour for the block placements", new Colour(182, 40, 226, 186));

    public Surround() {
        super("Surround", "Surrounds you with obsidian to minimize crystal damage.", Category.COMBAT);
        this.addSettings(
                placeMode,
                disableMode,
                blockMode,
                blocksPerTick,
                centerPlayer,
                rotate,
                timeout,
                renderPlace
        );
    }

    private int obsidianSlot;
    private int enderChestSlot;
    private int blocksPlaced = 0;

    private boolean hasPlaced = false;

    private Vec3d center = Vec3d.ZERO;

    private BlockPos renderBlock = null;

    @Override
    public void onEnable() {
        if (nullCheck()) return;

        obsidianSlot = InventoryUtil.getHotbarBlockSlot(Blocks.OBSIDIAN);
        enderChestSlot = InventoryUtil.getHotbarBlockSlot(Blocks.ENDER_CHEST);

        if (getBlockSlot() == -1) {
            ChatUtil.addChatMessage("No " + getBlockText() + ", " + ChatFormatting.RED + "Disabling!");
            this.disable();
        } else {
            if (centerPlayer.getValue()) {
                mc.player.motionX = 0.0;
                mc.player.motionZ = 0.0;

                center = PlayerUtil.getCenter(mc.player.posX, mc.player.posY, mc.player.posZ);

                mc.player.connection.sendPacket(new CPacketPlayer.Position(center.x, center.y, center.z, true));
                mc.player.setPosition(center.x, center.y, center.z);
            }
        }
    }

    @Override
    public void onDisable() {
        if (nullCheck()) return;

        blocksPlaced = 0;
        hasPlaced = false;
        center = Vec3d.ZERO;
        renderBlock = null;
    }

    public void onUpdate() {
        if (nullCheck()) return;

        if (timeout.getValue()) {
            if (this.isEnabled() && !disableMode.is("Never")) {
                if (mc.player.ticksExisted % timeoutTicks.getDoubleValue() == 0) {
                    this.toggle();
                }
            }
        } else if (hasPlaced && disableMode.is("Finish")) {
            this.toggle();
        } else {
            if (!mc.player.onGround) {
                this.toggle();
            }
        }

        blocksPlaced = 0;

        for (Vec3d vec3d : getPlaceType()) {
            BlockPos blockPos = new BlockPos(vec3d.add(mc.player.getPositionVector()));

            if (mc.world.getBlockState(blockPos).getBlock().isReplaceable(mc.world, blockPos)) {
                int oldInventorySlot = mc.player.inventory.currentItem;

                if (getBlockSlot() != -1) {
                    mc.player.inventory.currentItem = getBlockSlot();
                }

                if (mc.player.getHeldItemMainhand().getItem() == Item.getItemFromBlock(getBlockBlock())) {
                    PlaceUtil.placeBlock(blockPos, rotate.getValue(), rotateMode.is("Place"));
                }

                renderBlock = new BlockPos(vec3d.add(mc.player.getPositionVector()));

                mc.player.inventory.currentItem = oldInventorySlot;

                blocksPlaced++;

                if (blocksPlaced == blocksPerTick.getIntValue() && !disableMode.is("Never")) return;
            }
        }

        if (blocksPlaced == 0) {
            hasPlaced = true;
        }
    }

    private String getBlockText() {
        switch (blockMode.getMode()) {
            case "Obsidian":
                return "Obsidian";
            case "EnderChest":
                return "Ender Chests";
        }

        return "Obsidian";
    }

    private int getBlockSlot() {
        switch (blockMode.getMode()) {
            case "Obsidian":
                return obsidianSlot;
            case "EnderChest":
                return enderChestSlot;
        }

        return obsidianSlot;
    }

    private Block getBlockBlock() {
        switch (blockMode.getMode()) {
            case "Obsidian":
                return Blocks.OBSIDIAN;
            case "EnderChest":
                return Blocks.ENDER_CHEST;
        }

        return Blocks.OBSIDIAN;
    }

    @Override
    public void onRenderWorld() {
        if (nullCheck()) return;

        if (renderPlace.getValue() && renderBlock != null) {
            GL11.glLineWidth(outlineWidth.getFloatValue());

            RenderUtil3D.draw(renderBlock, !renderMode.is("Outline"), !renderMode.is("Box"), 0, 0, renderColour.getColor());
        }
    }

    @Override
    public String getHUDData() {
        return placeMode.getMode();
    }

    private final List<Vec3d> standardSurround = new ArrayList<>(Arrays.asList(
            new Vec3d(0, -1, 0),
            new Vec3d(1, 0, 0),
            new Vec3d(-1, 0, 0),
            new Vec3d(0, 0, 1),
            new Vec3d(0, 0, -1)
    ));

    private final List<Vec3d> fullSurround = new ArrayList<>(Arrays.asList(
            new Vec3d(0, -1, 0),
            new Vec3d(1, -1, 0),
            new Vec3d(0, -1, 1),
            new Vec3d(-1, -1, 0),
            new Vec3d(0, -1, -1),
            new Vec3d(1, 0, 0),
            new Vec3d(0, 0, 1),
            new Vec3d(-1, 0, 0),
            new Vec3d(0, 0, -1)
    ));

    private final List<Vec3d> antiCitySurround = new ArrayList<>(Arrays.asList(
            new Vec3d(0, -1, 0),
            new Vec3d(1, 0, 0),
            new Vec3d(-1, 0, 0),
            new Vec3d(0, 0, 1),
            new Vec3d(0, 0, -1),
            new Vec3d(2, 0, 0),
            new Vec3d(-2, 0, 0),
            new Vec3d(0, 0, 2),
            new Vec3d(0, 0, -2),
            new Vec3d(3, 0, 0),
            new Vec3d(-3, 0, 0),
            new Vec3d(0, 0, 3),
            new Vec3d(0, 0, -3)
    ));

    private List<Vec3d> getPlaceType() {
        if (placeMode.is("Standard")) {
            return standardSurround;
        } else if (placeMode.is("Full")) {
            return fullSurround;
        }

        return antiCitySurround;
    }
}
