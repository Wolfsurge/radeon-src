package cf.radeon.module.modules.hud;

import cf.radeon.module.Category;
import cf.radeon.module.Module;
import cf.radeon.module.settings.ModeSetting;

public class Armour extends Module {

    public static ModeSetting orientation = new ModeSetting("Orient", "Which way the module is rendered", "Across", "Down");

    public Armour() {
        super("Armour", "Displays your armour on screen.", Category.HUD, true);
        this.addSettings(orientation);
    }
}
