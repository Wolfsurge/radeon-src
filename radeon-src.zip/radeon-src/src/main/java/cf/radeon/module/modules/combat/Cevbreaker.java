package cf.radeon.module.modules.combat;

import cf.radeon.module.Category;
import cf.radeon.module.Module;
import cf.radeon.utils.block.BlockUtil;
import cf.radeon.utils.player.InventoryUtil;
import net.minecraft.block.Block;
import net.minecraft.block.BlockAir;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.Minecraft;
import net.minecraft.item.Item;
import net.minecraft.item.ItemPickaxe;
import net.minecraft.network.play.client.CPacketPlayerDigging;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

public class Cevbreaker extends Module {

    private BlockPos lastBlock = null;
    private boolean pickStillBol = false;
    private EnumFacing direction;
    private boolean minedBefore = false;
    private int reseTick;
    private int tick = 99;
    private int tickSpammer = 0;
    private int oldslot;
    private int breakTick = 0;
    private int wait = 100;

    public Cevbreaker() {
        super("CevBreaker", "cev breaker lmao", Category.COMBAT);
    }

    private Vec3d lastHitVec = null;

    public void onUpdate() {
        /*
            So, this is a little bit complex.
            I want to use the same things for every switch we will ever encounter, both with switch or switchback or switch still
            So, tick = 99 is when we have done
         */
        if (tick != 99) {
            // Simple timer
            if (tick++ >= wait) {
                // Save slot in case of switch back
                int prev = mc.player.inventory.currentItem;
                // If oldslot != -1 (who know, i dont wanna random crashes)
                if (oldslot != -1) {
                    // Change
                    mc.player.inventory.currentItem = oldslot;
                    oldslot = -1;
                }
                // If we have to change
                if (!pickStillBol) {
                    tick = 99;
                    mc.player.inventory.currentItem = prev;
                } else
                    tick = 99;
            }
        }

        // This is for making breaker working
        Minecraft.getMinecraft().playerController.blockHitDelay = 0;
        mc.playerController.blockHitDelay = 0;
        /*
            So, we have a lot of options and i tried to keep everything united.
            The first if, enter only if: Or we have a pick on the mainhand, or we have choose that we can do everything even without pick
         */
        if (mc.player.getHeldItemMainhand().getItem() instanceof ItemPickaxe)
            // The second check for breaker, if cevBreaker allow us to use breaker
            if (true) {
                // The second, first check if we have a lastblock, if yes, it's just a timer
                // Reset timer
                tickSpammer = 0;
                // If we have mined it before
                if (minedBefore) {
                    // Here, we check if it's air in case we have choose to not spam it every time
                    if (!(BlockUtil.getBlock(lastBlock) instanceof BlockAir)) {
                        // Get distance, if it's >=, then delete it
                        if (mc.player.getDistanceSq(lastBlock) >= 15)
                            lastBlock = null;
                        else {
                            // Finally break it
                            breakerBreak();
                        }
                    }
                    // This is for checking if it's air, if yes, then we have mined it (maybe)
                } else if (BlockUtil.getBlock(lastBlock) instanceof BlockAir) {
                    minedBefore = true;
                    reseTick = 0;
                }
            }
    }

    private void breakerBreak() {
        // Get item
        Item item = mc.player.inventory.getCurrentItem().getItem();
        // OldSlot
        int oldSlot = -1;
        // Switch to pick
        if (!(item instanceof ItemPickaxe) && minedBefore) {
            oldSlot = mc.player.inventory.currentItem;
            int slot = InventoryUtil.findFirstItemSlot(ItemPickaxe.class, 0, 9);
            // Who know? Do you want to get kicked?
            if (slot != -1)
                mc.player.inventory.currentItem = slot;
        }
        // Send STOP_DESTROY_BLOCK
        mc.player.connection.sendPacket(new CPacketPlayerDigging(CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK,
                lastBlock, direction));
        // If oldSlot != -1, so we have switchback
        if (oldSlot != -1 && true) {
            // Allow to switchback
            tick = 0;
            oldslot = oldSlot;
            // Since we use it for both packet and breaker, we have to do these checks
            wait = 20;
        }

    }

    private void setVec3d(BlockPos pos, EnumFacing side) {
        BlockPos neighbour = pos.offset(side);
        EnumFacing opposite = side.getOpposite();
        lastHitVec = new Vec3d(neighbour).add(0.5, 0.5, 0.5).add(new Vec3d(opposite.getDirectionVec()).scale(0.5));
    }

    // Algo for breaker when first launched, this is heavely modified from ciru's instabreaker
//    private void breakerAlgo(DamageBlockEvent event) {
//        // Checks if we have already entered here
//        if (lastBlock == null || event.getBlockPos().x != lastBlock.x || event.getBlockPos().y != lastBlock.y || event.getBlockPos().z != lastBlock.z) {
//            if (startPick.getValue()) {
//                int pick = InventoryUtil.findFirstItemSlot(ItemPickaxe.class, 0, 9);
//                if (pick != -1)
//                    mc.player.inventory.currentItem = pick;
//            }
//            // Start breaking normally
//            minedBefore = false;
//            mc.player.swingArm(EnumHand.MAIN_HAND);
//            mc.player.connection.sendPacket(new CPacketPlayerDigging(CPacketPlayerDigging.Action.START_DESTROY_BLOCK, event.getBlockPos(), event.getEnumFacing()));
//            lastBlock = event.getBlockPos();
//            direction = event.getEnumFacing();
//        }
//        // This is a simple timer in case we want to limit the packets during cevbreaker
//        if (breakerTickDelay.getValue() <= breakTick++) {
//            // Algo Breaker
//            breakerBreak();
//            event.cancel();
//            breakTick = 0;
//        }
//        // Switch to pick, dont run if cevbreaker
////        if (!Cevbreaker.isActive && switchPick.getValue()) {
////            oldslot = InventoryUtil.findFirstItemSlot(ItemPickaxe.class, 0, 9);
////            tick = 0;
////            wait = pickTickSwitch.getValue();
//            pickStillBol = !switchBack.getValue();
//        }
//    }

    private boolean canBreak(BlockPos pos) {
        final IBlockState blockState = mc.world.getBlockState(pos);
        final Block block = blockState.getBlock();
        return block.getBlockHardness(blockState, mc.world, pos) != -1;
    }

    public void onDisable() {
        breakTick = 0;
    }

}
