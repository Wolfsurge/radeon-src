package cf.radeon.module.modules.misc;

import cf.radeon.module.Category;
import cf.radeon.module.Module;
import cf.radeon.module.settings.BooleanSetting;
import cf.radeon.module.settings.ModeSetting;
import com.mojang.realmsclient.gui.ChatFormatting;
import net.minecraft.util.text.TextComponentString;
import net.minecraftforge.client.event.ClientChatReceivedEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * @author olliem5
 */

public final class ChatTweaks extends Module {
    public static final BooleanSetting clearBackground = new BooleanSetting("Clear Background", "Does not render the chatbox background", true);

    public static final BooleanSetting timestamps = new BooleanSetting("Timestamps", "Renders the time a message was sent in the chat", true);
    public static final ModeSetting hourMode = new ModeSetting("Hour", "How the hour is displayed", "Twelve", "TwentyFour");

    public ChatTweaks() {
        super("ChatTweaks", "Tweaks how your chat renders", Category.MISC);
        this.addSettings(
                clearBackground,
                timestamps,
                hourMode
        );
    }

    @SubscribeEvent
    public void onClientChatReceived(ClientChatReceivedEvent event) {
        if (nullCheck()) return;

        if (timestamps.getValue()) {
            TextComponentString textComponentString = new TextComponentString(ChatFormatting.DARK_PURPLE + "<" + (hourMode.is("Twelve") ? new SimpleDateFormat("h:mm").format(new Date()) : new SimpleDateFormat("k:mm").format(new Date())) + "> " + ChatFormatting.RESET);

            event.setMessage(textComponentString.appendSibling(event.getMessage()));
        }
    }
}
