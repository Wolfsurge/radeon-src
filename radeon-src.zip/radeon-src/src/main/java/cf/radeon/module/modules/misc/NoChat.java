package cf.radeon.module.modules.misc;

import cf.radeon.event.impl.PacketEvent;
import cf.radeon.module.Category;
import cf.radeon.module.Module;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.minecraft.network.play.server.SPacketChat;

public class NoChat extends Module {

	public NoChat() {
		super("NoChat", "Cancels all chat packets from the server but allows you to send chat messages.", Category.MISC);
	}

	@EventHandler
	private final Listener<PacketEvent.Receive> receiveListener = new Listener<>(e -> {
		if (nullCheck())
			return;

		if (e.getPacket() instanceof SPacketChat) {
			e.cancel();
		}
	});
}
