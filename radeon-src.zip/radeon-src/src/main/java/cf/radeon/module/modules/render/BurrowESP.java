package cf.radeon.module.modules.render;

import cf.radeon.module.Category;
import cf.radeon.module.Module;
import cf.radeon.module.settings.BooleanSetting;
import cf.radeon.module.settings.ColourPicker;
import cf.radeon.module.settings.ModeSetting;
import cf.radeon.module.settings.NumberSetting;
import cf.radeon.utils.render.RenderUtil3D;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.util.math.BlockPos;
import org.lwjgl.opengl.GL11;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;

/**
 * @author olliem5
 */

public final class BurrowESP extends Module {
    public static final BooleanSetting renderOwn = new BooleanSetting("Render Own", "Renders your own burrow block", false);
    public static final NumberSetting range = new NumberSetting("Range", "The range to search for burrow blocks in", 1, 5, 10, 1);

    public static final BooleanSetting renderBlock = new BooleanSetting("Render", "Allows the burrow blocks to be rendered", true);
    public static final ModeSetting renderMode = new ModeSetting("Render Mode", "The type of box to render", "Full", "Outline", "Box");
    public static final NumberSetting outlineWidth = new NumberSetting("Outline Width", "The width of the outline", 1.0, 2.0, 5.0, 0.5);
    public static final ColourPicker renderColour = new ColourPicker("Render Colour", "The colour for the burrow blocks", new Color(91, 79, 208, 220));

    public BurrowESP() {
        super("BurrowESP", "Shows blocks that players are burrowed in", Category.RENDER);
        this.addSettings(
                renderOwn,
                range,
                renderBlock,
                renderMode,
                outlineWidth,
                renderColour
        );
    }

    private final List<BlockPos> burrowBlocksList = new ArrayList<>();

    @Override
    public void onEnable() {
        if (nullCheck()) return;

        burrowBlocksList.clear();
    }

    @Override
    public void onDisable() {
        if (nullCheck()) return;

        burrowBlocksList.clear();
    }

    public void onUpdate() {
        if (nullCheck()) return;

        burrowBlocksList.clear();

        for (EntityPlayer entityPlayer : mc.world.playerEntities) {
            if (entityPlayer.getDistance(mc.player) <= range.getFloatValue()) {
                if (entityPlayer == mc.player && renderOwn.getValue()) {
                    if (mc.world.getBlockState(new BlockPos(mc.player.posX, mc.player.posY, mc.player.posZ)).getBlock() == Blocks.OBSIDIAN) {
                        burrowBlocksList.add(new BlockPos(mc.player.posX, mc.player.posY, mc.player.posZ));
                    }
                } else {
                    if (entityPlayer != mc.player && !renderOwn.getValue()) {
                        if (mc.world.getBlockState(new BlockPos(entityPlayer.posX, entityPlayer.posY, entityPlayer.posZ)).getBlock() == Blocks.OBSIDIAN) {
                            burrowBlocksList.add(new BlockPos(entityPlayer.posX, entityPlayer.posY, entityPlayer.posZ));
                        }
                    }
                }
            }
        }
    }

    @Override
    public void onRenderWorld() {
        if (nullCheck()) return;

        if (renderBlock.getValue()) {
            for (BlockPos burrowBlock : burrowBlocksList) {
                if (burrowBlock != null) {
                    GL11.glLineWidth(outlineWidth.getFloatValue());

                    RenderUtil3D.draw(burrowBlock,
                            !renderMode.is("Outline"),
                            !renderMode.is("Box"), 0, 0, renderColour.getColor());
                }
            }
        }
    }

    public enum RenderModes {
        Box,
        Outline,
        Full
    }
}
