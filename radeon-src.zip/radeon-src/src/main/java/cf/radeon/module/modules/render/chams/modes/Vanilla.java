package cf.radeon.module.modules.render.chams.modes;

import cf.radeon.module.modules.render.chams.ChamsMode;

/**
 * @author olliem5
 */

public final class Vanilla extends ChamsMode {}
