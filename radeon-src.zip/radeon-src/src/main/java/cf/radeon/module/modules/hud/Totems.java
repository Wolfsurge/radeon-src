package cf.radeon.module.modules.hud;

import cf.radeon.module.Category;
import cf.radeon.module.Module;

public class Totems extends Module {

    public Totems() {
        super("Totems", "Displays the amount of totems in your inventory on screen.", Category.HUD, true);
    }

}
