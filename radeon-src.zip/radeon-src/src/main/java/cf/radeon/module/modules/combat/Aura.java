package cf.radeon.module.modules.combat;

import cf.radeon.Radeon;
import cf.radeon.managers.RotationManager;
import cf.radeon.module.Category;
import cf.radeon.module.Module;
import cf.radeon.module.settings.BooleanSetting;
import cf.radeon.module.settings.ModeSetting;
import cf.radeon.module.settings.NumberSetting;
import cf.radeon.utils.combat.TargetUtil;
import cf.radeon.utils.player.InventoryUtil;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.item.ItemAxe;
import net.minecraft.item.ItemEndCrystal;
import net.minecraft.item.ItemSword;
import net.minecraft.network.play.client.CPacketUseEntity;
import net.minecraft.util.EnumHand;

public class Aura extends Module {

    public static final NumberSetting targetRange = new NumberSetting("Target Range", "The range that players can be attacked in", 0.0, 5.0, 10.0, 0.1);

    public static final BooleanSetting attack = new BooleanSetting("Attack", "Allows Aura to attack", true);
    public static final ModeSetting attackMode = new ModeSetting("Attack", "The mode for Aura attacks", "Packet", "Normal");
    public static final BooleanSetting cooldown = new BooleanSetting("Cooldown", "Allows for cooldown between swings", true);
    public static final BooleanSetting swing = new BooleanSetting("Swing", "Swings the player's arm after an attack", true);

    public static final BooleanSetting weapon = new BooleanSetting("Weapon", "Weapon settings for Aura", true);
    public static final ModeSetting weaponMode = new ModeSetting("Weapon", "The weapon that Aura will use", "Sword", "Axe");
    public static final BooleanSetting weaponOnly = new BooleanSetting("Weapon Only", "Only allows attacking when you are holding your designated weapon", true);
    public static final BooleanSetting autoSwitch = new BooleanSetting("Auto Switch", "Automatically switches to your designated weapon", true);

    public static final BooleanSetting rotate = new BooleanSetting("Rotate", "Allow for rotations", true);
    public static final ModeSetting rotateMode = new ModeSetting("Mode", "The mode to use for rotations", "Packet", "Legit");

    public static final BooleanSetting pause = new BooleanSetting("Pause", "Allows Aura to pause", true);
    public static final BooleanSetting pauseWithCrystals = new BooleanSetting("With Crystals", "Pauses attacking if AutoCrystal is enabled or you are holding crystals in your main hand", false);
    public static final BooleanSetting pauseWhileEating = new BooleanSetting("While Eating", "Pauses attacking if you are eating", false);

    public EntityPlayer currentTarget = null;

    public Aura() {
        super("Aura", "Automatically attacks players and entities in range.", Category.COMBAT);
        this.addSettings(targetRange, attack, attackMode, cooldown, swing, weapon, weaponMode, weaponOnly, autoSwitch, rotate, rotateMode, pause, pauseWithCrystals, pauseWhileEating);
    }

    public void onUpdate() {
        if (nullCheck()) return;

        currentTarget = TargetUtil.getClosestPlayer(targetRange.getDoubleValue());

        doKillAura(currentTarget);
    }

    public void doKillAura(EntityPlayer entityPlayer) {
        if (weaponOnly.getValue() && weaponMode.is("Sword") && !(mc.player.getHeldItemMainhand().getItem() instanceof ItemSword)) return;

        if (weaponOnly.getValue() && weaponMode.is("Axe") && !(mc.player.getHeldItemMainhand().getItem() instanceof ItemAxe)) return;

        if (pauseWithCrystals.getValue() && Radeon.moduleManager.getModuleByName("AutoCrystal").isEnabled() || mc.player.getHeldItemMainhand().getItem() instanceof ItemEndCrystal) return;

        if (pauseWhileEating.getValue() && mc.player.getHeldItemMainhand().getItem() == Items.GOLDEN_APPLE && mc.player.isHandActive()) return;

        if (currentTarget != null) {
            if (autoSwitch.getValue()) {
                switch (weaponMode.getMode()) {
                    case "Sword":
                        InventoryUtil.switchToSlot(ItemSword.class);
                        break;
                    case "Axe":
                        InventoryUtil.switchToSlot(ItemAxe.class);
                        break;
                }
            }

            if (rotate.getValue()) {
                RotationManager.rotateToEntity(entityPlayer, rotateMode.is("Packet"));
            }

            if (cooldown.getValue()) {
                if (attackMode.is("Normal")) {
                    if (mc.player.getCooledAttackStrength(0) >= 1) {
                        mc.playerController.attackEntity(mc.player, entityPlayer);

                        if (swing.getValue()) {
                            mc.player.swingArm(EnumHand.MAIN_HAND);
                        }
                    }
                } else {
                    mc.player.connection.sendPacket(new CPacketUseEntity(entityPlayer));

                    if (swing.getValue()) {
                        mc.player.swingArm(EnumHand.MAIN_HAND);
                    }

                    mc.player.resetCooldown();
                }
            } else {
                if (attackMode.is("Normal")) {
                    mc.playerController.attackEntity(mc.player, entityPlayer);
                } else {
                    mc.player.connection.sendPacket(new CPacketUseEntity(entityPlayer));
                }

                if (swing.getValue()) {
                    mc.player.swingArm(EnumHand.MAIN_HAND);
                }
            }
        }
    }

    public boolean isValid(Entity entity) {
        if(Radeon.friendManager.isFriend(entity.getName()))
            return false;
        else
            return true;
    }

    @Override
    public String getHUDData() {
        if (currentTarget != null) {
            return currentTarget.getName();
        }

        return "";
    }
}
