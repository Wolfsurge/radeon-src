package cf.radeon.module.settings;

public class Setting {
	
	public String name, description;
	public boolean focused;

	public String getName() {
		return name;
	}

}
