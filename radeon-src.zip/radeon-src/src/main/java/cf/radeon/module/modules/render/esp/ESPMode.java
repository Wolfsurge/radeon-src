package cf.radeon.module.modules.render.esp;

import me.wolfsurge.api.util.Globals;

/**
 * @author olliem5
 */

public abstract class ESPMode implements Globals {
    public void drawESP() {}
}
