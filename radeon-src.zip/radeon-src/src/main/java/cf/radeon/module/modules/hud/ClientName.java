package cf.radeon.module.modules.hud;

import cf.radeon.module.Category;
import cf.radeon.module.Module;
import cf.radeon.module.settings.ModeSetting;

public class ClientName extends Module {

    public static ModeSetting mode = new ModeSetting("Mode", "What mode to use", "Image", "Text");

    public ClientName() {
        super("ClientName", "Displays the client's name on screen.", Category.HUD, true);
        this.addSetting(mode);
    }

}
