package cf.radeon.module.modules.movement;

import cf.radeon.event.impl.TravelEvent;
import cf.radeon.module.Category;
import cf.radeon.module.Module;
import cf.radeon.module.settings.BooleanSetting;
import cf.radeon.module.settings.KeybindSetting;
import cf.radeon.module.settings.ModeSetting;
import cf.radeon.module.settings.NumberSetting;
import cf.radeon.utils.other.Timer;
import cf.radeon.utils.player.MotionUtil;
import cf.radeon.utils.player.PlayerUtil;
import org.lwjgl.input.Keyboard;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.minecraft.network.play.client.CPacketEntityAction;

public class ElytraFlight extends Module {

    public static ElytraFlight INSTANCE;

    public static ModeSetting mode = new ModeSetting("Mode", "Which mode to use", "Control", "Packet");
    public static NumberSetting speed = new NumberSetting("Speed", "How fast to fly", 0.0, 2.5, 5.0, 0.1);
    public static NumberSetting up = new NumberSetting("Up", "How fast to fly upwards", 0.0, 1.0, 5.0, 0.1);
    public static NumberSetting down = new NumberSetting("Down", "How fast to fly downwards", 0.0, 1.0, 5.0, 0.1);
    public static NumberSetting fall = new NumberSetting("Fall", "How fast to fall", 0.0, 0.0, 0.1, 0.01);
    public static BooleanSetting lockRotation = new BooleanSetting("LockRotation", "Lock the player's rotation", false);
    public static BooleanSetting pauseLiquid = new BooleanSetting("StopInLiquid", "Cancel flight when in liquid", true);
    public static BooleanSetting pauseCollision = new BooleanSetting("StopWhenColliding", "Cancel flight when colliding with a block", false);
    KeybindSetting activateKey = new KeybindSetting("Activate Key", Keyboard.KEY_NONE);

    public ElytraFlight() {
        super("ElytraFlight", "Use elytra easier", 0, Category.MOVEMENT);
        this.addSettings(mode, speed, up, down, fall, lockRotation, pauseLiquid, pauseCollision, activateKey);
        INSTANCE = this;
    }

    public static int flightKey;

    Timer timer = new Timer();

    @EventHandler
    private final Listener<TravelEvent> travelListener = new Listener<>(event -> {
        if(!nullCheck() && mc.player.isElytraFlying()) {
            if(PlayerUtil.isInLiquid() && pauseLiquid.getValue())
                return;

            else if (PlayerUtil.isCollided() && pauseCollision.getValue())
                return;

            elytraFlight(event);
        }
    });

    @Override
    public void onUpdate() {
        handleKey();
    }

    public void handleKey() {
        if(Keyboard.getEventKeyState()) {
            if(Keyboard.isKeyDown(activateKey.code)) {
                mc.getConnection().sendPacket(new CPacketEntityAction(mc.player, CPacketEntityAction.Action.START_FALL_FLYING));
            }
        }
    }

    public void elytraFlight(TravelEvent event) {
        event.cancel();

        mc.player.fallDistance = 0;

        MotionUtil.stopMotion(-fall.getDoubleValue());
        MotionUtil.setMoveSpeed(speed.getDoubleValue(), 0.6F);

        switch (mode.getMode()) {
            case "Control":
                handleControl();
                break;
            case "Packet":
                break;
        }

        PlayerUtil.lockLimbs();
    }

    public void handleControl() {
        if (mc.gameSettings.keyBindJump.isKeyDown()) {
            mc.player.motionY = up.getDoubleValue();
        }

        else if (mc.gameSettings.keyBindSneak.isKeyDown()) {
            mc.player.motionY = -down.getDoubleValue();
        }
    }

    @Override
    public String getHUDData() {
        return this.mode.getMode();
    }
}