package cf.radeon.module.modules.combat;

import cf.radeon.module.Category;
import cf.radeon.module.Module;
import cf.radeon.module.settings.BooleanSetting;
import cf.radeon.module.settings.ColourPicker;
import cf.radeon.module.settings.ModeSetting;
import cf.radeon.module.settings.NumberSetting;
import cf.radeon.utils.combat.TargetUtil;
import cf.radeon.utils.combat.crystal.PlaceUtil;
import cf.radeon.utils.other.ChatUtil;
import cf.radeon.utils.player.InventoryUtil;
import cf.radeon.utils.render.Colour;
import cf.radeon.utils.render.RenderUtil3D;
import com.mojang.realmsclient.gui.ChatFormatting;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.opengl.GL11;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * @author olliem5
 */

public final class AutoTrap extends Module {
    public static final ModeSetting placeMode = new ModeSetting("Place", "The style of trap to place", "Full", "City");
    public static final ModeSetting disableMode = new ModeSetting("Disable", "When to disable the module", "Finish", "Never");

    public static final NumberSetting blocksPerTick = new NumberSetting("BPT", "Blocks per tick to place", 1, 1, 10, 1);
    public static final NumberSetting targetRange = new NumberSetting("Target Range", "The range for a target to be found", 1.0, 4.4, 10.0, 0.1);

    public static final BooleanSetting rotate = new BooleanSetting("Rotate", "Allow for rotations", true);
    public static final ModeSetting rotateMode = new ModeSetting("Mode", "The mode to use for rotations", "Packet", "Legit");

    public static final BooleanSetting timeout = new BooleanSetting("Timeout", "Allows the module to timeout and disable", true);
    public static final NumberSetting timeoutTicks = new NumberSetting("Ticks", "Ticks that have to pass to timeout", 1.0, 15.0, 20.0, 1);

    public static final BooleanSetting renderPlace = new BooleanSetting("Render", "Allows the block placements to be rendered", true);
    public static final ModeSetting renderMode = new ModeSetting("Render Mode", "The type of box to render", "Full", "Outline", "Box");
    public static final NumberSetting outlineWidth = new NumberSetting("Outline Width", "The width of the outline", 1.0, 2.0, 5.0, 0.5);
    public static final ColourPicker renderColour = new ColourPicker("Render Colour", "The colour for the block placements", new Colour(15, 60, 231, 201));

    public AutoTrap() {
        super("AutoTrap", "Automatically traps enemies with obsidian", Category.COMBAT);
        this.addSettings(
                placeMode,
                disableMode,
                blocksPerTick,
                targetRange,
                rotate,
                rotateMode,
                timeout,
                timeoutTicks,
                renderPlace,
                renderMode,
                outlineWidth,
                renderColour
        );
    }

    private int obsidianSlot;
    private int blocksPlaced = 0;

    private boolean hasPlaced = false;

    private BlockPos renderBlock = null;
    private EntityPlayer target = null;

    @Override
    public void onEnable() {
        if (nullCheck()) return;

        obsidianSlot = InventoryUtil.getHotbarBlockSlot(Blocks.OBSIDIAN);

        if (obsidianSlot == -1) {
            ChatUtil.addChatMessage("No Obsidian, " + ChatFormatting.RED + "Disabling!");
            this.toggle();
        }
    }

    @Override
    public void onDisable() {
        if (nullCheck()) return;

        blocksPlaced = 0;
        hasPlaced = false;
        renderBlock = null;
        target = null;
    }

    public void onUpdate() {
        if (nullCheck()) return;

        target = TargetUtil.getClosestPlayer(targetRange.getFloatValue());

        if (timeout.getValue()) {
            if (this.isEnabled() && !disableMode.is("Never")) {
                if (mc.player.ticksExisted % timeoutTicks.getIntValue() == 0) {
                    this.toggle();
                }
            }
        } else {
            if (hasPlaced && disableMode.is("Finish")) {
                this.toggle();
            }
        }

        blocksPlaced = 0;

        for (Vec3d vec3d : getPlaceType()) {
            if (target != null) {
                BlockPos blockPos = new BlockPos(vec3d.add(target.getPositionVector()));

                if (mc.world.getBlockState(blockPos).getBlock().isReplaceable(mc.world, blockPos)) {
                    int oldInventorySlot = mc.player.inventory.currentItem;

                    if (obsidianSlot != -1) {
                        mc.player.inventory.currentItem = obsidianSlot;
                    }

                    if (mc.player.getHeldItemMainhand().getItem() == Item.getItemFromBlock(Blocks.OBSIDIAN)) {
                        PlaceUtil.placeBlock(blockPos, rotate.getValue(), rotateMode.is("Packet"));
                    }

                    renderBlock = new BlockPos(vec3d.add(target.getPositionVector()));

                    mc.player.inventory.currentItem = oldInventorySlot;

                    blocksPlaced++;

                    if (blocksPlaced == blocksPerTick.getIntValue() && !disableMode.is("Never")) return;
                }
            }
        }

        if (blocksPlaced == 0) {
            hasPlaced = true;
        }
    }

    @Override
    public void onRenderWorld() {
        if (nullCheck()) return;

        if (renderPlace.getValue() && renderBlock != null) {
            GL11.glLineWidth(outlineWidth.getFloatValue());

            RenderUtil3D.draw(renderBlock,
                    !renderMode.is("Outline"),
                    !renderMode.is("Box"), 0, 0, renderColour.getColor());
        }
    }

    @Override
    public String getHUDData() {
        if (target != null) {
            return target.getName();
        }

        return "";
    }

    private final List<Vec3d> fullTrap = new ArrayList<>(Arrays.asList(
            new Vec3d(0, -1, -1),
            new Vec3d(1, -1, 0),
            new Vec3d(0, -1, 1),
            new Vec3d(-1, -1, 0),
            new Vec3d(0, 0, -1),
            new Vec3d(1, 0, 0),
            new Vec3d(0, 0, 1),
            new Vec3d(-1, 0, 0),
            new Vec3d(0, 1, -1),
            new Vec3d(1, 1, 0),
            new Vec3d(0, 1, 1),
            new Vec3d(-1, 1, 0),
            new Vec3d(0, 2, -1),
            new Vec3d(0, 2, 1),
            new Vec3d(0, 2, 0)
    ));

    private final List<Vec3d> cityTrap = new ArrayList<>(Arrays.asList(
            new Vec3d(0, -1, -1),
            new Vec3d(1, -1, 0),
            new Vec3d(0, -1, 1),
            new Vec3d(-1, -1, 0),
            new Vec3d(0, 0, -1),
            new Vec3d(1, 0, 0),
            new Vec3d(0, 0, 1),
            new Vec3d(-1, 0, 0),
            new Vec3d(0, 1, -1),
            new Vec3d(1, 1, 0),
            new Vec3d(0, 1, 1),
            new Vec3d(-1, 1, 0),
            new Vec3d(0, 2, -1),
            new Vec3d(0, 2, 1),
            new Vec3d(0, 2, 0)
    ));

    private List<Vec3d> getPlaceType() {
        if (placeMode.is("Full")) {
            return fullTrap;
        } else {
            return cityTrap;
        }
    }
}
