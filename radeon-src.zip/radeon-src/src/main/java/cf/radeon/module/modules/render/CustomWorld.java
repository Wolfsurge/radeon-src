package cf.radeon.module.modules.render;

import cf.radeon.event.impl.PacketEvent;
import cf.radeon.module.Category;
import cf.radeon.module.Module;
import cf.radeon.module.settings.BooleanSetting;
import cf.radeon.module.settings.ModeSetting;
import cf.radeon.module.settings.NumberSetting;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.minecraft.network.play.server.SPacketTimeUpdate;

public final class CustomWorld extends Module {
    public static final ModeSetting weatherMode = new ModeSetting("Weather", "The world's weather", "Clear", "Rain", "Thunder");

    public static final ModeSetting timeMode = new ModeSetting("Time", "The world's time", "Day", "Noon", "Sunset", "Night", "Midnight", "Sunrise", "Custom");
    public static final NumberSetting customTime = new NumberSetting("Custom Time", "The custom time value", 0, 18000, 24000, 1);

    public static final BooleanSetting fix = new BooleanSetting("Blinking fix", "credits to Z3R0, he found this", true);

    public CustomWorld() {
        super("CustomWorld", "Changes the world time and weather", Category.RENDER);
        this.addSettings(
                weatherMode,
                timeMode,
                customTime,
                fix
        );
    }

    public void onUpdate() {
        if (nullCheck()) return;

        switch (weatherMode.getMode()) {
            case "Clear":
                mc.world.setRainStrength(0);
                break;
            case "Rain":
                mc.world.setRainStrength(1);
                break;
            case "Thunder":
                mc.world.setRainStrength(2);
                break;
        }

        switch (timeMode.getMode()) {
            case "Day":
                mc.world.setWorldTime(1000);
                break;
            case "Noon":
                mc.world.setWorldTime(6000);
                break;
            case "Sunset":
                mc.world.setWorldTime(12500);
                break;
            case "Night":
                mc.world.setWorldTime(13000);
                break;
            case "Midnight":
                mc.world.setWorldTime(18000);
                break;
            case "Sunrise":
                mc.world.setWorldTime(23500);
                break;
            case "Custom":
                mc.world.setWorldTime(customTime.getIntValue());
                break;
        }
    }

    @Override
    public String getHUDData() {
        return weatherMode.getMode() + ", " + timeMode.getMode();
    }

    public enum WeatherModes {
        Clear,
        Rain,
        Thunder
    }

    public enum TimeModes {
        Day,
        Noon,
        Sunset,
        Night,
        Midnight,
        Sunrise,
        Custom
    }

    @EventHandler
    private final Listener<PacketEvent.Receive> receiveListener = new Listener<>(event -> {
        if(nullCheck()) return;

        if(fix.getValue()) {
            if(event.getPacket() instanceof SPacketTimeUpdate) {
                event.cancel();
            }
        }
    });
}
