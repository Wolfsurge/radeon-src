package cf.radeon.module.modules.misc;

import cf.radeon.module.Category;
import cf.radeon.module.Module;
import cf.radeon.module.settings.NumberSetting;

public class TextbookAnnoy extends Module {

	NumberSetting minDelay = new NumberSetting("Min delay", "The minimum delay to use to spam.", 1d, 5d, 100d, 1);
	NumberSetting maxDelay = new NumberSetting("Max delay", "The maximum delay to use to spam.", 1d, 5d, 100d, 1);

	public TextbookAnnoy() {
		super("TextbookAnnoy", "Spam physics stuff at people. :/", Category.MISC);
		this.addSettings(minDelay, maxDelay);
	}

}
