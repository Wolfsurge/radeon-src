package cf.radeon.module.settings;

import java.util.Arrays;
import java.util.List;

public class ModeSetting extends Setting {
	
	public int index;
	public List<String> modes;
	
	public ModeSetting(String name, String desc, String... modes) {
		this.name = name;
		this.description = desc;
		this.modes = Arrays.asList(modes);
		index = 0;
	}
	
	public String getMode() {
		return modes.get(index);
	}
	
	public boolean is(String mode) {
		return index == modes.indexOf(mode);
	}
	
	public void cycle() {
		if(index < modes.size() - 1) {
			index++;
		} else {
			index = 0;
		}
	}
	
	public int getValue() {
		return index;
	}
}
