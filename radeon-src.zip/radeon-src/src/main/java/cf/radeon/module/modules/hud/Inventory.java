package cf.radeon.module.modules.hud;

import cf.radeon.module.Category;
import cf.radeon.module.Module;

public class Inventory extends Module {

    public Inventory() {
        super("Inventory", "Displays your inventory on screen.", Category.HUD, true);
    }

}
