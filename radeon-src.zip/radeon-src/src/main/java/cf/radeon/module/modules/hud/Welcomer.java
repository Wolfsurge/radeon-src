package cf.radeon.module.modules.hud;

import cf.radeon.module.Category;
import cf.radeon.module.Module;

public class Welcomer extends Module {

    public Welcomer() {
        super("Welcomer", "Welcomes you to the client!", Category.HUD, true);
    }

}
