package cf.radeon.module.modules.render;

import java.util.ArrayList;

import cf.radeon.module.Category;
import cf.radeon.module.Module;
import cf.radeon.module.modules.client.Colours;
import cf.radeon.module.settings.BooleanSetting;
import cf.radeon.utils.combat.CooldownUtil;
import cf.radeon.utils.render.RenderUtil3D;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.BlockPos;

public class PositionESP extends Module {

    public static final BooleanSetting others = new BooleanSetting("Other Players", "Render other players too.",
            false);

    public static final BooleanSetting filled = new BooleanSetting("Filled", "Makes the box filled", false);

    public PositionESP() {
        super("PositionESP","Renders a box in a players true position.", Category.RENDER);
        addSettings(others, filled);
    }

    private ArrayList<EntityPlayer> players = new ArrayList<EntityPlayer>();

    private CooldownUtil timer = new CooldownUtil();

    @Override
    public void onUpdate() {
        if(nullCheck()) return;

        if (others.getValue() && timer.passed(100)) {
            timer.reset();

            players.clear();

            mc.world.playerEntities.forEach(p -> {
                if (p != mc.player) {
                    players.add(p);
                }
            });
        }
    }

    @Override
    public void onRenderWorld() {
        if (nullCheck())
            return;

        if(nullCheck()) return;

        drawESP(mc.player);

        if(others.getValue()) {
            players.forEach(p -> {
                drawESP(p);
            });
        }

    }

    private void drawESP(EntityPlayer player) {
        RenderUtil3D.draw(new BlockPos(player.posX, player.posY, player.posZ), filled.getValue(), true, 0, 0,
                Colours.col);
    }
}
