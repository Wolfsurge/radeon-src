package cf.radeon.module.modules.misc;

import cf.radeon.module.Category;
import cf.radeon.module.Module;
import cf.radeon.utils.other.ChatUtil;
import org.lwjgl.input.Mouse;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.client.CPacketHeldItemChange;
import net.minecraft.network.play.client.CPacketPlayerTryUseItem;
import net.minecraft.util.EnumHand;

public class MiddleClickPearl extends Module {

    public MiddleClickPearl() {
        super("MiddleClickPearl", "Middle click to throw a pearl", Category.MISC);
    }

	@Override
	public void onUpdate() {
		if (Mouse.isButtonDown(2)) {
			boolean found = false;
            for (int i = 0; i < 9; ++i) {
                ItemStack itemStack = mc.player.inventory.getStackInSlot(i);
                if (itemStack.getItem() != Items.ENDER_PEARL) continue;
                found = true;
                mc.player.connection.sendPacket(new CPacketHeldItemChange(i));
                mc.player.connection.sendPacket(new CPacketPlayerTryUseItem(EnumHand.MAIN_HAND));
                mc.player.connection.sendPacket(new CPacketHeldItemChange(mc.player.inventory.currentItem));
                
                break;
            }
            if(!found) {
                ChatUtil.addChatMessage("Could not find pearl!");
            }
        }
	}
	
}
