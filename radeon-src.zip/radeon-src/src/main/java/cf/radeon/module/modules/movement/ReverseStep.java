package cf.radeon.module.modules.movement;

import cf.radeon.module.Category;
import cf.radeon.module.Module;
import cf.radeon.module.settings.NumberSetting;

public class ReverseStep extends Module {
    public static final NumberSetting motY = new NumberSetting("Motion Y", "The motion y that is subtracted.", 0.01, 1d, 10d, 0.01);

    public ReverseStep() {
        super("ReverseStep", "Step except its downward.", Category.MOVEMENT);
        this.addSettings(motY);
    }

    @Override
    public void onUpdate() {
        if(nullCheck()) return;
        if(mc.player.onGround && !mc.player.inWater && !mc.player.isInLava()) {
            mc.player.motionY -= motY.getDoubleValue();
        }
    }

}
