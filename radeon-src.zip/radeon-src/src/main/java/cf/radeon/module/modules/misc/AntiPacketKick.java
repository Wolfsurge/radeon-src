package cf.radeon.module.modules.misc;

import cf.radeon.module.Category;
import cf.radeon.module.Module;

/**
 * @author olliem5
 */

public final class AntiPacketKick extends Module {
    public AntiPacketKick() {
        super("AntiPacketKick", "Stops large packets from kicking you from servers", Category.MISC);
    }
}
