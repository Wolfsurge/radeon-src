package cf.radeon.module.modules.misc;

import java.util.Arrays;
import java.util.List;

import cf.radeon.event.impl.PacketEvent;
import cf.radeon.module.Category;
import cf.radeon.module.Module;
import cf.radeon.module.settings.BooleanSetting;
import cf.radeon.utils.other.Timer;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.minecraft.block.Block;
import net.minecraft.block.BlockCarpet;
import net.minecraft.block.BlockContainer;
import net.minecraft.block.BlockLadder;
import net.minecraft.block.BlockSkull;
import net.minecraft.block.BlockSnow;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;
import net.minecraft.inventory.ClickType;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketHeldItemChange;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.util.EnumActionResult;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public class Scaffold extends Module {
	public List<Block> blacklistedBlocks = Arrays.asList(Blocks.AIR, Blocks.WEB, Blocks.WATER, Blocks.FLOWING_WATER,
			Blocks.LAVA, Blocks.FLOWING_LAVA, Blocks.ENCHANTING_TABLE, Blocks.CARPET, Blocks.GLASS_PANE,
			Blocks.STAINED_GLASS_PANE, Blocks.IRON_BARS, Blocks.SNOW_LAYER, Blocks.ICE, Blocks.PACKED_ICE,
			Blocks.COAL_ORE, Blocks.DIAMOND_ORE, Blocks.EMERALD_ORE, Blocks.CHEST, Blocks.TORCH, Blocks.ANVIL,
			Blocks.TRAPPED_CHEST, Blocks.NOTEBLOCK, Blocks.JUKEBOX, Blocks.TNT, Blocks.GOLD_ORE, Blocks.IRON_ORE,
			Blocks.LAPIS_ORE, Blocks.LIT_REDSTONE_ORE, Blocks.QUARTZ_ORE, Blocks.REDSTONE_ORE,
			Blocks.WOODEN_PRESSURE_PLATE, Blocks.STONE_PRESSURE_PLATE, Blocks.LIGHT_WEIGHTED_PRESSURE_PLATE,
			Blocks.HEAVY_WEIGHTED_PRESSURE_PLATE, Blocks.STONE_BUTTON, Blocks.WOODEN_BUTTON, Blocks.LEVER,
			Blocks.CRAFTING_TABLE, Blocks.FURNACE, Blocks.LIT_FURNACE, Blocks.CACTUS, Blocks.SLIME_BLOCK,
			Blocks.STONE_SLAB, Blocks.STONE_SLAB2, Blocks.WOODEN_SLAB);

	private BlockData blockBelowData;
	private Timer towerTimer = new Timer();

	private float rotations[] = new float[2];

	private float addYaw;
	private float addPitch;

	private int slot = 0;

	int blocksPlaced = 0;

	BooleanSetting tower = new BooleanSetting("Tower", "", true);
	BooleanSetting sprint = new BooleanSetting("Sprint", "", false);
	BooleanSetting slowDown = new BooleanSetting("Slowdown", "", true);

	ItemStack spoofedBlocks;
	Timer randomYawPitchChangeTimer = new Timer();

	public Scaffold() {
		super("Scaffold", "Places blocks beneath you", Category.MISC);
		this.addSettings(tower, sprint, slowDown);
	}

	public void updateRandoms() {

		if (randomYawPitchChangeTimer.hasTimeElapsed(1000, true)) {
			this.addYaw = (float) randomNumber(-8, 8);
			this.addPitch = (float) randomNumber(-3, 3);
		}
	}

	public float[] doScaffoldRotations(Vec3d vec) {
		double diffX = vec.x - mc.player.posX;
		double diffY = vec.y - (mc.player.boundingBox.minY);
		double diffZ = vec.z - mc.player.posZ;
		double dist = MathHelper.sqrt(diffX * diffX + diffZ * diffZ);
		float yaw = (float) (Math.toDegrees(Math.atan2(diffZ, diffX)));
		float pitch = (float) -Math.toDegrees(Math.atan2(diffY, dist));
		return new float[] { mc.player.rotationYaw + MathHelper.wrapDegrees(yaw - mc.player.rotationYaw),
				mc.player.rotationPitch + MathHelper.wrapDegrees(pitch - mc.player.rotationPitch) };
	}

	public float[] getRotations(BlockPos t) {
		return doScaffoldRotations(new Vec3d(blockBelowData.position));
	}
	
	//TODO actually use the onMotion method lol

	public class OldMEvent {
		float yaw, pitch;
		
		
		public void setPitch(float pitch) {
			this.pitch = pitch;
		}
		
		public void setYaw(float yaw) {
			this.yaw = yaw;
		}
	}

	public OldMEvent onMotion(OldMEvent em) {


		try {

			updateRandoms();




			if (!sprint.getValue()) {
				mc.player.setSprinting(false);
			}

			int tempSlot = getBlockSlot();
			blockBelowData = null;
			slot = -1;
			if (tempSlot != -1) {
				double x = mc.player.posX, y = mc.player.posY - 1, z = mc.player.posZ;
				BlockPos blockBelow1 = new BlockPos(x, y, z);


				blockBelowData = getBlockData(blockBelow1);
				slot = tempSlot;
				if (blockBelowData != null) {
					float[] values = getRotations(blockBelowData.position);
					this.rotations = values;

					em.setYaw(values[0] + this.addYaw);
					em.setPitch(values[1] + this.addPitch);

					// mc.player.rotationYawHead = values[0];
				} else {
					if (rotations != null) {

						em.setYaw(rotations[0] + this.addYaw);
						em.setPitch(rotations[1] + this.addPitch);

					}
				}
			}

			if (blockBelowData == null) {
				towerTimer.reset();
				return null;
			}
			if (slot == -1)
				return null;
			if (!mc.world
					.getCollisionBoxes(mc.player,
							mc.player.getEntityBoundingBox().offset(mc.player.motionX, -1, mc.player.motionZ))
					.isEmpty())
				return null;
			boolean dohax = mc.player.inventory.currentItem != slot;
			this.spoofedBlocks = mc.player.inventory.getStackInSlot(slot);

			if (hasSetupSlot == false) {

				sendPacket(new CPacketHeldItemChange(slot));

				hasSetupSlot = true;
			}

			place();

			if (getBlock(blockBelowData.position) == Blocks.AIR) {
				place();
				for (int i = 0; i < 10; i++) {
					if (getBlock(blockBelowData.position) == Blocks.AIR) {
						place();
					}
				}
			}



			if (mc.gameSettings.keyBindJump.pressed && tower.getValue()) {
				mc.player.motionX = mc.player.motionZ = 0;
				mc.player.motionY = 0.42;
				if (towerTimer.hasTimeElapsed(1500, false)) {
					mc.player.motionY = -0.28;
					towerTimer.reset();
				}
			} else {
				towerTimer.reset();
			}

			if (invCheck()) {
				for (int i = 9; i < 36; i++) {
					if (mc.player.inventoryContainer.getSlot(i).getHasStack()) {
						Item item = mc.player.inventoryContainer.getSlot(i).getStack().getItem();
						if (item instanceof ItemBlock && !blacklistedBlocks.contains(((ItemBlock) item).getBlock())
								&& !((ItemBlock) item).getBlock().getLocalizedName().toLowerCase().contains("chest")) {
							swap(i, 7);
							break;
						}
					}
				}
			}
		} catch (Throwable ex) {
			ex.printStackTrace();
		}
		
		return em;

	}

	private void sendPacket(Packet<?> packet) {
		mc.player.connection.sendPacket(packet);
//		mc.networkManager.sendPacket(packet);
	}

	private Block getBlock(BlockPos pos) {
		return mc.world.getBlockState(pos).getBlock();
	}

	public void place() {
//		mc.playerController.processRightClickBlock(player, worldIn, pos, direction, vec, hand)
		if (mc.playerController.processRightClickBlock(mc.player, mc.world,
//				mc.player.inventoryContainer.getSlot(36 + slot).getStack(),
				blockBelowData.position.add(Math.random(), Math.random(), Math.random()), blockBelowData.face,
				new Vec3d(0, 0, 0), EnumHand.MAIN_HAND) == EnumActionResult.SUCCESS) {

			blocksPlaced++;
			mc.player.swingArm(EnumHand.MAIN_HAND);// .swingItem();

			if (slowDown.getValue()) {
				mc.player.motionX *= 0.4;
				mc.player.motionZ *= 0.4;
			}

		}
	}

	private double randomNumber(double max, double min) {
		return Math.round(min + (float) Math.random() * ((max - min)));
	}

	@EventHandler
	private final Listener<PacketEvent.Send> sendListener = new Listener<>(e -> {
		if(nullCheck()) return;

		if (e.getPacket() instanceof CPacketPlayer && rotations != null) {

			CPacketPlayer packet = (CPacketPlayer) e.getPacket();

			OldMEvent start = new OldMEvent();
			start.yaw = packet.yaw;
			start.pitch = packet.pitch;

			OldMEvent end = onMotion(start);

			if(end != null) {
				packet.yaw = end.yaw;
				packet.pitch = end.pitch;
			} else {
				((CPacketPlayer) e.getPacket()).yaw = rotations[0] + this.addYaw;// .setYaw(rotations[0] + this.addYaw);
				((CPacketPlayer) e.getPacket()).pitch = rotations[1] + this.addPitch;// .setPitch(rotations[1] +
				// this.addPitch);
			}


		}

		//TODO use a mixin or an accessor or something, bc i gotta spoof this...

		if(rotations != null && slot != 0) {
			mc.player.inventory.currentItem = slot;
		}
	});

	@Override
	public void onEnable() {
		super.onEnable();

		towerTimer.reset();

		this.addYaw = (float) randomNumber(-8, 8);
		this.addPitch = (float) randomNumber(-3, 3);

		hasSetupSlot = false;

	}

	boolean hasSetupSlot = false;

	@Override
	public void onDisable() {
		
		if(nullCheck()) return;
		
		super.onDisable();

		if (slot != mc.player.inventory.currentItem) {
			sendPacket(new CPacketHeldItemChange(mc.player.inventory.currentItem));
		}

		hasSetupSlot = false;

		blocksPlaced = 0;



		if (mc.player.isSwingInProgress) {
			mc.player.swingProgress = 0;
			mc.player.swingProgressInt = 0;
			mc.player.isSwingInProgress = false;
		}

	}

	protected void swap(int slot, int hotbarNum) {
		mc.playerController.windowClick(mc.player.inventoryContainer.windowId, slot, hotbarNum, ClickType.SWAP, mc.player);
	}

	private boolean invCheck() {
		for (int i = 36; i < 45; i++) {
			if (mc.player.inventoryContainer.getSlot(i).getHasStack()) {
				Item item = mc.player.inventoryContainer.getSlot(i).getStack().getItem();
				if (item instanceof ItemBlock && !blacklistedBlocks.contains(((ItemBlock) item).getBlock())) {
					return false;
				}
			}
		}
		return true;
	}

	public class BlockData {

		public BlockPos position;
		public EnumFacing face;

		private BlockData(BlockPos position, EnumFacing face) {
			this.position = position;
			this.face = face;
		}

	}

	private int getBlockCount() {
		int blockCount = 0;
		for (int i = 0; i < 45; i++) {
			if (mc.player.inventoryContainer.getSlot(i).getHasStack()) {
				ItemStack is = mc.player.inventoryContainer.getSlot(i).getStack();
				Item item = is.getItem();
				if (is.getItem() instanceof ItemBlock && !blacklistedBlocks.contains(((ItemBlock) item).getBlock())) {
					blockCount += is.stackSize;
				}
			}
		}
		return blockCount;
	}

	private boolean isPosSolid(BlockPos pos) {
		Block block = mc.world.getBlockState(pos).getBlock();
		IBlockState ibs = mc.world.getBlockState(pos);

		if ((ibs.getMaterial().isSolid() || !ibs.isTranslucent() || ibs.isFullCube() || block instanceof BlockLadder
				|| block instanceof BlockCarpet || block instanceof BlockSnow || block instanceof BlockSkull)
				&& !ibs.getMaterial().isLiquid() && !(block instanceof BlockContainer)) {
			return true;
		}
		return false;
	}

	private BlockData getBlockData(BlockPos pos) {
		if (!blacklistedBlocks.contains(mc.world.getBlockState(pos.add(0, -1, 0)).getBlock())) {
			return new BlockData(pos.add(0, -1, 0), EnumFacing.UP);
		}
		if (!blacklistedBlocks.contains(mc.world.getBlockState(pos.add(-1, 0, 0)).getBlock())) {
			return new BlockData(pos.add(-1, 0, 0), EnumFacing.EAST);
		}
		if (!blacklistedBlocks.contains(mc.world.getBlockState(pos.add(1, 0, 0)).getBlock())) {
			return new BlockData(pos.add(1, 0, 0), EnumFacing.WEST);
		}
		if (!blacklistedBlocks.contains(mc.world.getBlockState(pos.add(0, 0, -1)).getBlock())) {
			return new BlockData(pos.add(0, 0, -1), EnumFacing.SOUTH);
		}
		if (!blacklistedBlocks.contains(mc.world.getBlockState(pos.add(0, 0, 1)).getBlock())) {
			return new BlockData(pos.add(0, 0, 1), EnumFacing.NORTH);
		}
		BlockPos add = pos.add(-1, 0, 0);
		if (!blacklistedBlocks.contains(mc.world.getBlockState(add.add(-1, 0, 0)).getBlock())) {
			return new BlockData(add.add(-1, 0, 0), EnumFacing.EAST);
		}
		if (!blacklistedBlocks.contains(mc.world.getBlockState(add.add(1, 0, 0)).getBlock())) {
			return new BlockData(add.add(1, 0, 0), EnumFacing.WEST);
		}
		if (!blacklistedBlocks.contains(mc.world.getBlockState(add.add(0, 0, -1)).getBlock())) {
			return new BlockData(add.add(0, 0, -1), EnumFacing.SOUTH);
		}
		if (!blacklistedBlocks.contains(mc.world.getBlockState(add.add(0, 0, 1)).getBlock())) {
			return new BlockData(add.add(0, 0, 1), EnumFacing.NORTH);
		}
		BlockPos add2 = pos.add(1, 0, 0);
		if (!blacklistedBlocks.contains(mc.world.getBlockState(add2.add(-1, 0, 0)).getBlock())) {
			return new BlockData(add2.add(-1, 0, 0), EnumFacing.EAST);
		}
		if (!blacklistedBlocks.contains(mc.world.getBlockState(add2.add(1, 0, 0)).getBlock())) {
			return new BlockData(add2.add(1, 0, 0), EnumFacing.WEST);
		}
		if (!blacklistedBlocks.contains(mc.world.getBlockState(add2.add(0, 0, -1)).getBlock())) {
			return new BlockData(add2.add(0, 0, -1), EnumFacing.SOUTH);
		}
		if (!blacklistedBlocks.contains(mc.world.getBlockState(add2.add(0, 0, 1)).getBlock())) {
			return new BlockData(add2.add(0, 0, 1), EnumFacing.NORTH);
		}
		BlockPos add3 = pos.add(0, 0, -1);
		if (!blacklistedBlocks.contains(mc.world.getBlockState(add3.add(-1, 0, 0)).getBlock())) {
			return new BlockData(add3.add(-1, 0, 0), EnumFacing.EAST);
		}
		if (!blacklistedBlocks.contains(mc.world.getBlockState(add3.add(1, 0, 0)).getBlock())) {
			return new BlockData(add3.add(1, 0, 0), EnumFacing.WEST);
		}
		if (!blacklistedBlocks.contains(mc.world.getBlockState(add3.add(0, 0, -1)).getBlock())) {
			return new BlockData(add3.add(0, 0, -1), EnumFacing.SOUTH);
		}
		if (!blacklistedBlocks.contains(mc.world.getBlockState(add3.add(0, 0, 1)).getBlock())) {
			return new BlockData(add3.add(0, 0, 1), EnumFacing.NORTH);
		}
		BlockPos add4 = pos.add(0, 0, 1);
		if (!blacklistedBlocks.contains(mc.world.getBlockState(add4.add(-1, 0, 0)).getBlock())) {
			return new BlockData(add4.add(-1, 0, 0), EnumFacing.EAST);
		}
		if (!blacklistedBlocks.contains(mc.world.getBlockState(add4.add(1, 0, 0)).getBlock())) {
			return new BlockData(add4.add(1, 0, 0), EnumFacing.WEST);
		}
		if (!blacklistedBlocks.contains(mc.world.getBlockState(add4.add(0, 0, -1)).getBlock())) {
			return new BlockData(add4.add(0, 0, -1), EnumFacing.SOUTH);
		}
		if (!blacklistedBlocks.contains(mc.world.getBlockState(add4.add(0, 0, 1)).getBlock())) {
			return new BlockData(add4.add(0, 0, 1), EnumFacing.NORTH);
		}
		return null;
	}

	public float[] getRotationsBlock(BlockPos pos, EnumFacing facing) {
		double d0 = pos.getX() - mc.player.posX;
		double d2 = pos.getZ() - mc.player.posZ;
		float f = (float) (Math.atan2(d2, d0) * 180.0D / Math.PI) - 90.0F;
		float f1 = 86F;
		return new float[] { f, f1 };
	}

	private int getBlockSlot() {
		for (int i = 36; i < 45; ++i) {
			ItemStack itemStack = mc.player.inventoryContainer.getSlot(i).getStack();
			if (itemStack != null && itemStack.getItem() instanceof ItemBlock) {
				if (blacklistedBlocks.stream().anyMatch(e -> e.equals(((ItemBlock) itemStack.getItem()).getBlock()))) {
					continue;
				}
				return i - 36;
			}
		}
		return -1;
	}

}
