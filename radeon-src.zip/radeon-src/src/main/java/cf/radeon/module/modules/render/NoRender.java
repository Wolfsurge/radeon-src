package cf.radeon.module.modules.render;

import cf.radeon.module.Category;
import cf.radeon.module.Module;
import cf.radeon.module.settings.BooleanSetting;
import net.minecraft.entity.item.EntityFallingBlock;
import net.minecraft.entity.passive.EntityBat;
import net.minecraft.init.SoundEvents;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.client.event.RenderLivingEvent;
import net.minecraftforge.event.entity.PlaySoundAtEntityEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public final class NoRender extends Module {
    public static final BooleanSetting caveCulling = new BooleanSetting("Cave Culling", "Fixes Mojang's cool bug", true);
    public static final BooleanSetting bossbar = new BooleanSetting("Bossbar",
            "Doesnt render wither bars, and some server ads.", false);
    public static final BooleanSetting bats = new BooleanSetting("Bats", "Doesnt render annoying bats", true);
    public static final BooleanSetting potionIcons = new BooleanSetting("Potion Icons",
            "doesnt render potion icons in the top right.", true);

    public static final BooleanSetting advancements = new BooleanSetting("Advancements", "Doesnt render advancements. good feature 10/10", true);


    public static final BooleanSetting hurtcam = new BooleanSetting("Hurtcam", "Doesnt render the hurt animation.", false);

    public static final BooleanSetting falling_sand = new BooleanSetting("Falling sand", "Doesnt render sand if its falling", true);
    public static final BooleanSetting portal = new BooleanSetting("Portal", "Stops the purple texture rendering when in a Nether Portal", true);

    public static NoRender instance;

    public NoRender() {
        super("NoRender", "Stops the rendering of certain things", Category.RENDER);
        this.addSettings(caveCulling, bossbar, bats, potionIcons, advancements, hurtcam, falling_sand, portal);
        instance = this;
    }


    @Override
    public void onUpdate() {
        if(nullCheck()) return;

        if(falling_sand.getValue()) {
            mc.world.loadedEntityList.stream().filter(e -> e instanceof EntityFallingBlock).forEach(e -> mc.world.removeEntity(e));
        }

    }

    @SubscribeEvent
    public void onRenderPre(RenderGameOverlayEvent.Pre event) {
        if(nullCheck()) return;
        if (event.getType() == RenderGameOverlayEvent.ElementType.BOSSINFO && bossbar.getValue()) {
            event.setCanceled(true);
        }

        if (potionIcons.getValue() && event.getType() == RenderGameOverlayEvent.ElementType.POTION_ICONS)
            event.setCanceled(true);

    }

    @SubscribeEvent
    public void onRenderLiving(RenderLivingEvent.Pre<?> event) {
        if(nullCheck()) return;
        if (this.bats.getValue() && event.getEntity() instanceof EntityBat) {
            event.setCanceled(true);
        }
    }

    @SubscribeEvent
    public void onPlaySound(PlaySoundAtEntityEvent event) {
        if(nullCheck()) return;
        if (this.bats.getValue() && event.getSound().equals((Object) SoundEvents.ENTITY_BAT_AMBIENT)
                || event.getSound().equals((Object) SoundEvents.ENTITY_BAT_DEATH)
                || event.getSound().equals((Object) SoundEvents.ENTITY_BAT_HURT)
                || event.getSound().equals((Object) SoundEvents.ENTITY_BAT_LOOP)
                || event.getSound().equals((Object) SoundEvents.ENTITY_BAT_TAKEOFF)) {
            event.setVolume(0.0f);
            event.setPitch(0.0f);
            event.setCanceled(true);
        }
    }

    public boolean advancements() {
        return !nullCheck() && isEnabled() && advancements.getValue();
    }

    public boolean hurtcam() {
        return !nullCheck() && isEnabled() && hurtcam.getValue();
    }
}
