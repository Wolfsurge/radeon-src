package cf.radeon.module.modules.client;

import java.awt.Color;

import cf.radeon.module.Category;
import cf.radeon.module.Module;
import cf.radeon.module.settings.ColourPicker;
import cf.radeon.utils.render.Colour;

public class Colours extends Module {
	public ColourPicker colour = new ColourPicker("Colour", new Colour(255, 117, 46, 255));
	
	public static int colourInt = -1;
	public static Color col = Color.WHITE;
	
	public Colours() {
		super("Colours", "change the clients colour", 0, Category.CLIENT);
		this.addSettings(colour);
	}
	
	@Override
	public void onNonToggledUpdate() {
		this.enabled = false;
		
		colourInt = colour.getColor().getRGB();
		col = colour.getColor();
	}
}
