package cf.radeon.module.modules.render;

import cf.radeon.module.Category;
import cf.radeon.module.Module;
import cf.radeon.module.settings.BooleanSetting;
import cf.radeon.module.settings.ColourPicker;
import cf.radeon.module.settings.ModeSetting;
import cf.radeon.module.settings.NumberSetting;
import cf.radeon.utils.render.RenderUtil3D;
import net.minecraft.util.math.RayTraceResult;
import org.lwjgl.opengl.GL11;

import java.awt.*;

/**
 * @author olliem5
 */

public final class BlockHighlight extends Module {
    public static final BooleanSetting cancelSelectionBox = new BooleanSetting("Cancel Selection Box", "Cancels the rendering of the vanilla block selection box", true);

    public static final BooleanSetting renderBlock = new BooleanSetting("Render", "Allows the facing block to be rendered", true);
    public static final ModeSetting renderMode = new ModeSetting("Render Mode", "The type of box to render", "Full", "Outline", "Box");
    public static final NumberSetting outlineWidth = new NumberSetting("Outline Width", "The width of the outline", 1.0, 2.0, 5.0, 1);
    public static final ColourPicker renderColour = new ColourPicker("Render Colour", "The colour for the facing block", new Color(135, 46, 181, 220));

    public BlockHighlight() {
        super("BlockHighlight", "Highlights the block that you are looking at", Category.RENDER);
        this.addSettings(
                cancelSelectionBox,
                renderBlock,
                renderMode,
                outlineWidth,
                renderColour
        );
    }

    @Override
    public void onRenderWorld() {
        if (nullCheck()) return;

        if (renderBlock.getValue() && mc.objectMouseOver != null && mc.objectMouseOver.typeOfHit == RayTraceResult.Type.BLOCK) {
            GL11.glLineWidth(outlineWidth.getFloatValue());

            RenderUtil3D.draw(mc.objectMouseOver.getBlockPos(),
                    !renderMode.is("Outline"),
                    !renderMode.is("Box"), 0, 0, renderColour.getColor());
        }
    }

    public enum RenderModes {
        Box,
        Outline,
        Full
    }
}
