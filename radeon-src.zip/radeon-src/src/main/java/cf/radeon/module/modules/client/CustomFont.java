package cf.radeon.module.modules.client;

import cf.radeon.module.Category;
import cf.radeon.module.Module;
import cf.radeon.module.settings.ModeSetting;
import cf.radeon.module.settings.NumberSetting;

public class CustomFont extends Module {
	
	public static NumberSetting SHADOW_SPACING = new NumberSetting("Shadow", 0, 1, 1, 0.05);
	public static ModeSetting font = new ModeSetting("Font", "Comfortaa", "Red Hat Mono");
	
	public CustomFont() {
		super("CustomFont", "change font to comfortaa", 0, Category.CLIENT);
		this.addSettings(SHADOW_SPACING);
	}

}
