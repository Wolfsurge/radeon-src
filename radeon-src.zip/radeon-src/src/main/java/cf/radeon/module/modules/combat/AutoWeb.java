package cf.radeon.module.modules.combat;

import cf.radeon.managers.RotationManager;
import cf.radeon.module.Category;
import cf.radeon.module.Module;
import cf.radeon.module.settings.BooleanSetting;
import cf.radeon.module.settings.ColourPicker;
import cf.radeon.module.settings.ModeSetting;
import cf.radeon.module.settings.NumberSetting;
import cf.radeon.utils.combat.TargetUtil;
import cf.radeon.utils.other.ChatUtil;
import cf.radeon.utils.player.InventoryUtil;
import cf.radeon.utils.player.PlayerUtil;
import cf.radeon.utils.render.Colour;
import cf.radeon.utils.render.RenderUtil3D;
import com.mojang.realmsclient.gui.ChatFormatting;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.network.play.client.CPacketPlayerTryUseItemOnBlock;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import org.lwjgl.opengl.GL11;

/**
 * @author olliem5
 *
 * TODO: Fix placing 2 webs, maybe add it as other mode
 */

public final class AutoWeb extends Module {
    public static final ModeSetting targetMode = new ModeSetting("Target", "The target to go for when placing webs", "Self", "Target");
    public static final NumberSetting targetRange = new NumberSetting("Target Range", "The range for a target to be found", 1.0, 4.4, 10.0, 0.1);

    public static final BooleanSetting rotate = new BooleanSetting("Rotate", "Allow for rotations", true);
    public static final ModeSetting rotateMode = new ModeSetting("Mode", "The mode to use for rotations", "Packet", "Legit");

    public static final BooleanSetting renderPlace = new BooleanSetting("Render", "Allows the web placements to be rendered", true);
    public static final ModeSetting renderMode = new ModeSetting("Render Mode", "The type of box to render", "Full", "Outline", "Box");
    public static final NumberSetting outlineWidth = new NumberSetting("Outline Width", "The width of the outline", 1.0, 2.0, 5.0, 0.5);
    public static final ColourPicker renderColour = new ColourPicker("Render Colour", "The colour for the web placements", new Colour(15, 60, 231, 201));

    public AutoWeb() {
        super("AutoWeb", "Places webs at your or a target's feet", Category.COMBAT);
        this.addSettings(
                targetMode,
                targetRange,
                rotate,
                rotateMode,
                renderPlace,
                renderMode,
                outlineWidth,
                renderColour
        );
    }

    private int webSlot;

    private BlockPos renderBlock = null;
    private EntityPlayer target = null;

    @Override
    public void onEnable() {
        if (nullCheck()) return;

        webSlot = InventoryUtil.getHotbarBlockSlot(Blocks.WEB);

        if (webSlot == -1) {
            ChatUtil.addChatMessage("No Webs, " + ChatFormatting.RED + "Disabling!");
            this.toggle();
        }
    }

    @Override
    public void onDisable() {
        if (nullCheck()) return;

        renderBlock = null;
        target = null;
    }

    public void onUpdate() {
        if (nullCheck()) return;

        if (targetMode.is("Self")) {
            target = mc.player;
        } else {
            target = TargetUtil.getClosestPlayer(targetRange.getDoubleValue());
        }

        if (target != null) {
            if (!hasWeb(target)) {
                int oldInventorySlot = mc.player.inventory.currentItem;

                if (webSlot != -1) {
                    mc.player.inventory.currentItem = webSlot;
                }

                if (mc.player.getHeldItemMainhand().getItem() == Item.getItemFromBlock(Blocks.WEB)) {
                    if (rotate.getValue()) {
                        RotationManager.rotateToEntity(target, rotateMode.is("Packet"));
                    }

                    mc.player.connection.sendPacket(new CPacketPlayerTryUseItemOnBlock(new BlockPos(PlayerUtil.getCenter(target.posX, target.posY, target.posZ)), EnumFacing.UP, EnumHand.MAIN_HAND, 0, 0, 0));
                }

                renderBlock = new BlockPos(PlayerUtil.getCenter(target.posX, target.posY, target.posZ));

                mc.player.inventory.currentItem = oldInventorySlot;
            }
        }
    }

    private boolean hasWeb(EntityPlayer entityPlayer) {
        return mc.world.getBlockState(entityPlayer.getPosition()).getBlock() == Blocks.WEB;
    }

    @Override
    public void onRenderWorld() {
        if (nullCheck()) return;

        if (renderPlace.getValue() && renderBlock != null) {
            GL11.glLineWidth(outlineWidth.getFloatValue());

            RenderUtil3D.draw(renderBlock,
                    !renderMode.is("Outline"),
                    !renderMode.is("Box"), 0, 0, renderColour.getColor());
        }
    }

    @Override
    public String getHUDData() {
        if (target != null) {
            return target.getName();
        }

        return "";
    }

    public enum TargetModes {
        Self,
        Target
    }
}
