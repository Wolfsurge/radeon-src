package cf.radeon.module.modules.render;

import cf.radeon.managers.FriendManager;
import cf.radeon.module.Category;
import cf.radeon.module.Module;
import cf.radeon.module.modules.client.Social;
import cf.radeon.module.modules.render.chams.ChamsMode;
import cf.radeon.module.modules.render.chams.modes.Highlight;
import cf.radeon.module.modules.render.chams.modes.Vanilla;
import cf.radeon.module.settings.BooleanSetting;
import cf.radeon.module.settings.ColourPicker;
import cf.radeon.module.settings.ModeSetting;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityEnderCrystal;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.entity.passive.EntityAnimal;
import net.minecraft.entity.player.EntityPlayer;
import java.awt.*;

/**
 * @author olliem5
 *
 * TODO: Fix sheep wool colouring & the weird skeletons with fur
 */

public final class Chams extends Module {
    public static final ModeSetting mode = new ModeSetting("Mode", "The mode to use for Chams", "Highlight", "Vanilla");

    public static final BooleanSetting leftArm = new BooleanSetting("Left Arm", "Allows Chams to function on your left arm", true);
    public static final ColourPicker leftArmColour = new ColourPicker("Left Hand Colour", "The colour for your left arm", new Color(106, 22, 219, 100));

    public static final BooleanSetting rightArm = new BooleanSetting("Right Arm", "Allows Chams to function on your right arm", true);
    public static final ColourPicker rightArmColour = new ColourPicker("Right Hand Colour", "The colour for your right arm", new Color(106, 22, 219, 100));

    public static final BooleanSetting crystals = new BooleanSetting("Crystals", "Allows Chams to function on crystals", true);
    public static final ColourPicker crystalColour = new ColourPicker("Crystal Colour", "The colour for crystals", new Color(106, 22, 219, 100));

    public static final BooleanSetting players = new BooleanSetting("Players", "Allows Chams to function on players", true);
    public static final ColourPicker playerColour = new ColourPicker("Player Colour", "The colour for players", new Color(106, 22, 219, 100));

    public static final BooleanSetting animals = new BooleanSetting("Animals", "Allows Chams to function on animals", true);
    public static final ColourPicker animalColour = new ColourPicker("Animal Colour", "The colour for animals", new Color(75, 219, 22, 100));

    public static final BooleanSetting mobs = new BooleanSetting("Mobs", "Allows Chams to function on animals", true);
    public static final ColourPicker mobColour = new ColourPicker("Mob Colour", "The colour for animals", new Color(236, 13, 29, 100));

    public Chams() {
        super("Chams", "Highlights entities", Category.RENDER);
        this.addSettings(
                mode,
                leftArm,
                leftArmColour,
                rightArm,
                rightArmColour,
                crystals,
                crystalColour,
                players,
                playerColour,
                animals,
                animalColour,
                mobs,
                mobColour
        );
    }

    public static ChamsMode chamsMode;

    public void onUpdate() {
        if (nullCheck()) return;

        switch (mode.getMode()) {
            case "Highlight":
                chamsMode = new Highlight();
                break;
            case "Vanilla":
                chamsMode = new Vanilla();
                break;
        }
    }

    public static Color getChamsColour(Entity entity) {
        if (entity instanceof EntityEnderCrystal) {
            return new Color(crystalColour.getValue().getRed(), crystalColour.getValue().getGreen(), crystalColour.getValue().getBlue(), crystalColour.getValue().getAlpha());
        }

        if (entity instanceof EntityPlayer) {
            if (FriendManager.isFriend(entity.getName())) {
                return new Color(Social.friendColour.getValue().getRed(), Social.friendColour.getValue().getGreen(), Social.friendColour.getValue().getBlue(), Social.friendColour.getValue().getAlpha());
            } else if (!FriendManager.isEnemy(entity.getName())) {
                return new Color(Social.enemyColour.getValue().getRed(), Social.enemyColour.getValue().getGreen(), Social.enemyColour.getValue().getBlue(), Social.enemyColour.getValue().getAlpha());
            } else {
                return new Color(playerColour.getValue().getRed(), playerColour.getValue().getGreen(), playerColour.getValue().getBlue(), playerColour.getValue().getAlpha());
            }
        }

        if (entity instanceof EntityAnimal) {
            return new Color(animalColour.getValue().getRed(), animalColour.getValue().getGreen(), animalColour.getValue().getBlue(), animalColour.getValue().getAlpha());
        }

        if (entity instanceof EntityMob) {
            return new Color(mobColour.getValue().getRed(), mobColour.getValue().getGreen(), mobColour.getValue().getBlue(), mobColour.getValue().getAlpha());
        }

        return new Color(255, 255, 255, 255);
    }

    public static boolean entityCheck(Entity entity) {
        return entity instanceof EntityEnderCrystal && crystals.getValue() || entity instanceof EntityPlayer && players.getValue() || entity instanceof EntityAnimal && animals.getValue() || entity instanceof EntityMob && mobs.getValue();
    }

    public enum ChamsModes {
        Highlight,
        Vanilla
    }
}
