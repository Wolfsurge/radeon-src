package cf.radeon.module.modules.render.esp.modes;

import cf.radeon.module.modules.render.ESP;
import cf.radeon.module.modules.render.esp.ESPMode;

import java.util.Objects;

/**
 * @author olliem5
 */

public final class Glow extends ESPMode {
    @Override
    public void drawESP() {
        mc.world.loadedEntityList.stream()
                .filter(Objects::nonNull)
                .filter(entity -> mc.player != entity)
                .filter(ESP::entityCheck)
                .forEach(entity -> entity.setGlowing(true));
    }
}
