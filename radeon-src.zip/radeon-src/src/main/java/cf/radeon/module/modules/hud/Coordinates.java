package cf.radeon.module.modules.hud;

import cf.radeon.module.Category;
import cf.radeon.module.Module;

public class Coordinates extends Module {

    public Coordinates() {
        super("Coordinates", "Displays the player's coordinates on screen.", Category.HUD, true);
    }

}
