package cf.radeon.module.modules.misc;

import cf.radeon.module.Category;
import cf.radeon.module.Module;
import cf.radeon.module.settings.BooleanSetting;
import cf.radeon.utils.other.ChatUtil;
import cf.radeon.utils.other.MathUtil;
import com.mojang.realmsclient.gui.ChatFormatting;
import net.minecraft.client.gui.GuiGameOver;
import net.minecraftforge.client.event.GuiOpenEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

/**
 * @author olliem5
 */

public final class AutoRespawn extends Module {
    public static final BooleanSetting printCoordinates = new BooleanSetting("Print Coordinates", "Prints your death coordinates client side when you respawn", true);

    public AutoRespawn() {
        super("AutoRespawn", "Automatically respawns you when you die", Category.MISC);
        this.addSettings(
                printCoordinates
        );
    }

    @SubscribeEvent
    public void onGuiOpen(GuiOpenEvent event) {
        if (nullCheck()) return;

        if (event.getGui() instanceof GuiGameOver) {
            if (printCoordinates.getValue()) {
                ChatUtil.addChatMessage("You " + ChatFormatting.RED + "died " + ChatFormatting.WHITE + "at [" + MathUtil.roundAvoid(mc.player.posX, 1) + ", " + MathUtil.roundAvoid(mc.player.posY, 1) + ", " + MathUtil.roundAvoid(mc.player.posZ, 1) + "].");
            }

            mc.player.respawnPlayer();
            mc.displayGuiScreen(null);
        }
    }
}
