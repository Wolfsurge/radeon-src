package cf.radeon.module.modules.movement;

import cf.radeon.module.Category;
import cf.radeon.module.Module;
import cf.radeon.module.settings.BooleanSetting;
import net.minecraft.client.gui.GuiChat;
import net.minecraftforge.client.event.InputUpdateEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.input.Keyboard;

/**
 * @author olliem5
 */

public final class NoSlow extends Module {
    public static final BooleanSetting blocks = new BooleanSetting("Blocks", "Allows NoSlow to stop blocks from slowing you down", true);
    public static final BooleanSetting soulSand = new BooleanSetting("Soul Sand", "Allows soul sand slowness to cease", true);
    public static final BooleanSetting slimeBlocks = new BooleanSetting("Slime Blocks", "Allows slime block slowness to cease", true);

    public static final BooleanSetting guiMove = new BooleanSetting("GUI Move", "Allows you to move in GUI's", true);
    public static final BooleanSetting arrowKeyLook = new BooleanSetting("Arrow Key Look", "Allows you to look around with the arrow keys", true);

    public NoSlow() {
        super("NoSlow", "Prevents using items from slowing you down", Category.MOVEMENT);
        this.addSettings(
                blocks,
                soulSand,
                slimeBlocks,
                guiMove,
                arrowKeyLook
        );
    }

    public void onUpdate() {
        if (nullCheck()) return;

        if (guiMove.getValue()) {
            if (mc.currentScreen != null && !(mc.currentScreen instanceof GuiChat) && guiMove.getValue()) {
                if (arrowKeyLook.getValue()) {
                    if (Keyboard.isKeyDown(200)) {
                        mc.player.rotationPitch -= 5;
                    }

                    if (Keyboard.isKeyDown(208)) {
                        mc.player.rotationPitch += 5;
                    }

                    if (Keyboard.isKeyDown(205)) {
                        mc.player.rotationYaw += 5;
                    }

                    if (Keyboard.isKeyDown(203)) {
                        mc.player.rotationYaw -= 5;
                    }

                    if (mc.player.rotationPitch > 90) {
                        mc.player.rotationPitch = 90;
                    }

                    if (mc.player.rotationPitch < -90) {
                        mc.player.rotationPitch = -90;
                    }
                }
            }
        }
    }

    @SubscribeEvent
    public void onInputUpdate(InputUpdateEvent event) {
        if (nullCheck()) return;

        if (mc.player.isHandActive() && !mc.player.isRiding()) {
            event.getMovementInput().moveStrafe *= 5;
            event.getMovementInput().moveForward *= 5;
        }
    }
}
