package cf.radeon.module.modules.client;

import cf.radeon.Radeon;
import cf.radeon.clickgui.ClickGui;
import cf.radeon.module.Category;
import cf.radeon.module.Module;
import cf.radeon.module.settings.BooleanSetting;
import cf.radeon.module.settings.ColourPicker;
import cf.radeon.utils.render.Colour;
import org.lwjgl.input.Keyboard;

import java.awt.*;

public class ClickGuiModule extends Module {

	public static ClickGuiModule INSTANCE;

	public static BooleanSetting darken = new BooleanSetting("Darken", "Whether to darken the background of the ClickGUI", false);
	public static BooleanSetting reset = new BooleanSetting("Reset", "Reset the ClickGUI", false);
	public static BooleanSetting limit = new BooleanSetting("LimitPositions", "Limit the frame's X and Y to the displays boundaries", true);

	public static BooleanSetting rainbow = new BooleanSetting("Rainbow", false);
	public static ColourPicker header = new ColourPicker("Header", new Colour(255, 117, 46, 255));
	public static ColourPicker background = new ColourPicker("Background", new Color(14,14,14));
	public static ColourPicker hovered = new ColourPicker("Hovered", 0xFF222222);
	public static ColourPicker enabled = new ColourPicker("Enabled", new Color(14,14,14));
	public static ColourPicker enabledText = new ColourPicker("Enabled Text", new Colour(255, 117, 46, 255));
	public static ColourPicker slider = new ColourPicker("Slider", new Colour(255, 117, 46, 255));

	public ClickGuiModule() {
		super("ClickGUI", "idk clickgui open for settings etc", Keyboard.KEY_RSHIFT, Category.CLIENT);
		this.addSettings(reset, darken, limit, rainbow, header, background, hovered, enabled, slider);
		INSTANCE = this;
	}

	@Override
	public void onEnable() {
		mc.displayGuiScreen(Radeon.clickGui);
		toggle();
	}
	
	@Override
	public void onNonToggledUpdate() {
		if(reset.isEnabled()) {
			Radeon.clickGui.reset();
			reset.enabled = false;
		}
	}
}
