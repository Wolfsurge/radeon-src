package cf.radeon.module.modules.movement;

import cf.radeon.module.Category;
import cf.radeon.module.Module;
import cf.radeon.module.settings.NumberSetting;

public class Flight extends Module {

    public static NumberSetting speedInAir = new NumberSetting("Speed in air", "the speed kind of", 0.01F, 0.025F, 0.05F, 0.01);

    public Flight() {
        super("Flight", "Simple flight module. its a motion flight not vanilla", Category.MOVEMENT);
        this.addSettings(speedInAir);
    }

    @Override
    public void onUpdate() {
        if(nullCheck()) return;
        mc.player.motionY = 0.0;
        mc.player.speedInAir = speedInAir.getFloatValue();
    }

    public void onDisable() {
        if(nullCheck()) return;
        mc.player.speedInAir = 0.02F;
    }
}
