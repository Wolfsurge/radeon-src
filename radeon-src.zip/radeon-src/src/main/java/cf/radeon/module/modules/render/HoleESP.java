package cf.radeon.module.modules.render;

import cf.radeon.module.Category;
import cf.radeon.module.Module;
import cf.radeon.module.settings.BooleanSetting;
import cf.radeon.module.settings.ColourPicker;
import cf.radeon.module.settings.ModeSetting;
import cf.radeon.module.settings.NumberSetting;
import cf.radeon.utils.block.BlockUtil;
import cf.radeon.utils.block.hole.HoleUtil;
import cf.radeon.utils.render.RenderUtil3D;
import net.minecraft.util.math.BlockPos;
import org.lwjgl.opengl.GL11;

import java.awt.*;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @author olliem5
 */

public final class HoleESP extends Module {
    public static final NumberSetting holeRange = new NumberSetting("Hole Range", "The range to search for holes in", 1, 5, 10, 1);

    public static final BooleanSetting obsidian = new BooleanSetting("Obsidian Holes", "Allows obsidian holes to be rendered", true);
    public static final ModeSetting obsidianRenderMode = new ModeSetting("O Render Mode", "The type of box to render", "Full", "Outline", "Box");
    public static final NumberSetting obsidianBoxHeight = new NumberSetting("O Box Height", "The height of the box", -1.0, -0.7, 2.0, 0.1);
    public static final NumberSetting obsidianOutlineHeight = new NumberSetting("O Outline Height", "The height of the outline", -1.0, -0.7, 2.0, 0.1);
    public static final NumberSetting obsidianOutlineWidth = new NumberSetting("O Outline Width", "The width of the outline", 1.0, 2.0, 5.0, 0.1);
    public static final ColourPicker obsidianHoleColour = new ColourPicker("Obsidian Hole Colour", "The colour for obsidian holes", new Color(234, 37, 58, 169));

    public static final BooleanSetting mixed = new BooleanSetting("Mixed Holes", "Allows bedrock/obby holes to be rendered", true);
    public static final ModeSetting mixedRenderMode = new ModeSetting("M Render Mode", "The type of box to render", "Full", "Outline", "Box");
    public static final NumberSetting mixedBoxHeight = new NumberSetting("M Box Height", "The height of the box", -1.0, -0.7, 2.0, 0.1);
    public static final NumberSetting mixedOutlineHeight = new NumberSetting("M Outline Height", "The height of the outline", -1.0, -0.7, 2.0, 0.1);
    public static final NumberSetting mixedOutlineWidth = new NumberSetting("M Outline Width", "The width of the outline", 1.0, 2.0, 5.0, 0.1);
    public static final ColourPicker mixedHoleColour = new ColourPicker("Mixed Hole Colour", "The colour for Mixed holes", new Color(235, 171, 38, 169));

    public static final BooleanSetting bedrock = new BooleanSetting("Bedrock Holes", "Allows bedrock holes to be rendered", true);
    public static final ModeSetting bedrockRenderMode = new ModeSetting("B Render Mode", "The type of box to render", "Full", "Outline", "Box");
    public static final NumberSetting bedrockBoxHeight = new NumberSetting("B Box Height", "The height of the box", -1.0, -0.7, 2.0, 0.1);
    public static final NumberSetting bedrockOutlineHeight = new NumberSetting("B Outline Height", "The height of the outline", -1.0, -0.7, 2.0, 0.1);
    public static final NumberSetting bedrockOutlineWidth = new NumberSetting("B Outline Width", "The width of the outline", 1.0, 2.0, 5.0, 0.1);
    public static final ColourPicker bedrockHoleColour = new ColourPicker("Bedrock Hole Colour", "The colour for bedrock holes", new Color(61, 194, 46, 169));

    public static final BooleanSetting enderChest = new BooleanSetting("Ender Chest Holes", "Allows ender chest holes to be rendered", true);
    public static final ModeSetting enderChestRenderMode = new ModeSetting("E Render Mode", "The type of box to render", "Full", "Outline", "Box");
    public static final NumberSetting enderChestBoxHeight = new NumberSetting("E Box Height", "The height of the box", -1.0, -0.7, 2.0, 0.1);
    public static final NumberSetting enderChestOutlineHeight = new NumberSetting("E Outline Height", "The height of the outline", -1.0, -0.7, 2.0, 0.1);
    public static final NumberSetting enderChestOutlineWidth = new NumberSetting("E Outline Width", "The width of the outline", 1.0, 2.0, 5.0, 0.1);
    public static final ColourPicker enderChestHoleColour = new ColourPicker("Ender Chest Hole Colour", "The colour for ender chest holes", new Color(222, 38, 38, 169));

    public static final BooleanSetting enchantingTable = new BooleanSetting("Enchant Table Holes", "Allows enchanting table holes to be rendered", true);
    public static final ModeSetting enchantRenderMode = new ModeSetting("ET Render Mode", "The type of box to render", "Full", "Outline", "Box");
    public static final NumberSetting enchantingTableBoxHeight = new NumberSetting("ET Box Height", "The height of the box", -1.0, -0.7, 2.0, 0.1);
    public static final NumberSetting enchantingTableOutlineHeight = new NumberSetting("ET Outline Height", "The height of the outline", -1.0, -0.7, 2.0, 0.1);
    public static final NumberSetting enchantingTableOutlineWidth = new NumberSetting("ET Outline Width", "The width of the outline", 1.0, 2.0, 5.0, 0.1);
    public static final ColourPicker enchantingTableHoleColour = new ColourPicker("Enchanting Table Hole Colour", "The colour for enchanting table holes", new Color(222, 38, 38, 169));

    public static final BooleanSetting anvil = new BooleanSetting("Anvil Holes", "Allows mixed holes to be rendered", true);
    public static final ModeSetting anvilRenderMode = new ModeSetting("A Render Mode", "The type of box to render", "Full", "Outline", "Box");
    public static final NumberSetting anvilBoxHeight = new NumberSetting("A Box Height", "The height of the box", -1.0, -0.7, 2.0, 0.1);
    public static final NumberSetting anvilOutlineHeight = new NumberSetting("A Outline Height", "The height of the outline", -1.0, -0.7, 2.0, 0.1);
    public static final NumberSetting anvilOutlineWidth = new NumberSetting("A Outline Width", "The width of the outline", 1.0, 2.0, 5.0, 0.1);
    public static final ColourPicker anvilHoleColour = new ColourPicker("Anvil Hole Colour", "The colour for mixed holes", new Color(222, 38, 38, 169));

    public HoleESP() {
        super("HoleESP", "Highlights safe holes for crystal pvp", Category.RENDER);
        this.addSetting(holeRange);
        this.addSettings(obsidian, obsidianRenderMode, obsidianBoxHeight, obsidianOutlineHeight, obsidianOutlineWidth, obsidianHoleColour);
        this.addSettings(mixed, mixedRenderMode, mixedBoxHeight, mixedOutlineHeight, mixedOutlineWidth, mixedHoleColour);
        this.addSettings(bedrock, bedrockRenderMode, bedrockBoxHeight, bedrockOutlineHeight, bedrockOutlineWidth, bedrockHoleColour);
        this.addSettings(enderChest, enderChestRenderMode, enderChestBoxHeight, enderChestOutlineHeight, enderChestOutlineWidth, enderChestHoleColour);
        this.addSettings(enchantingTable, enchantRenderMode, enchantingTableBoxHeight, enchantingTableOutlineHeight, enchantingTableOutlineWidth, enchantingTableHoleColour);
        this.addSettings(anvil, anvilRenderMode, anvilBoxHeight, anvilOutlineHeight, anvilOutlineWidth, anvilHoleColour);
    }

    public List<BlockPos> findObsidianHoles() {
        return BlockUtil.getNearbyBlocks(mc.player, holeRange.getDoubleValue(), false).stream()
                .filter(HoleUtil::isObsidianHole)
                .collect(Collectors.toList());
    }

    public List<BlockPos> findMixedHoles() {
        return BlockUtil.getNearbyBlocks(mc.player, holeRange.getDoubleValue(), false).stream()
                .filter(HoleUtil::isMixedHole)
                .collect(Collectors.toList());
    }

    public List<BlockPos> findBedrockHoles() {
        return BlockUtil.getNearbyBlocks(mc.player, holeRange.getDoubleValue(), false).stream()
                .filter(HoleUtil::isBedrockHole)
                .collect(Collectors.toList());
    }

    public List<BlockPos> findEnderChestHoles() {
        return BlockUtil.getNearbyBlocks(mc.player, holeRange.getDoubleValue(), false).stream()
                .filter(HoleUtil::isEnderChestHole)
                .collect(Collectors.toList());
    }

    public List<BlockPos> findEnchantingTableHoles() {
        return BlockUtil.getNearbyBlocks(mc.player, holeRange.getDoubleValue(), false).stream()
                .filter(HoleUtil::isEnchantingTableHole)
                .collect(Collectors.toList());
    }

    public List<BlockPos> findAnvilHoles() {
        return BlockUtil.getNearbyBlocks(mc.player, holeRange.getDoubleValue(), false).stream()
                .filter(HoleUtil::isAnvilHole)
                .collect(Collectors.toList());
    }

    @Override
    public void onRenderWorld() {
        if (nullCheck()) return;

        List<BlockPos> obsidianHoles = findObsidianHoles();
        List<BlockPos> bedrockHoles = findBedrockHoles();
        List<BlockPos> mixedHoles = findBedrockHoles();
        List<BlockPos> enderChestHoles = findEnderChestHoles();
        List<BlockPos> enchantingTableHoles = findEnchantingTableHoles();
        List<BlockPos> anvilHoles = findAnvilHoles();

        if (obsidian.getValue() && obsidianHoles != null) {
            GL11.glLineWidth(obsidianOutlineWidth.getFloatValue());

            for (BlockPos obsidianHole : findObsidianHoles()) {
                RenderUtil3D.draw(obsidianHole, obsidianRenderMode.getMode() != "Outline", obsidianRenderMode.getMode() != "Box", obsidianBoxHeight.getFloatValue(), obsidianOutlineHeight.getFloatValue(), obsidianHoleColour.getValue());
            }
        }

        if (obsidian.getValue() && mixedHoles != null) {
            GL11.glLineWidth(mixedOutlineWidth.getFloatValue());

            for (BlockPos mixedHole : findMixedHoles()) {
                RenderUtil3D.draw(mixedHole, mixedRenderMode.getMode() != "Outline", mixedRenderMode.getMode() != "Box", mixedBoxHeight.getFloatValue(), mixedOutlineHeight.getFloatValue(), mixedHoleColour.getValue());
            }
        }

        if (bedrock.getValue() && bedrockHoles != null) {
            GL11.glLineWidth(bedrockOutlineWidth.getFloatValue());

            for (BlockPos bedrockHole : findBedrockHoles()) {
                RenderUtil3D.draw(bedrockHole, bedrockRenderMode.getMode() != "Outline", bedrockRenderMode.getMode() != "Box", bedrockBoxHeight.getFloatValue(), bedrockOutlineHeight.getFloatValue(), bedrockHoleColour.getValue());
            }
        }

        if (enderChest.getValue() && enderChestHoles != null) {
            GL11.glLineWidth(enderChestOutlineWidth.getFloatValue());

            for (BlockPos enderChestHole : findEnderChestHoles()) {
                RenderUtil3D.draw(enderChestHole, enderChestRenderMode.getMode() != "Outline", enderChestRenderMode.getMode() != "Box", enderChestBoxHeight.getFloatValue(), enderChestOutlineHeight.getFloatValue(), enderChestHoleColour.getValue());
            }
        }

        if (enchantingTable.getValue() && enchantingTableHoles != null) {
            GL11.glLineWidth(enchantingTableOutlineWidth.getFloatValue());

            for (BlockPos enchantingTableHole : findEnchantingTableHoles()) {
                RenderUtil3D.draw(enchantingTableHole, enchantRenderMode.getMode() != "Outline", enchantRenderMode.getMode() != "Box", enchantingTableBoxHeight.getFloatValue(), enchantingTableOutlineHeight.getFloatValue(), enchantingTableHoleColour.getValue());
            }
        }

        if (anvil.getValue() && anvilHoles != null) {
            GL11.glLineWidth(anvilOutlineWidth.getFloatValue());

            for (BlockPos anvilHole : findAnvilHoles()) {
                RenderUtil3D.draw(anvilHole, anvilRenderMode.getMode() != "Outline", anvilRenderMode.getMode() != "Box", anvilBoxHeight.getFloatValue(), anvilOutlineHeight.getFloatValue(), anvilHoleColour.getValue());
            }
        }
    }

    public enum RenderModes {
        Box,
        Outline,
        Full
    }
}
