package cf.radeon.module.modules.combat;

import cf.radeon.event.impl.PacketEvent;
import cf.radeon.module.Category;
import cf.radeon.module.Module;
import cf.radeon.module.settings.BooleanSetting;
import cf.radeon.module.settings.ColourPicker;
import cf.radeon.module.settings.ModeSetting;
import cf.radeon.module.settings.NumberSetting;
import cf.radeon.utils.combat.CooldownUtil;
import cf.radeon.utils.combat.crystal.CrystalUtils;
import cf.radeon.utils.combat.piston.BlockUtils;
import cf.radeon.utils.combat.piston.TargetUtils;
import cf.radeon.utils.other.ChatUtil;
import cf.radeon.utils.player.InventoryUtils;
import cf.radeon.utils.render.Colour;
import cf.radeon.utils.render.RenderUtil3D;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.minecraft.block.BlockCompressedPowered;
import net.minecraft.block.BlockEmptyDrops;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityEnderCrystal;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumFacing.Axis;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import org.lwjgl.opengl.GL11;

/**
 *
 * I made the esp
 *
 * @author Z3R0
 *
 */

public class PistonAura extends Module {

    public static final NumberSetting range = new NumberSetting("Range", "The range", 0.1, 5.2, 10.0,
            1);
    public static final BooleanSetting checkPiston = new BooleanSetting("Check Piston", "duh", true);

    public static final BooleanSetting autoDisable = new BooleanSetting("Disable after explode",
            "disabled the module when a crystal is blown up.", false);

    public static final BooleanSetting dev = new BooleanSetting("Developer mode",
            "Make it work on zombies as well as players, to test things.", false);

    public static final BooleanSetting crystalRender = new BooleanSetting("Render",
            "Enabled all rendering features for pistonaura", true);
    public static final ModeSetting blockRenderMode = new ModeSetting("Block Mode",
            "The type of box to render", "Full", "Box", "Outline", "None");
    public static final NumberSetting outlineWidth = new NumberSetting("Outline Width",
            "The width of the outline", 1.0, 2.0, 5.0, 0.5);
    public static final ColourPicker renderColour = new ColourPicker("Render Colour", "the color",
            new Colour(231, 15, 101, 180));

    public PistonAura() {
        super("PistonAura", "best pistonaura out there lmao", Category.COMBAT);
        this.addSettings(range, checkPiston, autoDisable, crystalRender, blockRenderMode, outlineWidth, renderColour, dev);
    }

    int progress = 0;

    EnumFacing facing;
    int sleep;

    BlockPos renderPos;

    @Override
    public void onEnable() {
        progress = 0;
        super.onEnable();
    }

    @Override
    public void onDisable() {
        if (nullCheck())
            return;
        renderPos = null;
        super.onDisable();
    }

    CooldownUtil delay = new CooldownUtil();

    @EventHandler
    public final Listener<PacketEvent.Send> sendListener = new Listener<>(event -> {
        if (nullCheck())
            return;

        if (event.getPacket() instanceof CPacketPlayer) {
            CPacketPlayer packet = (CPacketPlayer) event.getPacket();
            if (progress > 0) {
                switch (facing) {

                    case NORTH:
                        packet.yaw = 180;
                        break;
                    case SOUTH:
                        packet.yaw = 0;
                        break;
                    case WEST:
                        packet.yaw = 90;
                        break;
                    case EAST:
                        packet.yaw = -90;
                        break;

                    case UP:
                        // up doesnt need to work lmao
                        break;

                }
                packet.pitch = 90;
            }
        }
    });

    @Override
    public void onUpdate() {
        if (nullCheck())
            return;
        // this makes it have delay, and work lmao
        // its just a crystalaura with this tick delay off
        if (!delay.passed(50))
            return;

        delay.reset();

        InventoryUtils.push();
        TargetUtils.findTarget(range.getFloatValue());
        if (TargetUtils.getDistance(null) > range.getFloatValue())
            return;
        Entity entity = TargetUtils.currentTarget;

        if (entity instanceof EntityPlayer) {
            int obsidian = InventoryUtils.pickItem(49, false);
            int piston = InventoryUtils.pickItem(33, false);
            int power = InventoryUtils.pickItem(152, false);
            int crystal = InventoryUtils.pickItem(426, false);

            if (obsidian == -1 || piston == -1 || power == -1 || (crystal == -1 && !mc.player.inventory.offHandInventory
                    .get(0).getItem().getClass().equals(Item.getItemById(426).getClass()))) {
                toggle();
                return;
            }

            // ここいじれば高さ変えれる(後ろに".offset(EnumFacing.UP)"追加)
            BlockPos pos = new BlockPos(entity).offset(EnumFacing.UP);
            //

            if (sleep > 0) {
                sleep--;
            } else {
                switch (progress) {
                    case 0:

                        facing = getFacing(pos);

                        if (facing == null)
                            return;

                        BlockPos Pos = new BlockPos(pos).offset(facing).offset(EnumFacing.DOWN);

                        renderPos = Pos;

                        InventoryUtils.setSlot(obsidian);

                        BlockUtils event = BlockUtils.isPlaceable(Pos, 0, false);

                        BlockUtils.doPlace(event, true);

                        Pos = new BlockPos(pos).offset(facing).offset(facing).offset(EnumFacing.DOWN);

                        InventoryUtils.setSlot(obsidian);

                        event = BlockUtils.isPlaceable(Pos, 0, false);

                        BlockUtils.doPlace(event, true);

                        progress++;
                        break;
                    case 1:
                        // piston
                        Pos = new BlockPos(pos).offset(facing, 2);
                        InventoryUtils.setSlot(piston);
                        event = BlockUtils.isPlaceable(Pos, 0, false);
                        BlockUtils.doPlace(event, true);

                        // power
                        Pos = new BlockPos(pos).offset(facing, 3);
                        InventoryUtils.setSlot(power);
                        event = BlockUtils.isPlaceable(Pos, 0, false);
                        BlockUtils.doPlace(event, false);
                        for (EnumFacing f : EnumFacing.values()) {
                            if (f == facing.rotateY().rotateY())
                                continue;
                            if (!(mc.world.getBlockState(Pos).getBlock() instanceof BlockCompressedPowered)) {
                                Pos = new BlockPos(pos).offset(facing, 2).offset(f);
                                event = BlockUtils.isPlaceable(Pos, 0, false);
                                BlockUtils.doPlace(event, false);
                            }
                        }

                        // crystal
                        Pos = new BlockPos(pos).offset(facing);
                        CrystalUtils.placeCrystal(Pos);

                        int i = 0;
                        for (Entity target : mc.world.loadedEntityList) {
                            if (entity.getDistance(target) > range.getFloatValue())
                                continue;
                            if (target instanceof EntityEnderCrystal) {
                                mc.playerController.attackEntity(mc.player, target);
                                i++;
                            }
                        }

                        if (i > 0) {
                            mc.world.setBlockToAir(pos.offset(facing, 1));
                            if (mc.world.getBlockState(pos.offset(facing, 2)).getBlock() instanceof BlockEmptyDrops)
                                mc.world.setBlockToAir(pos.offset(facing, 1).offset(EnumFacing.UP));
                            else
                                mc.world.setBlockToAir(pos.offset(facing, 2));
                        }

                        progress = 1;
                        sleep += mc.player.ticksExisted % 2 == 0 ? 1 : 0;

//					renderPos = null;

                        if (autoDisable.getValue()) {
                            toggle();
                        }

                        break;
                }
            }
        }
        InventoryUtils.pop();

    }

    public EnumFacing getFacing(BlockPos position) {
        for (EnumFacing f : EnumFacing.values()) {
            if (f.getAxis().equals(Axis.Y))
                continue;

            BlockPos pos = new BlockPos(position).offset(f);

            if (mc.world.isAirBlock(pos.offset(f, 0)) && mc.world.isAirBlock(pos.offset(f, 1))
                    && mc.world.checkNoEntityCollision(new AxisAlignedBB(pos, pos.offset(f, 2)))) {

                for (EnumFacing fa : EnumFacing.values()) {
                    if (fa == f.rotateY().rotateY())
                        continue;
                    if (mc.world.isAirBlock(pos.offset(f, 1).offset(fa))) {
                        return f;
                    }
                }
            }
        }
        return null;
    }
    // renderPos


    @Override
    public void onRenderWorld() {
        if (nullCheck())
            return;

        GlStateManager.pushMatrix();

        try {
            if (crystalRender.getValue() && renderPos != null) {
                GL11.glLineWidth(outlineWidth.getFloatValue());

                if (!blockRenderMode.is("None")) {
                    try {
                        RenderUtil3D.draw(renderPos, !blockRenderMode.is("Outline"),
                                !blockRenderMode.is("Box"), 0, 0, renderColour.getColor());
                    } catch (Throwable e) {
                    }

                }

            }
        } catch (Throwable e) {
            e.printStackTrace();
            ChatUtil.addChatMessage("pistonaura error: msg in console!");
        }

        GlStateManager.popMatrix();
    }

}
