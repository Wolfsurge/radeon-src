package cf.radeon.module.modules.render;

import java.awt.Color;
import java.util.HashMap;

import cf.radeon.module.Category;
import cf.radeon.module.Module;
import cf.radeon.module.settings.BooleanSetting;
import cf.radeon.module.settings.ColourPicker;
import cf.radeon.module.settings.NumberSetting;
import cf.radeon.utils.render.Colour;
import cf.radeon.utils.render.RenderUtil3D;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityChest;
import net.minecraft.tileentity.TileEntityEnderChest;
import net.minecraft.tileentity.TileEntityShulkerBox;
import net.minecraft.util.math.BlockPos;

public class StorageESP extends Module {

    long lastUpdate = System.currentTimeMillis();

    HashMap<BlockPos, BlockTypeRender> storage = new HashMap<BlockPos, StorageESP.BlockTypeRender>();

    public enum BlockTypeRender {
        CHEST, SHULK, ECHEST;
    }

    NumberSetting range = new NumberSetting("Range", "The range to search in", 10d, 100d, 400d, 1);

    BooleanSetting box = new BooleanSetting("Fill", "Fill the storage esp thingies", true);
    BooleanSetting outline = new BooleanSetting("Outline", "outline the storage esp thingies", false);

    BooleanSetting chests = new BooleanSetting("Chests", "Render Chests", true);
    ColourPicker chests_color = new ColourPicker("Chest Color", "The chest color", new Colour(Color.ORANGE));

    BooleanSetting shulkers = new BooleanSetting("Shulkers", "Render shulkers", true);
    ColourPicker shulkers_color = new ColourPicker("Shulker Color", "The shulker color", new Colour(Color.RED));

    BooleanSetting echests = new BooleanSetting("EChests", "Render enderchests", true);
    ColourPicker echests_color = new ColourPicker("EChest Color", "The echest color", new Colour(Color.MAGENTA));

    public StorageESP() {
        super("StorageESP","Render storage stuff", Category.RENDER);
        this.addSettings(range, box, outline, chests, chests_color, shulkers, shulkers_color, echests, echests_color);

    }

    @Override
    public void onUpdate() {

    }

    @Override
    public void onRenderWorld() {
        if (nullCheck())
            return;

        for(TileEntity e : mc.world.loadedTileEntityList) {
            if(e instanceof TileEntityChest && chests.enabled) {
                RenderUtil3D.draw(e.getPos(), box.getValue(), outline.getValue(), 0, 0, chests_color.getColor());
            }

            if(e instanceof TileEntityShulkerBox && shulkers.enabled) {
                RenderUtil3D.draw(e.getPos(), box.getValue(), outline.getValue(), 0, 0, shulkers_color.getColor());
            }

            if(e instanceof TileEntityEnderChest && echests.enabled) {
                RenderUtil3D.draw(e.getPos(), box.getValue(), outline.getValue(), 0, 0, echests_color.getColor());
            }
        }
    }

    private double getDistance(BlockPos b) {
        return mc.player.getDistanceSq(b);
    }

    private void update() {
        storage.clear();

        mc.world.loadedTileEntityList.forEach(te -> {
            if(chests.getValue() && te instanceof TileEntityChest) {
                storage.put(te.getPos(), BlockTypeRender.CHEST);
            }

            if(shulkers.getValue() && te instanceof TileEntityShulkerBox) {
                storage.put(te.getPos(), BlockTypeRender.SHULK);
            }

            if(echests.getValue() && te instanceof TileEntityEnderChest) {
                storage.put(te.getPos(), BlockTypeRender.ECHEST);
            }
        });
    }
}
