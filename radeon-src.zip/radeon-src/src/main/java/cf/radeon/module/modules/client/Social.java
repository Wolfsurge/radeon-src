package cf.radeon.module.modules.client;

import cf.radeon.module.Category;
import cf.radeon.module.Module;
import cf.radeon.module.settings.BooleanSetting;
import cf.radeon.module.settings.ColourPicker;
import cf.radeon.utils.render.Colour;

/**
 * @author olliem5
 */

public final class Social extends Module {
    public static final BooleanSetting friends = new BooleanSetting("Friends", "Allows for usage of the friends system", true);
    public static final ColourPicker friendColour = new ColourPicker("Friend Colour", "The colour to render friends with", new Colour(0, 255, 0, 100));

    public static final BooleanSetting enemies = new BooleanSetting("Enemies", "Allows for usage of the enemy system", true);
    public static final ColourPicker enemyColour = new ColourPicker("Enemy Colour", "The colour to render enemies with", new Colour(255, 0, 0, 100));

    public Social() {
        super("Social", "Allows for usage of the social system", Category.CLIENT);
        this.addSettings(
                friends,
                friendColour,
                enemies,
                enemyColour
        );

        this.enabled = true;
        this.visible.enabled = false;
    }

    @Override
    public void onNonToggledUpdate() {
        this.enabled = true;
    }

    @Override
    public void onDisable() {
        if (nullCheck()) return;

        this.enabled = true;
    }

    @Override
    public String getHUDData() {
        if (friends.getValue() && enemies.getValue()) {
            return "Friends, Enemies";
        } else if (friends.getValue() && !enemies.getValue()) {
            return "Friends";
        } else if (!friends.getValue() && enemies.getValue()) {
            return "Enemies";
        }

        return "";
    }
}
