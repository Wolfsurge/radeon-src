package cf.radeon.module.modules.render.esp.modes;

import cf.radeon.module.modules.render.ESP;
import cf.radeon.module.modules.render.esp.ESPMode;
import cf.radeon.utils.entity.EntityUtil;
import cf.radeon.utils.render.RenderUtil3D;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.opengl.GL11;
import java.util.Objects;
import static org.lwjgl.opengl.GL11.GL_LINE_LOOP;

/**
 * @author olliem5
 */

public final class CSGO extends ESPMode {
    @Override
    public void drawESP() {
        try {
            boolean isThirdPersonFrontal = mc.getRenderManager().options.thirdPersonView == 2;
            float viewerYaw = mc.getRenderManager().playerViewY;

            mc.world.loadedEntityList.stream()
                    .filter(Objects::nonNull)
                    .filter(entity -> mc.player != entity)
                    .filter(ESP::entityCheck)
                    .forEach(entity -> {
                        RenderUtil3D.prepareGL();

                        Vec3d vec3d = EntityUtil.getInterpolatedPos(entity, mc.getRenderPartialTicks());

                        GL11.glLineWidth(ESP.lineWidth.getFloatValue());

                        GlStateManager.translate(vec3d.x - mc.getRenderManager().renderPosX, vec3d.y - mc.getRenderManager().renderPosY, vec3d.z - mc.getRenderManager().renderPosZ);
                        GlStateManager.glNormal3f(0.0f, 1.0f, 0.0f);
                        GlStateManager.rotate(-viewerYaw, 0.0f, 1.0f, 0.0f);
                        GlStateManager.rotate((float) (isThirdPersonFrontal ? -1 : 1), 1.0f, 0.0f, 0.0f);

                        GL11.glColor4f(ESP.getESPColour(entity).getRed() / 255.0f, ESP.getESPColour(entity).getGreen() / 255.0f, ESP.getESPColour(entity).getBlue() / 255.0f, ESP.getESPColour(entity).getAlpha() / 255.0f);

                        GL11.glBegin(GL_LINE_LOOP);
                        {
                            GL11.glVertex2d(-entity.width, 0);
                            GL11.glVertex2d(-entity.width, entity.height / 3);
                            GL11.glVertex2d(-entity.width, 0);
                            GL11.glVertex2d((-entity.width / 3) * 2, 0);
                        }

                        GL11.glEnd();

                        GL11.glBegin(GL_LINE_LOOP);
                        {
                            GL11.glVertex2d(-entity.width, entity.height);
                            GL11.glVertex2d((-entity.width / 3) * 2, entity.height);
                            GL11.glVertex2d(-entity.width, entity.height);
                            GL11.glVertex2d(-entity.width, (entity.height / 3) * 2);
                        }

                        GL11.glEnd();

                        GL11.glBegin(GL_LINE_LOOP);
                        {
                            GL11.glVertex2d(entity.width, entity.height);
                            GL11.glVertex2d((entity.width / 3) * 2, entity.height);
                            GL11.glVertex2d(entity.width, entity.height);
                            GL11.glVertex2d(entity.width, (entity.height / 3) * 2);
                        }

                        GL11.glEnd();

                        GL11.glBegin(GL_LINE_LOOP);
                        {
                            GL11.glVertex2d(entity.width, 0);
                            GL11.glVertex2d((entity.width / 3) * 2, 0);
                            GL11.glVertex2d(entity.width, 0);
                            GL11.glVertex2d(entity.width, entity.height / 3);
                        }

                        GL11.glEnd();

                        RenderUtil3D.releaseGL();
                    });
        } catch (Exception e) {}
    }
}
