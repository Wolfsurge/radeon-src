package cf.radeon.module.modules.hud;

import cf.radeon.module.Category;
import cf.radeon.module.Module;

public class FPS extends Module {

    public FPS() {
        super("FPS", "Displays your FPS on screen.", Category.HUD, true);
    }

}
