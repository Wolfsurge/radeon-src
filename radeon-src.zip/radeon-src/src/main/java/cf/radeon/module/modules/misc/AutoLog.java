package cf.radeon.module.modules.misc;

import cf.radeon.module.Category;
import cf.radeon.module.Module;
import cf.radeon.module.settings.BooleanSetting;
import cf.radeon.module.settings.ModeSetting;
import cf.radeon.module.settings.NumberSetting;
import net.minecraft.client.gui.GuiMainMenu;

/**
 * @author olliem5
 */

public final class AutoLog extends Module {
    public static final ModeSetting logMode = new ModeSetting("Mode", "How the module makes you disconnect from the server", "Disconnect", "Kick");
    public static final BooleanSetting toggleAfter = new BooleanSetting("Toggle After", "Toggles the module after a disconnect happens", true);
    public static final NumberSetting logHealth = new NumberSetting("Health", "The health to be on to be disconnected", 0.0f, 10.0f, 36.0f, 1);

    public AutoLog() {
        super("AutoLog", "Leaves the server you are on at a specified health", Category.MISC);
        this.addSettings(
                logMode,
                toggleAfter,
                logHealth
        );
    }

    public void onUpdate() {
        if (nullCheck()) return;

        if (mc.player.getHealth() <= logHealth.getFloatValue()) {
            switch (logMode.getMode()) {
                case "Disconnect":
                    mc.world.sendQuittingDisconnectingPacket();
                    mc.loadWorld(null);
                    mc.displayGuiScreen(new GuiMainMenu());
                    break;
                case "Kick":
                    mc.player.inventory.currentItem = 69420;
                    break;
            }

            if (toggleAfter.getValue()) {
                this.toggle();
            }
        }
    }

    @Override
    public String getHUDData() {
        return logMode.getMode() + ", " + logHealth.getFloatValue();
    }
}
