package cf.radeon.module.modules.movement;

import cf.radeon.module.Category;
import cf.radeon.module.Module;
import cf.radeon.module.settings.BooleanSetting;
import cf.radeon.module.settings.ModeSetting;

public class Speed extends Module {
    public static final ModeSetting mode = new ModeSetting("Mode", "The type of speed", "CPVPCC", "Ghost", "NOAC");
    public static final BooleanSetting cancelMotionOnDisable = new BooleanSetting("Stop motion on disable", "Sets your motion to 0 when its disabled", false);

    public Speed() {
        super("Speed", "Strafe, but a better name.", Category.MOVEMENT);
        addSettings(mode, cancelMotionOnDisable);
    }

    @Override
    public void onDisable() {
        if(nullCheck()) return;
        mc.player.speedInAir = 0.02F;

        if(cancelMotionOnDisable.getValue()) {
            mc.player.motionX = 0;
            mc.player.motionY = 0;
            mc.player.motionZ = 0;
        }
    }

    @Override
    public void onUpdate() {
        if(!this.isEnabled() || nullCheck()) return;

        switch(mode.getMode()) {
            case "CPVPCC": {
                if(mc.player.onGround) {
                    mc.player.jump();
                    mc.player.speedInAir = 0.02F;
                    double friction = 0.8;
                    mc.player.motionX *= friction;
                    mc.player.motionZ *= friction;
                } else {
                    mc.player.speedInAir = 0.0226F;
                }
                break;
            }

            case "Ghost": {
                if(mc.player.onGround) {
                    mc.player.jump();
                }
                break;
            }

            case "NOAC": {
                if(mc.player.onGround) {
                    mc.player.jump();
                }

                mc.player.speedInAir = 0.6F;

                break;
            }

        }

    }

    @Override
    public String getHUDData() {
        return mode.getMode();
    }
}
