package cf.radeon.module.modules.combat;

import cf.radeon.managers.RotationManager;
import cf.radeon.module.Category;
import cf.radeon.module.Module;
import cf.radeon.module.settings.BooleanSetting;
import cf.radeon.module.settings.ColourPicker;
import cf.radeon.module.settings.ModeSetting;
import cf.radeon.module.settings.NumberSetting;
import cf.radeon.utils.block.hole.HoleUtil;
import cf.radeon.utils.combat.TargetUtil;
import cf.radeon.utils.render.Colour;
import cf.radeon.utils.render.RenderUtil3D;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.network.play.client.CPacketPlayerTryUseItemOnBlock;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import org.lwjgl.opengl.GL11;

import java.util.Objects;

/**
 * @author olliem5
 */

public final class AutoCreeper extends Module {
    public static final ModeSetting attackMode = new ModeSetting("Mode", "The mode for attacking players", "Hole", "Always");
    public static final NumberSetting targetRange = new NumberSetting("Target Range", "The range for a target to be found", 1.0, 4.4, 10.0, 0.1);

    public static final BooleanSetting rotate = new BooleanSetting("Rotate", "Allow for rotations", true);
    public static final ModeSetting rotateMode = new ModeSetting("Mode", "The mode to use for rotations", "Packet", "Legit");

    public static final BooleanSetting renderPlace = new BooleanSetting("Render", "Allows the creeper egg placements to be rendered", true);
    public static final ModeSetting renderMode = new ModeSetting("Render Mode", "The type of box to render", "Full", "Box", "Outline");
    public static final NumberSetting outlineWidth = new NumberSetting("Outline Width", "The width of the outline", 1.0, 2.0, 5.0, 0.5);
    public static final ColourPicker renderColour = new ColourPicker("Render Colour", "The colour for the creeper egg placements", new Colour(102, 216, 231, 201));

    public AutoCreeper() {
        super("AutoCreeper", "Automatically places creeper eggs at player's feet, for anarchypvp.pw", Category.COMBAT);
        this.addSettings(
                attackMode,
                targetRange,
                rotate,
                rotateMode,
                renderPlace,
                renderMode,
                outlineWidth,
                renderColour
        );
    }

    private boolean offhand = false;

    private BlockPos placePosition = null;
    private EntityPlayer target = null;

    @Override
    public void onDisable() {
        if (nullCheck()) return;

        placePosition = null;
        target = null;
    }

    public void onUpdate() {
        if (nullCheck()) return;

        target = TargetUtil.getClosestPlayer(targetRange.getFloatValue());

        offhand = mc.player.getHeldItemOffhand().getItem() == Items.SPAWN_EGG;

        mc.world.playerEntities.stream()
                .filter(Objects::nonNull)
                .filter(target -> target != mc.player)
                .filter(target -> !target.isDead)
                .filter(target -> target.getHealth() > 0)
                .filter(target -> mc.player.getDistance(target) <= targetRange.getFloatValue())
                .filter(target -> HoleUtil.isPlayerInHole(target) || attackMode.is("Always"))
                .forEach(target -> {
                    placePosition = new BlockPos(target.posX, target.posY -1, target.posZ);

                    if (mc.player.getHeldItemMainhand().getItem() == Items.SPAWN_EGG || mc.player.getHeldItemOffhand().getItem() == Items.SPAWN_EGG) {
                        if (rotate.getValue()) {
                            RotationManager.rotateToBlockPos(placePosition, rotateMode.is("Packet"));
                        }

                        mc.player.connection.sendPacket(new CPacketPlayerTryUseItemOnBlock(placePosition, EnumFacing.UP, offhand ? EnumHand.OFF_HAND : EnumHand.MAIN_HAND, 0, 0, 0));
                    }
                });
    }

    @Override
    public void onRenderWorld() {
        if (nullCheck()) return;

        if (renderPlace.getValue() && placePosition != null) {
            GL11.glLineWidth(outlineWidth.getFloatValue());

            RenderUtil3D.draw(placePosition,
                    !renderMode.is("Outline"),
                    !renderMode.is("Box"), 0, 0, renderColour.getColor());
        }
    }

    @Override
    public String getHUDData() {
        if (target != null) {
            return target.getName();
        }

        return "";
    }

    public enum AttackModes {
        Hole,
        Always
    }

    public enum RotationModes {
        Packet,
        Legit
    }

    public enum RenderModes {
        Box,
        Outline,
        Full
    }
}
