package cf.radeon.module.modules.combat;

import java.awt.Color;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import cf.radeon.event.impl.PacketEvent;
import cf.radeon.module.Category;
import cf.radeon.module.Module;
import cf.radeon.module.modules.combat.crystal.BlockUtil;
import cf.radeon.module.settings.BooleanSetting;
import cf.radeon.module.settings.ColourPicker;
import cf.radeon.module.settings.NumberSetting;
import cf.radeon.utils.entity.EntityUtil;
import cf.radeon.utils.other.ItemUtil;
import cf.radeon.utils.other.Timer;
import cf.radeon.utils.render.Colour;
import cf.radeon.utils.render.RenderUtil3D;
import me.wolfsurge.mixin.mixins.accessor.ICPacketUseEntity;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityEnderCrystal;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.init.SoundEvents;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketPlayerTryUseItemOnBlock;
import net.minecraft.network.play.client.CPacketUseEntity;
import net.minecraft.network.play.client.CPacketUseEntity.Action;
import net.minecraft.network.play.server.SPacketSoundEffect;
import net.minecraft.network.play.server.SPacketSpawnObject;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.BlockPos;

public class AutoCrystalRewrite2 extends Module {

    BooleanSetting placeT = new BooleanSetting("Place", "Place crystals", true);
    BooleanSetting autoSwitch = new BooleanSetting("AutoSwitch", "Switch to a crystal.", false);
    private NumberSetting placeRange = new NumberSetting("PlaceRange",
            "the range to place crystals from.", 1, 5, 6, 1);
    NumberSetting armorScale = new NumberSetting("ArmorScale",
            "the armor scale for place calculation", 0, 10, 100, 1);
    NumberSetting facePlaceHp = new NumberSetting("FaceplaceHP", "The HP to faceplace at", 0.0, 8,
            36f, 1);
    NumberSetting minDamage = new NumberSetting("MinDamage", "The minimum damage.", 1, 4, 36, 1);
    NumberSetting maxSelfDamage = new NumberSetting("MaxSelfDamage", "The maximum damage.", 1, 8,
            36f, 1);
    BooleanSetting secondCheck = new BooleanSetting("SecondCheck", "check x2", true);
    BooleanSetting onePointThirteen = new BooleanSetting("1.13+", "enable this if its >1.12.2", false);

    BooleanSetting breakT = new BooleanSetting("Break", "Break settings", true);
    NumberSetting breakRange = new NumberSetting("BreakRange", "The range to break crystals from", 1,
            5, 6, 0.1);
    NumberSetting breakWallRange = new NumberSetting("BreakWallsRange",
            "The range to break crystals from thru walls", 1f, 5f, 6f, 1);
    NumberSetting breakDelay = new NumberSetting("BreakDelay", "The break delay", 0, 0, 150, 1);
    BooleanSetting instant = new BooleanSetting("InstantBreak", "Break crystals instantly", true);
    NumberSetting instantDelay = new NumberSetting("InstantBreakDelay", "the delay", 0, 0, 50, 1);

    BooleanSetting targetT = new BooleanSetting("Target", "target settingss", true);
    NumberSetting range = new NumberSetting("Range", "Maximum range for CA targets", 1f, 9f, 15f, 1);

    BooleanSetting miscT = new BooleanSetting("Misc", "Misc settings.", true);
    BooleanSetting soundRemove = new BooleanSetting("SoundRemove", "Remove crystals from sound packets", true);
    BooleanSetting debug = new BooleanSetting("Debug", "Debug stuff", false);

    BooleanSetting renderT = new BooleanSetting("Render", "render settings", true);
    ColourPicker rendercolor = new ColourPicker("RenderColor", "the rendering color", new Colour(Color.CYAN));
    BooleanSetting renderBox = new BooleanSetting("Fill", "render the filled thing", true);
    BooleanSetting renderOutline = new BooleanSetting("Outline", "render the outline thing", true);
    BooleanSetting renderEpic = new BooleanSetting("RenderEpic", "epik rendering w/ delay", true);
    private cf.radeon.utils.combat.CombatUtil CombatUtil;

    public AutoCrystalRewrite2() {
        super("ACRewrite2", "v crystalaura", Category.COMBAT);
        addSettings(placeT, autoSwitch, placeRange, armorScale, facePlaceHp, minDamage, maxSelfDamage, secondCheck, onePointThirteen); // Place
        addSettings(breakT, breakRange, breakWallRange, breakDelay, instant, instantDelay); // Break
        addSettings(targetT, range); // Targeting
        addSettings(miscT, soundRemove, debug); // Misc
        addSettings(renderT, rendercolor, renderBox, renderOutline, renderEpic); // Render
        placeSet = new HashSet<>();
        clearTimer = new Timer();
        breakTimer = new Timer();
        predictedId = -1;
        renderPos = null;
        currentTarget = null;
        coolDown = false;
    }

    private Set<BlockPos> placeSet;
    private final Timer clearTimer;
    private final Timer breakTimer;
    private int predictedId;
    private BlockPos renderPos;
    private EntityPlayer currentTarget;
    private boolean offhand;
    private boolean mainhand;
    private boolean coolDown;

    private long epicRenderDelay = -1;

    HashMap<BlockPos, Double> epicRenderingData = new HashMap<BlockPos, Double>();

    @Override
    public void onRenderWorld() {
        if (nullCheck())
            return;

        if (renderT.getValue() && renderPos != null) {

            if (renderEpic.getValue()) {

                for (BlockPos pos : epicRenderingData.keySet()) {
                    Color c = applyAlpha(rendercolor.getColor(), (int) ((epicRenderingData.get(pos) / 5d) * rendercolor.getColor().getAlpha()));
                    RenderUtil3D.draw(renderPos, renderBox.getValue(), renderOutline.getValue(), 0, 0, c);
                }

            } else {
                RenderUtil3D.draw(renderPos, renderBox.getValue(), renderOutline.getValue(), 0, 0, rendercolor.getColor());
            }

        }
    }

    private Color applyAlpha(Color value, int i) {
        return new Color(value.getRed(), value.getGreen(), value.getBlue(), i);
    }

    @Override
    public void onUpdate() {
        if (nullCheck())
            return;

        if (renderEpic.getValue() && System.currentTimeMillis() - epicRenderDelay >= 200) {
            ArrayList<BlockPos> remove = new ArrayList<BlockPos>();
            for (BlockPos pos : epicRenderingData.keySet()) {
                double value = epicRenderingData.get(pos);
                if (value - .5d <= 0) {
                    remove.add(pos);
                } else {
                    value -= .5d;
                    epicRenderingData.replace(pos, value);
                }
            }

            remove.forEach(b -> epicRenderingData.remove(b));

        }

        if (clearTimer.hasReached(500L)) {
            placeSet.clear();
            predictedId = -1;
            coolDown = false;
            renderPos = null;
            clearTimer.reset();
        }

        offhand = mc.player.getHeldItemOffhand().getItem() == Items.END_CRYSTAL;
        mainhand = mc.player.getHeldItemMainhand().getItem() == Items.END_CRYSTAL;

        currentTarget = CombatUtil.getTarget(range.getFloatValue());
        if(currentTarget != null && currentTarget.getName().contains("ArchKing")) {
            currentTarget = null;
        }

        if (currentTarget != null) {
            doPlace();
            doBreak();
        }

    }

    private void doPlace() {
        BlockPos placePos = null;
        float maxDamage = 0.5F;
        List<?> sphere = BlockUtil.getSphere(placeRange.getFloatValue(), true);
        int size = sphere.size();

        for (int i = 0; i < size; ++i) {
            BlockPos pos = (BlockPos) sphere.get(i);

            if (BlockUtil.canPlaceCrystal(pos, secondCheck.getValue(), onePointThirteen.getValue())) {
                float self = calculate(pos, mc.player);

                if (EntityUtil.getHealth(mc.player) > self + 0.5F
                        && (maxSelfDamage.getFloatValue() > self)) {
                    float damage = calculate(pos, currentTarget);

                    if (damage > maxDamage && damage > self && (damage > minDamage.getFloatValue()
                            || (((Float) facePlaceHp.getFloatValue() > EntityUtil.getHealth(currentTarget)
                            || ItemUtil.isArmorLow(currentTarget, ((Integer) armorScale.getIntValue()))
                            && damage > 2.0F)))) {
                        maxDamage = damage;
                        placePos = pos;
                    }
                }
            }
        }

        if (!offhand && !mainhand && !(Boolean) autoSwitch.getValue()) {
            renderPos = null;
        } else {
            if (placePos != null) {
                if (autoSwitch.getValue()) {
                    doSwitch();
                }

                mc.getConnection().sendPacket(new CPacketPlayerTryUseItemOnBlock(placePos, EnumFacing.UP,
                        offhand ? EnumHand.OFF_HAND : EnumHand.MAIN_HAND, 0.5F, 0.5F, 0.5F));
                placeSet.add(placePos);

                if (renderEpic.getValue()) {
                    if (epicRenderingData.containsKey(placePos)) {


                        if(epicRenderingData.get(placePos) <= 1) {
                            epicRenderingData.replace(placePos, 5d);
                        }


                    } else {
                        epicRenderingData.put(placePos, 5d);
                    }
                }

                renderPos = placePos;
            } else {
                renderPos = null;
            }

        }
    }

    private void doSwitch() {
        int slot = ItemUtil.getItemFromHotbar(Items.END_CRYSTAL);

        if (slot != -1 && !coolDown) {
            if (mc.player.getHeldItemOffhand().getItem() != Items.GOLDEN_APPLE
                    && (mc.player.getHeldItemMainhand().getItem() != Items.GOLDEN_APPLE || !mc.player.isHandActive())) {
                mc.player.inventory.currentItem = slot;
                coolDown = true;
            }
        }
    }

    private void doBreak() {
        Entity entity = null;
        int size = mc.world.loadedEntityList.size();

        for (int i = 0; i < size; ++i) {
            Entity crystal = (Entity) mc.world.loadedEntityList.get(i);

            if (crystal instanceof EntityEnderCrystal && isValid(crystal) && crystal.getEntityId() != predictedId) {
                float self = calculate(crystal, mc.player);

                if (EntityUtil.getHealth(mc.player) > self + 0.5F) {
                    float damage = calculate(crystal, currentTarget);

                    if (damage > self && (damage > minDamage.getFloatValue()
                            || (facePlaceHp.getFloatValue() > EntityUtil.getHealth(currentTarget)
                            || ItemUtil.isArmorLow(currentTarget, armorScale.getIntValue()))
                            && damage > 2.0F)) {
                        entity = crystal;
                    }
                }
            }
        }

        if (entity != null && breakTimer.hasReached((long) (breakDelay.getIntValue()))) {
            mc.getConnection().sendPacket(new CPacketUseEntity(entity));
            mc.player.swingArm(offhand ? EnumHand.OFF_HAND : EnumHand.MAIN_HAND);
            breakTimer.reset();
        }

    }

    public void log(String info) {
        if (debug.getValue()) {
            // debug(info);
        }
    }

    private boolean isValid(Entity crystal) {
        return (double) (mc.player.canEntityBeSeen(crystal)
                ? ((Float) breakRange.getFloatValue()) * ((Float) breakRange.getFloatValue())
                : ((Float) breakWallRange.getFloatValue())
                * ((Float) breakWallRange.getFloatValue())) > mc.player.getDistanceSq(crystal);
    }

    private float calculate(Entity crystal, EntityPlayer target) {
        return EntityUtil.calculate(crystal.posX, crystal.posY, crystal.posZ, target);
    }

    private float calculate(BlockPos pos, EntityPlayer entity) {
        return EntityUtil.calculate((float) pos.getX() + 0.5F, (double) (pos.getY() + 1),
                (float) pos.getZ() + 0.5F, entity);
    }

    public void instantHit(int id) {
        ICPacketUseEntity hitPacket = (ICPacketUseEntity) (new CPacketUseEntity());
        hitPacket.setEntityId(id);
        hitPacket.setAction(Action.ATTACK);
        mc.getConnection().sendPacket((Packet<?>) hitPacket);
        predictedId = id;
        mc.player.swingArm(offhand ? EnumHand.OFF_HAND : EnumHand.MAIN_HAND);
    }

    @EventHandler
    private final Listener<PacketEvent.Receive> receiveListener = new Listener<>(event -> {
        if (nullCheck())
            return;

        if (event.getPacket() instanceof SPacketSpawnObject && instant.getValue()) {
            SPacketSpawnObject packet = (SPacketSpawnObject) event.getPacket();
            BlockPos entities = new BlockPos(packet.getX(), packet.getY(), packet.getZ());

            if (packet.getType() == 51 && placeSet.contains(entities.down())) {
                if (mc.player.getDistance(entities.getX(), entities.getY(),
                        entities.getZ()) > (double) ((Float) breakRange.getFloatValue())) {
                    return;
                }

                if (instantDelay.getIntValue() != 0) {
                    try {
                        Thread.sleep((long) ((Integer) instantDelay.getIntValue()));
                    } catch (Exception ignored) {}
                }

                instantHit(packet.getEntityID());
            }
        }

        if (event.getPacket() instanceof SPacketSoundEffect && soundRemove.getValue()) {
            SPacketSoundEffect spacketsoundeffect = (SPacketSoundEffect) event.getPacket();

            if (spacketsoundeffect.getCategory() == SoundCategory.BLOCKS
                    && spacketsoundeffect.getSound() == SoundEvents.ENTITY_GENERIC_EXPLODE) {
                ArrayList<Entity> arraylist = new ArrayList<Entity>(mc.world.loadedEntityList);
                int size = arraylist.size();

                for (int i = 0; i < size; ++i) {
                    Entity entity = (Entity) arraylist.get(i);

                    if (entity instanceof EntityEnderCrystal && entity.getDistanceSq(spacketsoundeffect.getX(),
                            spacketsoundeffect.getY(), spacketsoundeffect.getZ()) < 36.0D) {
                        entity.setDead();
                    }
                }
            }
        }
    });
}
