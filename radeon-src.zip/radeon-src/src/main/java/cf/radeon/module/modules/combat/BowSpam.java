package cf.radeon.module.modules.combat;

import cf.radeon.module.Category;
import cf.radeon.module.Module;
import cf.radeon.module.settings.NumberSetting;
import net.minecraft.item.ItemBow;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketPlayerDigging;
import net.minecraft.network.play.client.CPacketPlayerTryUseItem;
import net.minecraft.util.math.BlockPos;

public class BowSpam extends Module {

    NumberSetting ticks = new NumberSetting("Ticks", "# of ticks until next release.", 0, 3, 40, 1);

    public BowSpam() {
        super("BowSpam", "spam ur bow", Category.COMBAT);
        this.addSettings(ticks);
    }

    private int _ticks;

    public void onUpdate() {
        if(nullCheck()) return;
        if (mc.player.getHeldItemMainhand().getItem() instanceof ItemBow && mc.player.isHandActive()
                && mc.player.getItemInUseMaxCount() >= 3 && ++_ticks >= ticks.getIntValue()) {
            _ticks = 0;
            mc.player.connection
                    .sendPacket((Packet) new CPacketPlayerDigging(CPacketPlayerDigging.Action.RELEASE_USE_ITEM,
                            BlockPos.ORIGIN, mc.player.getHorizontalFacing()));
            mc.player.connection.sendPacket((Packet) new CPacketPlayerTryUseItem(mc.player.getActiveHand()));
            mc.player.stopActiveHand();
        }
    }
}
