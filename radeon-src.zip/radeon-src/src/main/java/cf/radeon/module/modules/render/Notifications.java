package cf.radeon.module.modules.render;

import cf.radeon.Radeon;
import cf.radeon.module.Category;
import cf.radeon.module.Module;
import cf.radeon.module.settings.BooleanSetting;
import cf.radeon.module.settings.ModeSetting;
import cf.radeon.notifications.Notification;
import cf.radeon.notifications.NotificationType;

public class Notifications extends Module {

    public static ModeSetting mode = new ModeSetting("Mode", "How to render the notifications", "PC", "Chat", "Render");
    public static BooleanSetting toggled = new BooleanSetting("Module Toggled", false);

    public Notifications() {
        super("Notifications", "Renders notifications when certain events happen", Category.RENDER);
        this.addSetting(mode);
        this.addSettings(toggled);
    }

    @Override
    public void onRenderGUI() {
        if(mode.is("Render"))
            Radeon.notificationManager.render();
    }

    @Override
    public void onEnable() {

    }
}
