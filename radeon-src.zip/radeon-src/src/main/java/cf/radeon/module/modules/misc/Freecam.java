package cf.radeon.module.modules.misc;

import cf.radeon.event.impl.PacketEvent;
import cf.radeon.event.impl.TravelEvent;
import cf.radeon.module.Category;
import cf.radeon.module.Module;
import cf.radeon.module.settings.BooleanSetting;
import cf.radeon.module.settings.ModeSetting;
import cf.radeon.module.settings.NumberSetting;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.minecraft.client.entity.EntityOtherPlayerMP;
import net.minecraft.entity.Entity;
import net.minecraft.network.play.client.*;
import net.minecraftforge.client.event.PlayerSPPushOutOfBlocksEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

/**
 * @author olliem5
 */

public final class Freecam extends Module {
    public static final ModeSetting mode = new ModeSetting("Mode", "The mode to use for freecam, use camera for baritone", "Normal", "Camera");
    public static final NumberSetting speed = new NumberSetting("Speed", "The speed to move the camera at", 0.01f, 0.20f, 0.40f, 0.01);

    public static final BooleanSetting cancelPackets = new BooleanSetting("Cancel Packets", "Cancels packets when you are in freecam", true);
    public static final BooleanSetting cPacketPlayer = new BooleanSetting("CPacketPlayer", "Cancels the CPacketPlayer packet in freecam", true);
    public static final BooleanSetting cPacketInput = new BooleanSetting("CPacketInput", "Cancels the CPacketInput packet in freecam", true);
    public static final BooleanSetting cPacketUseEntity = new BooleanSetting("CPacketUseEntity", "Cancels the CPacketUseEntity packet in freecam", true);
    public static final BooleanSetting cPacketPlayerTryUseItem = new BooleanSetting("CPacketPlayerTryUseItem", "Cancels the CPacketPlayerTryUseItem packet in freecam", true);
    public static final BooleanSetting cPacketPlayerTryUseItemOnBlock = new BooleanSetting("CPacketPlayerTryUseItemOnBlock", "Cancels the CPacketPlayerTryUseItemOnBlock packet in freecam", true);
    public static final BooleanSetting cPacketVehicleMove = new BooleanSetting("CPacketVehicleMove", "Cancels the CPacketVehicleMove packet in freecam", true);

    public Freecam() {
        super("Freecam", "Moves your camera outside of your body", Category.MISC);
        this.addSettings(
                mode,
                speed,
                cancelPackets,
                cPacketPlayer,
                cPacketInput,
                cPacketUseEntity,
                cPacketPlayerTryUseItem,
                cPacketPlayerTryUseItemOnBlock,
                cPacketVehicleMove
        );
    }

    private double posX;
    private double posY;
    private double posZ;

    private float pitch;
    private float yaw;

    private boolean isRidingEntity;

    private Entity ridingEntity = null;
    private EntityOtherPlayerMP fakePlayer = null;

    @Override
    public void onEnable() {
        if (nullCheck()) return;

        if (mode.is("Normal")) {
            isRidingEntity = mc.player.getRidingEntity() != null;

            if (mc.player.getRidingEntity() == null) {
                posX = mc.player.posX;
                posY = mc.player.posY;
                posZ = mc.player.posZ;
            } else {
                ridingEntity = mc.player.getRidingEntity();
                mc.player.dismountRidingEntity();
            }

            pitch = mc.player.rotationPitch;
            yaw = mc.player.rotationYaw;

            generateFakePlayer();

            mc.player.noClip = true;
            mc.player.capabilities.isFlying = true;
            mc.player.capabilities.setFlySpeed(speed.getFloatValue());
        } else {
            generateFakePlayer();

            fakePlayer.noClip = true;
            fakePlayer.capabilities.isFlying = true;
            fakePlayer.capabilities.setFlySpeed(speed.getFloatValue());

            mc.setRenderViewEntity(fakePlayer);
        }
    }

    private void generateFakePlayer() {
        fakePlayer = new EntityOtherPlayerMP(mc.world, mc.getSession().getProfile());
        fakePlayer.copyLocationAndAnglesFrom(mc.player);
        fakePlayer.rotationYaw = mc.player.rotationYaw;
        fakePlayer.rotationYawHead = mc.player.rotationYawHead;
        fakePlayer.inventory.copyInventory(mc.player.inventory);

        mc.world.addEntityToWorld(fakePlayer.entityId, fakePlayer);
    }

    @Override
    public void onDisable() {
        if (nullCheck()) return;

        if (mode.is("Normal")) {
            mc.player.noClip = false;
            mc.player.capabilities.isFlying = false;
            mc.player.capabilities.setFlySpeed(0.05f);
            mc.player.setPositionAndRotation(posX, posY, posZ, yaw, pitch);

            posX = posY = posZ = 0.0;
            pitch = yaw = 0.0f;

            mc.player.motionX = mc.player.motionY = mc.player.motionZ = 0.0f;

            if (isRidingEntity) {
                mc.player.startRiding(ridingEntity, true);
            } else {
                ridingEntity = null;
            }
        } else {
            fakePlayer.noClip = false;
            fakePlayer.capabilities.isFlying = false;
            fakePlayer.capabilities.setFlySpeed(0.05f);

            mc.setRenderViewEntity(mc.player);
        }

        mc.world.removeEntityFromWorld(fakePlayer.entityId);

        fakePlayer = null;
    }

    public void onUpdate() {
        if (nullCheck()) return;

        if (mode.is("Normal")) {
            mc.player.noClip = true;
            mc.player.onGround = false;
            mc.player.fallDistance = 0;
            mc.player.capabilities.isFlying = true;
            mc.player.capabilities.setFlySpeed(speed.getFloatValue());
        } else {
            fakePlayer.noClip = true;
            fakePlayer.capabilities.isFlying = true;
            fakePlayer.capabilities.setFlySpeed(speed.getFloatValue());
        }
    }
    
    @EventHandler
    private final Listener<PacketEvent.Send> sendListener = new Listener<>(event -> {
        if (nullCheck()) return;

        if (mode.is("Normal")) {
            if (cancelPackets.getValue() && cPacketPlayer.getValue() && event.getPacket() instanceof CPacketPlayer) {
                event.cancel();
            } else if (cancelPackets.getValue() && cPacketInput.getValue() && event.getPacket() instanceof CPacketInput) {
                event.cancel();
            } else if (cancelPackets.getValue() && cPacketUseEntity.getValue() && event.getPacket() instanceof CPacketUseEntity) {
                event.cancel();
            } else if (cancelPackets.getValue() && cPacketPlayerTryUseItem.getValue() && event.getPacket() instanceof CPacketPlayerTryUseItem) {
                event.cancel();
            } else if (cancelPackets.getValue() && cPacketPlayerTryUseItemOnBlock.getValue() && event.getPacket() instanceof CPacketPlayerTryUseItemOnBlock) {
                event.cancel();
            } else if (cancelPackets.getValue() && cPacketVehicleMove.getValue() && event.getPacket() instanceof CPacketVehicleMove) {
                event.cancel();
            }
        }
    });

    @EventHandler
    private final Listener<TravelEvent> travelEventListener = new Listener<>(event -> {
        if (nullCheck()) return;

        if (mode.is("Normal")) {
            mc.player.noClip = true;
        } else {
            fakePlayer.noClip = true;
        }
    });

    @SubscribeEvent
    public void onPlayerPushOutOfBlocks(PlayerSPPushOutOfBlocksEvent event) {
        if (nullCheck()) return;

        if (mode.is("Normal")) {
            mc.player.noClip = true;
        } else {
            fakePlayer.noClip = true;
        }
    }
}