package cf.radeon.module.modules.combat;

import cf.radeon.module.Category;
import cf.radeon.module.Module;
import cf.radeon.module.settings.BooleanSetting;
import cf.radeon.module.settings.NumberSetting;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.init.Items;
import net.minecraft.util.EnumHand;

public class AutoGapple extends Module {
    public static final BooleanSetting always = new BooleanSetting("Always", "always eat gapples", true);
    public static final NumberSetting health = new NumberSetting("Health",
            "The health to be used if it isnt `always`", 1.0, 16.0, 20.0, 1);

    public AutoGapple() {
        super("AutoGapple", "Eats gapples for you.", Category.COMBAT);
        this.addSettings(always, health);
    }

    public void onDisbale() {
        if (nullCheck())
            return;
        if (wasEating) {
            wasEating = false;
            KeyBinding.setKeyBindState(mc.gameSettings.keyBindUseItem.getKeyCode(), false);
        }
    }

    private boolean wasEating = false;

    public void onUpdate() {
        if(nullCheck()) return;



        if (always.getValue()) {
            if (mc.gameSettings.keyBindSprint.isKeyDown())
                mc.player.setSprinting(true);
            eatGap();
        } else {
            if (mc.player.getHealth() <= health.getFloatValue())
                eatGap();

            if (wasEating && mc.player.getHealth() >= health.getFloatValue()) {
                wasEating = false;
                KeyBinding.setKeyBindState(mc.gameSettings.keyBindUseItem.getKeyCode(), false);
            }
        }
    }

    public void eatGap() {
        if (mc.player.getHeldItemMainhand().getItem() == Items.GOLDEN_APPLE
                || mc.player.getHeldItemOffhand().getItem() == Items.GOLDEN_APPLE) {
            if (mc.currentScreen == null) {
                KeyBinding.setKeyBindState(mc.gameSettings.keyBindUseItem.getKeyCode(), true);
                wasEating = true;
            } else {
                mc.playerController.processRightClick(mc.player, mc.world, getHand());
            }
        }
    }

    public EnumHand getHand() {
        if(mc.player.getHeldItemOffhand().getItem() == Items.GOLDEN_APPLE) {
            return EnumHand.OFF_HAND;
        }

        return EnumHand.MAIN_HAND;
    }
}
