package cf.radeon.module;

public enum Category {

    COMBAT("Combat"),
    MOVEMENT("Movement"),
    RENDER("Render"),
    EXPLOIT("Exploit"),
    CLIENT("Client"),
    MISC("Misc"),
    HUD("HUD");

	public String name;
	
	Category(String string) {
		name = string;
	}

}
