package cf.radeon.module.modules.misc;

import cf.radeon.module.Category;
import cf.radeon.module.Module;
import cf.radeon.module.settings.NumberSetting;
import net.minecraft.client.entity.EntityOtherPlayerMP;

/**
 * @author olliem5
 */

public final class FakePlayer extends Module {
	public static final NumberSetting health = new NumberSetting("Health", "The health of the fake player",
			0.0f, 20.0f, 36.0f, 1);

	public FakePlayer() {
		super("FakePlayer", "Spawns a client side player entity, usually for module testing", Category.MISC);
		this.addSettings(health);
	}

	private EntityOtherPlayerMP fakePlayer = null;

	@Override
	public void onEnable() {
		if (nullCheck())
			return;

		fakePlayer = new EntityOtherPlayerMP(mc.world, mc.getSession().getProfile());

		if (fakePlayer != null) {
			fakePlayer.setHealth(health.getFloatValue());
			fakePlayer.copyLocationAndAnglesFrom(mc.player);
			fakePlayer.rotationYawHead = mc.player.rotationYawHead;
			mc.world.addEntityToWorld(fakePlayer.entityId, fakePlayer);
		}
	}

	@Override
	public void onDisable() {
		if (nullCheck())
			return;

		mc.world.removeEntityFromWorld(fakePlayer.entityId);

		fakePlayer = null;
	}

	@Override
	public String getHUDData() {
		return String.valueOf(health.getFloatValue());
	}

}
