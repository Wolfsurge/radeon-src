package cf.radeon.module.modules.combat;

import cf.radeon.managers.ModuleManager;
import cf.radeon.module.Category;
import cf.radeon.module.Module;
import cf.radeon.module.settings.BooleanSetting;
import cf.radeon.module.settings.NumberSetting;
import cf.radeon.utils.block.hole.Hole;
import cf.radeon.utils.block.hole.HoleUtil;
import net.minecraft.block.state.IBlockState;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3i;


/**
 *
 * @author Z3R0
 *
 * TODO: Fix autoanvil bugging out?
 * TODO: Switch slots to the correct item
 *
 */

public class HoleBot extends Module {
    public static final NumberSetting range = new NumberSetting("Search radius", "The search range.",
            9, 0, 32, 1);

    public static final BooleanSetting autoDisable = new BooleanSetting("Disable",
            "Auto disabled once its found a path.", true);

    public static final BooleanSetting modules = new BooleanSetting("Modules",
            "Use other modules to make it work better.", true);

    public static final BooleanSetting surround = new BooleanSetting("Surround",
            "Use surround if it cant find safe holes", true);

    public static final BooleanSetting autocrystal = new BooleanSetting("AutoCrystal",
            "Keep autocrystal on.", true);


    public static final BooleanSetting autogap = new BooleanSetting("AutoGapple",
            "Keep autogapple on.", true);


    public HoleBot() {
        super("HoleBot", "Experimental; goes to a safe hole for cpvp. also has some basic other stuff", Category.COMBAT);
        this.addSettings(range, modules, surround, autocrystal, autogap, autoDisable);
    }

    @Override
    public void onUpdate() {

        if (nullCheck())
            return;

        try {

            if (modules.getValue() && autocrystal.getValue()) {

                if (!ModuleManager.getModuleByName("AutoCrystal").isEnabled()) {
                    ModuleManager.getModuleByName("AutoCrystal").toggle();
                }

            }


            if(modules.getValue() && autogap.getValue()) {

                if (!ModuleManager.getModuleByName("AutoGapple").isEnabled()) {
                    ModuleManager.getModuleByName("AutoGapple").toggle();
                }
            }



            BlockPos bestHole = null;
            Hole.HoleTypes currentType;
            if(HoleUtil.isPlayerInHole(mc.player)) return;

            double dist = 100.0;
            double bRating = 0;
            final Vec3i playerPos = new Vec3i(mc.player.posX, mc.player.posY, mc.player.posZ);

            for (int x = playerPos.getX() - range.getIntValue(); x < playerPos.getX() + range.getIntValue(); x++) {
                for (int z = playerPos.getZ() - range.getIntValue(); z < playerPos.getZ() + range.getIntValue(); z++) {
                    for (int y = playerPos.getY() + range.getIntValue(); y > playerPos.getY() - range.getIntValue(); y--) {
                        BlockPos blockPos = new BlockPos(x, y, z);
                        double holeDist = mc.player.getDistanceSq(blockPos);

                        if (holeDist <= 1)
                            continue;

                        if (holeDist > dist)
                            continue;

                        IBlockState blockState = mc.world.getBlockState(blockPos);

                        Hole.HoleTypes type = Hole.isBlockValid(blockState, blockPos);

                        double rating = 0;


                        if(type == Hole.HoleTypes.Bedrock) {
                            rating += 10;
                        }

                        if(type == Hole.HoleTypes.Normal || type == Hole.HoleTypes.Obsidian) {
                            rating += 8;
                        }

                        rating += (1 / holeDist) * 10;

                        if(rating > bRating && type != Hole.HoleTypes.None && holeDist < 13) {
                            bRating = rating;
                            bestHole = blockPos;
                            dist = holeDist;
                            currentType = type;
                        }

                    }
                }
            }

            if (bestHole == null) {

                if (modules.getValue() && surround.getValue()) {
                    if (!ModuleManager.getModuleByName("Surround").isEnabled()) {
                        ModuleManager.getModuleByName("Surround").toggle();
                    }

                    toggle();
                } else {
                    // idk
                    //TODO
                }

                return;
            }

            baritoneToPos(bestHole
//					.add(0, -1, 0)
            );

            if (autoDisable.getValue()) {
                toggle();
            }

        } catch (Throwable e) {
            mc.shutdown();
            mc.shutdown();
            e.printStackTrace();
        }

//		BaritoneAPI.getProvider().getPrimaryBaritone().getCustomGoalProcess().setGoal();

    }

    public void baritoneToPos(BlockPos pos) {

//		BaritoneAPI.getProvider().getPrimaryBaritone().getCustomGoalProcess().setGoalAndPath(new GoalBlock(pos));

        mc.player.sendChatMessage("#goto " + pos.getX() + " " + pos.getY() + " " + pos.getZ());
        // yes its not perfect but going thru the java api just didnt work ok
    }

//	public static void baritoneToPos(int x, int z) {
//
//		mc.player.sendChatMessage("#goto " + x + " " + z);
//	}

}
