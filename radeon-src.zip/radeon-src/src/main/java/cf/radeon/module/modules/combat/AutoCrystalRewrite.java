package cf.radeon.module.modules.combat;

import java.awt.Color;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.UUID;
import java.util.stream.Collectors;

import cf.radeon.module.Category;
import cf.radeon.module.Module;
import cf.radeon.module.settings.BooleanSetting;
import cf.radeon.module.settings.ColourPicker;
import cf.radeon.module.settings.ModeSetting;
import cf.radeon.module.settings.NumberSetting;
import cf.radeon.utils.block.BlockUtil;
import cf.radeon.utils.combat.CooldownUtil;
import cf.radeon.utils.combat.crystal.CrystalUtil;
import cf.radeon.utils.render.Colour;
import cf.radeon.utils.render.RenderUtil3D;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityEnderCrystal;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.init.MobEffects;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;
import net.minecraft.item.ItemTool;
import net.minecraft.network.login.client.CPacketEncryptionResponse;
import net.minecraft.network.play.client.CPacketConfirmTeleport;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.network.play.client.CPacketSpectate;
import net.minecraft.network.play.client.CPacketTabComplete;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;

public class AutoCrystalRewrite extends Module {


    BooleanSetting top_place = new BooleanSetting("Place", "Place crystals", true);
    NumberSetting place_range = new NumberSetting("Place range", "The range that it will place crystals", 1.0, 3.5, 6.0, 0.5);
    NumberSetting place_max_self_damage = new NumberSetting("Place Max Self Damage", "The maximum damage that it can do to you if it will be placed.", 0.0, 6.0, 20.0, 1);
    NumberSetting place_min_enemy_damage = new NumberSetting("Place Min Enemy Damage", "The minimum damage a crystal needs to do to an enemy to be placed.", 0.0, 8.0, 20.0, 1);
    BooleanSetting faceplace = new BooleanSetting("Faceplace", "Place crystals if they are in a hole.", true);
    BooleanSetting multiplace = new BooleanSetting("Multiplace", "Place multi", false);
    BooleanSetting antiSelfKill = new BooleanSetting("Antiselfkill", "dont kill urself", true);
    BooleanSetting smartPlace = new BooleanSetting("SmartPlace", "Make sure that every crystal you place does more damage to the target than to yourself.", true);
    NumberSetting place_delay = new NumberSetting("Place delay", "MS delay in between placing crystals", 0, 5, 1000, 1);
    ModeSetting multiplaceType = new ModeSetting("Multiplace Type", "The type of multiplace", "After", "Before", "During", "More", "Advanced");

    BooleanSetting top_break = new BooleanSetting("Break", "Break crystals", true);
    NumberSetting break_range = new NumberSetting("Break range", "The range that it will Break crystals", 1.0, 3.5, 6.0, 0.5);
    NumberSetting break_tries = new NumberSetting("Break attempts", "the amount of times it will try and break the crystal.", 1, 1, 5, 1);
    NumberSetting break_max_self_damage = new NumberSetting("Break Max Self Damage", "The maximum damage that it can do to you if it will be broken.", 0.0, 6.0, 20.0, 1);
    NumberSetting break_min_enemy_damage = new NumberSetting("Break Min Enemy Damage", "The minimum damage a crystal needs to do to an enemy to be broken.", 0.0, 8.0, 20.0, 1);
    NumberSetting break_delay = new NumberSetting("Break delay", "MS delay in between breaking crystals", 0, 500, 1000, 1);
    ModeSetting offType = new ModeSetting("Offtype", "", "Death", "HPZero");

    BooleanSetting top_target = new BooleanSetting("Target", "Target settings", true);
    NumberSetting target_range = new NumberSetting("Target range", "The range that it will search for player targets", 5.0, 9.0, 20.0, 1);
    BooleanSetting smart_death_check = new BooleanSetting("Smart death check", "A smarter way of checking if the player is dead before making them the new target.", true);

    BooleanSetting top_misc = new BooleanSetting("Misc", "other settings", true);
    BooleanSetting antiWeakness = new BooleanSetting("Anti weakness", "anti weakness bc ppl are weird and use it still", true);
    BooleanSetting debug = new BooleanSetting("Debug", "Show debug stuff", false);
    BooleanSetting betterOffhand = new BooleanSetting("BetterOffhand", "Improved offhand performance.", true);
    BooleanSetting multiThread = new BooleanSetting("MultiThread", "Remove lag spikes while crystalaura is enabled.", false);
    BooleanSetting packetSpoofer = new BooleanSetting("PacketSpoofer", "Confuse the servers anticheat", false);
    BooleanSetting badACDisabler = new BooleanSetting("BadAC Disabler", "Disable bad anticheats interaction checks.", false);

    BooleanSetting top_render = new BooleanSetting("Rendering", "rendering", true);
    ColourPicker render_break_color = new ColourPicker("Break ESP Color", "ESP for breaking", new Colour(Color.RED));
    ColourPicker render_place_color = new ColourPicker("Place ESP Color", "ESP for placing", new Colour(Color.GREEN));

    public AutoCrystalRewrite() {
        super("ACRewrite", "Rewrite of the ac, a lot better", Category.COMBAT);
        this.addSettings( // Place
                top_place,
                place_range,
                place_max_self_damage,
                place_min_enemy_damage,
                faceplace,
                multiplace,
                antiSelfKill,
                smartPlace,
                place_delay
        );
        this.addSettings( // Break
                top_break,
                break_range,
                break_tries,
                break_delay
        );
        this.addSettings( // Target
                top_target,
                target_range,
                smart_death_check
        );
        this.addSettings( // Misc
                top_misc,
                antiWeakness,
                packetSpoofer,
                badACDisabler
        );

        this.addSettings( // Render
                top_render,
                render_break_color,
                render_place_color
        );
    }

    @Override
    public String getHUDData() {
        if(target != null) {
            return target.getName();
        }

        return super.getHUDData();
    }

    public void info(String info) {
        if(debug.getValue()) {
            // debug(info);
        }
    }

    private boolean isHoldingCrystal() {
        return mc.player.getHeldItemMainhand().getItem() != null && (mc.player.getHeldItemMainhand().getItem() == Items.END_CRYSTAL || mc.player.getHeldItemOffhand().getItem() == Items.END_CRYSTAL);
    }

    public EntityPlayer target;

    boolean offhand = false;

    CooldownUtil targetupdate_timer = new CooldownUtil();
    CooldownUtil place_timer = new CooldownUtil();
    CooldownUtil break_timer = new CooldownUtil();

    BlockPos place_block;
    BlockPos break_block;

    @Override
    public void onUpdate() {
        if(nullCheck()) return;

        offhand = mc.player.getHeldItemOffhand().getItem() == Items.END_CRYSTAL;

        if(targetupdate_timer.passed(300)) {

            if(top_target.getValue()) {
                updateTarget();
            } else {
                target = mc.player;
            }

            targetupdate_timer.reset();
        }

        if(target == null || !isHoldingCrystal()) {
            break_block = null;
            place_block = null;
            return;
        }

        if(packetSpoofer.getValue()) {
            try {
                mc.networkManager.sendPacket(new CPacketConfirmTeleport(5));
                mc.networkManager.sendPacket(new CPacketSpectate(UUID.randomUUID()));
                mc.networkManager.sendPacket(new CPacketEncryptionResponse());
                mc.networkManager.sendPacket(new CPacketTabComplete("/fsgkjdhfjishdgf", null, false));
            } catch(Exception e) {
                try {
                    mc.getConnection().sendPacket(new CPacketConfirmTeleport(5));
                    mc.getConnection().sendPacket(new CPacketSpectate(UUID.randomUUID()));
                    mc.getConnection().sendPacket(new CPacketEncryptionResponse());
                    mc.getConnection().sendPacket(new CPacketTabComplete("/fsgkjdhfjishdgf", null, false));
                } catch (Exception ex1) {}
            }
        }

        if(badACDisabler.getValue()) {
            for(int i = 0; i < 50; i++) {
                mc.getConnection().sendPacket(new CPacketPlayer.Position(0, 0, 0, true));
            }
        }

        if(top_place.getValue()) {
            if(!(!faceplace.getValue() && CrystalUtil.IsPlayerInHole(target))) {
                if(place_timer.passed(place_delay.getIntValue())) {
                    placeCrystals();
                    place_timer.reset();
                }

            }
        }

        if(top_break.getValue()) {
            //break_delay

            if(break_timer.passed(break_delay.getIntValue())) {
                breakCrystals();
                break_timer.reset();
            }

        }


    }

    private void breakCrystals() {


        if (antiWeakness.getValue() && mc.player.isPotionActive(MobEffects.WEAKNESS)) {
            boolean should_weakness = true;

            if (mc.player.isPotionActive(MobEffects.STRENGTH)) {

                if (Objects.requireNonNull(mc.player.getActivePotionEffect(MobEffects.STRENGTH)).getAmplifier() == 2) {
                    should_weakness = false;
                }

            }

            if (should_weakness) {

//                if (!already_attacking) {
//                    already_attacking = true;
//                }

                int new_slot = -1;

                for (int i = 0; i < 9; i++) {

                    ItemStack stack = mc.player.inventory.getStackInSlot(i);

                    if (stack.getItem() instanceof ItemSword || stack.getItem() instanceof ItemTool) {
                        new_slot = i;
                        mc.playerController.updateController();
                        break;
                    }

                }

                if (new_slot != -1) {
                    mc.player.inventory.currentItem = new_slot;
                }

            }
        }


        double bestScore = 0;
        EntityEnderCrystal bestTarget = null;

        for(Entity e: mc.world.loadedEntityList) {
            if(!(e instanceof EntityEnderCrystal)) continue;
            if(e.isDead) continue;
            if(e.getDistance(mc.player) > break_range.getFloatValue()) continue;

            double posX = e.posX;
            double posY = e.posY;
            double posZ = e.posZ;

            double targetDMG = CrystalUtil.calculateDamage(posX, posY, posZ, target);
            double selfDMG = CrystalUtil.calculateDamage(posX, posY, posZ, mc.player);

            if(selfDMG > targetDMG) continue;


            double score = targetDMG - selfDMG;

            if(score > bestScore) {
                bestScore = score;
                bestTarget = (EntityEnderCrystal) e;
            }

        }

        if(bestTarget == null) {
            break_block = null;
            return;
        }

        break_block = new BlockPos(bestTarget);

        for(int i = 0; i < break_tries.getIntValue(); i++) {
            CrystalUtil.breakCrystal(bestTarget, true);


            if(offhand) {
                mc.player.swingArm(EnumHand.OFF_HAND);
            } else {
                mc.player.swingArm(EnumHand.MAIN_HAND);
            }

        }

    }

    private void placeCrystals() {
        List<BlockPos> positions = crystalBlocks(mc.player, place_range.getFloatValue(), false, multiplace.getValue(), false);

        positions = positions.parallelStream().filter(pos -> isGoodPlaceCrystalSpot(pos)).collect(Collectors.toList());
        positions.sort(crystalPosDamageComp2);
        positions.sort(crystalPosDamageComp);
        Collections.reverse(positions);

        if(positions.isEmpty() || positions.size() == 0) {
            place_block = null;
            return;
        }

        BlockPos bestPos = positions.get(0);
        if(CrystalUtil.canPlaceCrystal(bestPos, multiplace.getValue(), false)) {
            place_block = bestPos;
            CrystalUtil.placeCrystal(bestPos, CrystalUtil.getEnumFacing(false, bestPos), true);
        } else {
            place_block = null;
        }

    }

    Comparator<BlockPos> crystalPosDamageComp = new Comparator<BlockPos>() {
        @Override
        public int compare(BlockPos o1, BlockPos o2) {
            int o1dmg = (int) CrystalUtil.calculateDamage(o1.getX(), o1.getY() + 1, o1.getZ(), target);
            int o2dmg = (int) CrystalUtil.calculateDamage(o2.getX(), o2.getY() + 1, o2.getZ(), target);
            return o1dmg - o2dmg;
        }
    };


    Comparator<BlockPos> crystalPosDamageComp2 = new Comparator<BlockPos>() {
        @Override
        public int compare(BlockPos o1, BlockPos o2) {
            int o1dmg = (int) CrystalUtil.calculateDamage(o1.getX(), o1.getY() + 1, o1.getZ(), mc.player);
            int o2dmg = (int) CrystalUtil.calculateDamage(o2.getX(), o2.getY() + 1, o2.getZ(), mc.player);
            return o2dmg - o1dmg;
        }
    };

//	class Sortbyroll implements Comparator<Student> {
//	    // Used for sorting in ascending order of
//	    // roll number
//	    public int compare(Student a, Student b)
//	    {
//	        return a.rollno - b.rollno;
//	    }
//	}


    @Override
    public void onRenderWorld() {
        if (nullCheck()) return;



        if(break_block != null) {
            RenderUtil3D.draw(break_block, true, false, 0, 0, render_break_color.getColor());
        }

        if(place_block != null) {
            RenderUtil3D.draw(place_block, true, false, 0, 0, render_place_color.getColor());
        }
    }

    public boolean isGoodPlaceCrystalSpot(BlockPos pos) {
        double damageToEnemy = CrystalUtil.calculateDamage(pos.getX(), pos.getY() + 1, pos.getZ(), target);
        double damageToSelf = CrystalUtil.calculateDamage(pos.getX(), pos.getY() + 1, pos.getZ(), target);

        if(antiSelfKill.getValue()) {
            if(mc.player.getHealth() - damageToSelf <= 1.0) {
                return false;
            }
        }

        if(smartPlace.getValue()) {
            if(damageToSelf > damageToEnemy) {
                return false;
            }
        }

        if(damageToEnemy < place_min_enemy_damage.getFloatValue()) {
            return false;
        }

        if(damageToSelf > place_max_self_damage.getFloatValue()) {
            return false;
        }



        return true;
    }


    private void updateTarget() {
        List<EntityPlayer> targets = mc.world.playerEntities;
        targets = targets.stream().filter(e -> isValidTarget(e)).collect(Collectors.toList());


        if(targets == null || targets.isEmpty()) {
            target = null;
            return;
        }

        double bestDistance = 100;
        EntityPlayer bestTarget = null;

        for(EntityPlayer e: targets) {
            if(e.getDistance(mc.player) < bestDistance) {
                bestDistance = e.getDistance(mc.player);
                bestTarget = e;
            }
        }
        if(bestTarget != null) {
            target = bestTarget;
        }

    }



    private boolean isValidTarget(EntityPlayer e) {

        if(e == mc.player) return false;

        if(smart_death_check.getValue()) {
            if(e.isDead || e.getHealth() <= 0.0) {
                return false;
            }
        } else {
            if(e.isDead) {
                return false;
            }
        }

        if(e.getDistance(mc.player) > target_range.getFloatValue()) {
            return false;
        }

        return true;
    }






    //utils and stuff


    public static List<BlockPos> crystalBlocks(EntityPlayer entityPlayer, double placeRange, boolean prediction,
                                               boolean multiPlace, boolean thirteen) {
        return BlockUtil.getNearbyBlocks(entityPlayer, placeRange, prediction).stream()
                .filter(blockPos -> CrystalUtil.canPlaceCrystal(blockPos, multiPlace, thirteen))
                .collect(Collectors.toList());
    }
}
