package cf.radeon.module.modules.render;

import cf.radeon.managers.FriendManager;
import cf.radeon.module.Category;
import cf.radeon.module.Module;
import cf.radeon.module.modules.client.Social;
import cf.radeon.module.modules.render.esp.ESPMode;
import cf.radeon.module.modules.render.esp.modes.Box;
import cf.radeon.module.modules.render.esp.modes.CSGO;
import cf.radeon.module.modules.render.esp.modes.Glow;
import cf.radeon.module.settings.BooleanSetting;
import cf.radeon.module.settings.ColourPicker;
import cf.radeon.module.settings.ModeSetting;
import cf.radeon.module.settings.NumberSetting;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityEnderCrystal;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.entity.passive.EntityAnimal;
import net.minecraft.entity.player.EntityPlayer;

import java.awt.*;
import java.util.Objects;

/**
 * @author olliem5
 */

public final class ESP extends Module {
    public static final ModeSetting mode = new ModeSetting("Mode", "The mode to use for ESP", "CSGO", "Box", "Glow", "Hitbox");
    public static final NumberSetting lineWidth = new NumberSetting("Line Width", "The width of the lines", 1.0, 2.0, 5.0, 0.1);

    public static final BooleanSetting crystals = new BooleanSetting("Crystals", "Allows ESP to function on crystals", true);
    public static final ColourPicker crystalColour = new ColourPicker("Crystal Colour", "The colour for crystals", new Color(106, 22, 219, 100));

    public static final BooleanSetting players = new BooleanSetting("Players", "Allows ESP to function on players", true);
    public static final ColourPicker playerColour = new ColourPicker("Player Colour", "The colour for players", new Color(106, 22, 219, 100));

    public static final BooleanSetting animals = new BooleanSetting("Animals", "Allows ESP to function on animals", true);
    public static final ColourPicker animalColour = new ColourPicker("Animal Colour", "The colour for animals", new Color(75, 219, 22, 100));

    public static final BooleanSetting mobs = new BooleanSetting("Mobs", "Allows ESP to function on animals", true);
    public static final ColourPicker mobColour = new ColourPicker("Mob Colour", "The colour for animals", new Color(236, 13, 29, 100));

    public ESP() {
        super("ESP", "Highlights entities in your world", Category.RENDER);
        this.addSettings(
                mode,
                lineWidth,
                crystals,
                crystalColour,
                players,
                playerColour,
                animals,
                animalColour,
                mobs,
                mobColour
        );
    }

    private ESPMode espMode;

    public void onUpdate() {
        if (nullCheck()) return;

        switch (mode.getMode()) {
            case "CSGO":
                espMode = new CSGO();
                break;
            case "Box":
                espMode = new Box();
                break;
            case "Glow":
                espMode = new Glow();
                break;
        }

        if (!espMode.equals(new Glow())) {
            mc.world.loadedEntityList.stream()
                    .filter(Objects::nonNull)
                    .filter(entity -> mc.player != entity)
                    .filter(ESP::entityCheck)
                    .forEach(entity -> entity.setGlowing(false));
        }
    }

    public static boolean entityCheck(Entity entity) {
        return entity instanceof EntityEnderCrystal && crystals.getValue() || entity instanceof EntityPlayer && players.getValue() || entity instanceof EntityAnimal && animals.getValue() || entity instanceof EntityMob && mobs.getValue();
    }

    public static Color getESPColour(Entity entity) {
        if (entity instanceof EntityEnderCrystal) {
            return new Color(crystalColour.getValue().getRed(), crystalColour.getValue().getGreen(), crystalColour.getValue().getBlue(), crystalColour.getValue().getAlpha());
        }

        if (entity instanceof EntityPlayer) {
            if (FriendManager.isFriend(entity.getName())) {
                return new Color(Social.friendColour.getValue().getRed(), Social.friendColour.getValue().getGreen(), Social.friendColour.getValue().getBlue(), Social.friendColour.getValue().getAlpha());
            } else if (!FriendManager.isEnemy(entity.getName())) {
                return new Color(Social.enemyColour.getValue().getRed(), Social.enemyColour.getValue().getGreen(), Social.enemyColour.getValue().getBlue(), Social.enemyColour.getValue().getAlpha());
            } else {
                return new Color(playerColour.getValue().getRed(), playerColour.getValue().getGreen(), playerColour.getValue().getBlue(), playerColour.getValue().getAlpha());
            }
        }

        if (entity instanceof EntityAnimal) {
            return new Color(animalColour.getValue().getRed(), animalColour.getValue().getGreen(), animalColour.getValue().getBlue(), animalColour.getValue().getAlpha());
        }

        if (entity instanceof EntityMob) {
            return new Color(mobColour.getValue().getRed(), mobColour.getValue().getGreen(), mobColour.getValue().getBlue(), mobColour.getValue().getAlpha());
        }

        return new Color(255, 255, 255, 255);
    }

    @Override
    public void onRenderWorld() {
        if (nullCheck()) return;

        try {
            espMode.drawESP();
        } catch(NullPointerException ignored) {}
    }
}
