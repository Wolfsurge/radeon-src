package cf.radeon.module.modules.render;

import cf.radeon.event.impl.TransformFirstPersonEvent;
import cf.radeon.module.Category;
import cf.radeon.module.Module;
import cf.radeon.module.settings.BooleanSetting;
import cf.radeon.module.settings.NumberSetting;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.util.EnumHandSide;

/**
 * @author olliem5
 */

public final class ViewModel extends Module {
    public static final BooleanSetting cancelEating = new BooleanSetting("Cancel Eating", "Cancels the eating animation", true);

    public static final BooleanSetting leftPosition = new BooleanSetting("Left Position", "Changes how the left hand is rendered", true);
    public static final NumberSetting leftX = new NumberSetting("Left X", "Changes the X position of the left hand", -2.0, 0.0, 2.0, 0.01);
    public static final NumberSetting leftY = new NumberSetting("Left Y", "Changes the Y position of the left hand", -2.0, 0.2, 2.0, 0.01);
    public static final NumberSetting leftZ = new NumberSetting("Left Z", "Changes the Z position of the left hand", -2.0, -1.2, 2.0, 0.01);

    public static final BooleanSetting rightPosition = new BooleanSetting("Right Position", "Changes how the right hand is rendered", true);
    public static final NumberSetting rightX = new NumberSetting("Right X", "Changes the X position of the right hand", -2.0, 0.0, 2.0, 0.01);
    public static final NumberSetting rightY = new NumberSetting("Right Y", "Changes the Y position of the right hand", -2.0, 0.2, 2.0, 0.01);
    public static final NumberSetting rightZ = new NumberSetting("Right Z", "Changes the Z position of the right hand", -2.0, -1.2, 2.0, 0.01);

    public static final BooleanSetting leftRotation = new BooleanSetting("Left Rotation", "Changes the left hands model rotation", true);
    public static final NumberSetting leftYaw = new NumberSetting("L Yaw", "Changes yaw of your left hand", -100, 0, 100, 1);
    public static final NumberSetting leftPitch = new NumberSetting("L Pitch", "Changes pitch of your left hand", -100, 0, 100, 1);
    public static final NumberSetting leftRoll = new NumberSetting("L Roll", "Changes roll of your left hand", -100, 0, 100, 1);

    public static final BooleanSetting rightRotation = new BooleanSetting("Right Rotation", "Changes the right hands model rotation", true);
    public static final NumberSetting rightYaw = new NumberSetting("R Yaw", "Changes yaw of your Right hand", -100, 0, 100, 1);
    public static final NumberSetting rightPitch = new NumberSetting("R Pitch", "Changes pitch of your Right hand", -100, 0, 100, 1);
    public static final NumberSetting rightRoll = new NumberSetting("R Roll", "Changes roll of your Right hand", -100, 0, 100, 1);

    public ViewModel() {
        super("ViewModel", "Changes the way you look in first person", Category.RENDER);
        this.addSetting(cancelEating);
        this.addSettings(leftPosition, leftX, leftY, leftZ);
        this.addSettings(rightPosition, rightX, rightY, rightZ);
        this.addSettings(leftRotation, leftYaw, leftPitch, leftRoll);
        this.addSettings(rightRotation, rightYaw, rightPitch, rightRoll);
    }

    @EventHandler
    private final Listener<TransformFirstPersonEvent.Pre> transformFirstPersonEventPreListener = new Listener<>(event -> {
        if (nullCheck()) return;

        if (leftPosition.getValue() && event.getEnumHandSide() == EnumHandSide.LEFT) {
            GlStateManager.translate(leftX.getDoubleValue(), leftY.getDoubleValue(), leftZ.getDoubleValue());
        }

        if (rightPosition.getValue() && event.getEnumHandSide() == EnumHandSide.RIGHT) {
            GlStateManager.translate(rightX.getDoubleValue(), rightY.getDoubleValue(), rightZ.getDoubleValue());
        }
    });

    @EventHandler
    private final Listener<TransformFirstPersonEvent.Post> transformFirstPersonEventPostListener = new Listener<>(event -> {
        if (nullCheck()) return;

        if (leftRotation.getValue() && event.getEnumHandSide() == EnumHandSide.LEFT) {
            GlStateManager.rotate(leftYaw.getFloatValue(),0,1,0);
            GlStateManager.rotate(leftPitch.getFloatValue(),1,0,0);
            GlStateManager.rotate(leftRoll.getFloatValue(),0,0,1);
        }

        if (rightRotation.getValue() && event.getEnumHandSide() == EnumHandSide.RIGHT) {
            GlStateManager.rotate(rightYaw.getFloatValue(),0,1,0);
            GlStateManager.rotate(rightPitch.getFloatValue(),1,0,0);
            GlStateManager.rotate(rightRoll.getFloatValue(),0,0,1);
        }
    });
}
