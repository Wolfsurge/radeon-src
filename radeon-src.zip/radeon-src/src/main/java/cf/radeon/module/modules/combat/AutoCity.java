package cf.radeon.module.modules.combat;

import java.util.ArrayList;
import java.util.stream.Collectors;

import cf.radeon.managers.FriendManager;
import cf.radeon.module.Category;
import cf.radeon.module.Module;
import cf.radeon.utils.other.ChatUtil;
import cf.radeon.utils.other.Pair;
import net.minecraft.block.Block;
import net.minecraft.block.BlockLiquid;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketPlayerDigging;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;

public class AutoCity extends Module {

    BlockPos current;
    boolean started = false;

    public AutoCity() {
        super("AutoCity", "Cities the nearest player to you.", Category.COMBAT);
    }

    private static final BlockPos[] surroundOffset =
            {
                    new BlockPos(0, 0, -1), // north
                    new BlockPos(1, 0, 0), // east
                    new BlockPos(0, 0, 1), // south
                    new BlockPos(-1, 0, 0) // west
            };

    @Override
    public void onEnable() {

        if(nullCheck()) return;

        super.onEnable();

        final ArrayList<Pair<EntityPlayer, ArrayList<BlockPos>>> cityPlayers = GetPlayersReadyToBeCitied();

        if (cityPlayers.isEmpty()) {
            ChatUtil.addChatMessage("There is nobody to city...");
            toggle();
            return;
        }

        EntityPlayer target = null;
        BlockPos targetBlock = null;
        double currDistance = 100;

        for (Pair<EntityPlayer, ArrayList<BlockPos>> pair : cityPlayers) {
            for (BlockPos pos : pair.getSecond()) {
                if (targetBlock == null) {
                    target = pair.getFirst();
                    targetBlock = pos;
                    continue;
                }

                double dist = pos.getDistance(targetBlock.getX(), targetBlock.getY(), targetBlock.getZ());

                if (dist < currDistance) {
                    currDistance = dist;
                    targetBlock = pos;
                    target = pair.getFirst();
                }
            }
        }

        if (targetBlock == null) {
            ChatUtil.addChatMessage("No blocks to mine!");
            toggle();
            return;
        }

        current = targetBlock;
        started = false;
    }

    @Override
    public void onUpdate() {

        if(nullCheck()) return;

        boolean hasPickaxe = mc.player.getHeldItemMainhand().getItem() == Items.DIAMOND_PICKAXE;

        if (!hasPickaxe) {
            for (int i = 0; i < 9; ++i) {
                ItemStack stack = mc.player.inventory.getStackInSlot(i);

                if (stack.isEmpty())
                    continue;

                if (stack.getItem() == Items.DIAMOND_PICKAXE) {
                    hasPickaxe = true;
                    mc.player.inventory.currentItem = i;
                    mc.playerController.updateController();
                    break;
                }
            }
        }

        if (!hasPickaxe) {
            ChatUtil.addChatMessage("You need a pickaxe you moron");
            toggle();
            return;
        }

        BlockPos currBlock = current;

        if (currBlock == null) {
            ChatUtil.addChatMessage("Done!");
            toggle();
            return;
        }

        Update(3, false);
    }

    private boolean IsDoneBreaking(IBlockState blockState) {
        return blockState.getBlock() == Blocks.BEDROCK || blockState.getBlock() == Blocks.AIR
                || blockState.getBlock() instanceof BlockLiquid;
    }

    public boolean Update(float range, boolean rayTrace) {
        if (current == null)
            return false;

        IBlockState state = mc.world.getBlockState(current);

        if (IsDoneBreaking(state) || mc.player.getDistanceSq(current) > Math.pow(range, range)) {
            current = null;
            return false;
        }

        // CPacketAnimation
        mc.player.swingArm(EnumHand.MAIN_HAND);

        EnumFacing facing = EnumFacing.UP;

        if (rayTrace) {
            RayTraceResult result = mc.world.rayTraceBlocks(
                    new Vec3d(mc.player.posX, mc.player.posY + mc.player.getEyeHeight(), mc.player.posZ),
                    new Vec3d(current.getX() + 0.5, current.getY() - 0.5, current.getZ() + 0.5));

            if (result != null && result.sideHit != null)
                facing = result.sideHit;
        }

        if (!started) {
            started = true;
            // Start Break

            mc.player.connection
                    .sendPacket((Packet<?>) new CPacketPlayerDigging(CPacketPlayerDigging.Action.START_DESTROY_BLOCK,
                            current, facing));
        } else {
            mc.playerController.onPlayerDamageBlock(current, facing);
        }

        return true;
    }

    public ArrayList<Pair<EntityPlayer, ArrayList<BlockPos>>> GetPlayersReadyToBeCitied() {
        ArrayList<Pair<EntityPlayer, ArrayList<BlockPos>>> players = new ArrayList<Pair<EntityPlayer, ArrayList<BlockPos>>>();

        for (Entity entity : mc.world.playerEntities.stream()
                .filter(entityPlayer -> !FriendManager.isFriend(entityPlayer.getDisplayNameString())).collect(Collectors.toList())) {
            ArrayList<BlockPos> positions = new ArrayList<BlockPos>();

            for (int i = 0; i < 4; ++i) {
                BlockPos o = GetPositionVectorBlockPos(entity, surroundOffset[i]);

                // ignore if the surrounding block is not obsidian
                if (mc.world.getBlockState(o).getBlock() != Blocks.OBSIDIAN)
                    continue;

                boolean passCheck = false;

                switch (i) {
                    case 0:
                        passCheck = canPlaceCrystal(o.north(1).down());
                        break;
                    case 1:
                        passCheck = canPlaceCrystal(o.east(1).down());
                        break;
                    case 2:
                        passCheck = canPlaceCrystal(o.south(1).down());
                        break;
                    case 3:
                        passCheck = canPlaceCrystal(o.west(1).down());
                        break;
                }

                if (passCheck)
                    positions.add(o);
            }

            if (!positions.isEmpty())
                players.add(new Pair<EntityPlayer, ArrayList<BlockPos>>((EntityPlayer) entity, positions));
        }

        return players;
    }

    public BlockPos GetPositionVectorBlockPos(Entity entity, BlockPos toAdd) {
        final Vec3d v = entity.getPositionVector();

        if (toAdd == null)
            return new BlockPos(v.x, v.y, v.z);

        return new BlockPos(v.x, v.y, v.z).add(toAdd);
    }

    public boolean canPlaceCrystal(final BlockPos pos) {

        final Block block = mc.world.getBlockState(pos).getBlock();

        if (block == Blocks.OBSIDIAN || block == Blocks.BEDROCK) {
            final Block floor = mc.world.getBlockState(pos.add(0, 1, 0)).getBlock();
            final Block ceil = mc.world.getBlockState(pos.add(0, 2, 0)).getBlock();

            if (floor == Blocks.AIR && ceil == Blocks.AIR) {
                if (mc.world.getEntitiesWithinAABBExcludingEntity(null, new AxisAlignedBB(pos.add(0, 1, 0)))
                        .isEmpty()) {
                    return true;
                }
            }
        }

        return false;
    }

}
