package cf.radeon.module.modules.combat;

import java.util.ArrayList;
import java.util.List;

import cf.radeon.event.impl.PacketEvent;
import cf.radeon.module.Category;
import cf.radeon.module.Module;
import cf.radeon.module.settings.BooleanSetting;
import cf.radeon.module.settings.NumberSetting;
import cf.radeon.utils.block.BlockUtil;
import cf.radeon.utils.combat.crystal.PlaceUtil;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.minecraft.block.Block;
import net.minecraft.block.BlockAnvil;
import net.minecraft.block.BlockObsidian;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public class AnvilAura extends Module {

    public NumberSetting range = new NumberSetting("Range", "range", 0.0, 6.0,
            10.0, 0.5);
    public NumberSetting wallsRange = new NumberSetting("WallsRange", "", 0.0,
            3.5, 10.0, 1);
    public NumberSetting placeDelay = new NumberSetting("PlaceDelay", "", 0, 0, 500, 1);
    public BooleanSetting rotate = new BooleanSetting("Rotate", "", true);
    public BooleanSetting packet = new BooleanSetting("Packet", "", true);
    public BooleanSetting switcher = new BooleanSetting("Switch", "", true);
    public NumberSetting rotations = new NumberSetting("Spoofs", "", 1, 1, 20, 1);

    private float yaw = 0.0f;
    private float pitch = 0.0f;
    private boolean rotating = false;
    private int rotationPacketsSpoofed = 0;
    private EntityPlayer finalTarget;
    private BlockPos placeTarget;

    public AnvilAura() {
        super("AnvilAura", "piece of trash", Category.COMBAT);
        this.addSettings(range, rotate, packet, switcher, rotations);
    }

    @Override
    public void onUpdate() {
        if (nullCheck())
            return;
        doAnvilAura();
    }

    @EventHandler
    private final Listener<PacketEvent.Send> sendListener = new Listener<>(event -> {
        if (nullCheck())
            return;
        if (this.rotate.isEnabled() && this.rotating) {
            if (event.getPacket() instanceof CPacketPlayer) {
                CPacketPlayer packet = (CPacketPlayer) event.getPacket();
                packet.yaw = this.yaw;
                packet.pitch = this.pitch;
            }
            ++this.rotationPacketsSpoofed;
            if (this.rotationPacketsSpoofed >= this.rotations.getIntValue()) {
                this.rotating = false;
                this.rotationPacketsSpoofed = 0;
            }
        }
    });

    public void doAnvilAura() {
        this.finalTarget = this.getTarget();
        if (this.finalTarget != null) {
            this.placeTarget = this.getTargetPos(this.finalTarget);
        }
        if (this.placeTarget != null && this.finalTarget != null) {
            this.placeAnvil(this.placeTarget);
        }
    }

    public void placeAnvil(BlockPos pos) {
        if (this.rotate.getValue()) {
            this.rotateToPos(pos);
        }
        if (this.switcher.getValue() && !this.isHoldingAnvil()) {
            this.doSwitch();
        }
        PlaceUtil.placeBlock(pos, false, this.packet.getValue());
    }

    public boolean isHoldingAnvil() {
        return mc.player.getHeldItemMainhand().getItem() instanceof ItemBlock
                && ((ItemBlock) mc.player.getHeldItemMainhand().getItem()).getBlock() instanceof BlockAnvil
                || mc.player.getHeldItemOffhand().getItem() instanceof ItemBlock
                && ((ItemBlock) mc.player.getHeldItemOffhand().getItem())
                .getBlock() instanceof BlockAnvil;
    }

    public void doSwitch() {
        int obbySlot = findHotbarBlock(BlockObsidian.class);
        if (obbySlot == -1) {
            for (int l = 0; l < 9; ++l) {
                ItemStack stack = mc.player.inventory.getStackInSlot(l);
                Block block = ((ItemBlock) stack.getItem()).getBlock();
                if (!(block instanceof BlockObsidian))
                    continue;
                obbySlot = l;
            }
        }
        if (obbySlot != -1) {
            mc.player.inventory.currentItem = obbySlot;
        }
    }

    public int findHotbarBlock(final Class<BlockObsidian> clazz) {
        for (int i = 0; i < 9; ++i) {
            final ItemStack stack = mc.player.inventory.getStackInSlot(i);
            if (stack != ItemStack.EMPTY) {
                if (clazz.isInstance(stack.getItem())) {
                    return i;
                }
                if (stack.getItem() instanceof ItemBlock) {
                    final Block block = ((ItemBlock) stack.getItem()).getBlock();
                    if (clazz.isInstance(block)) {
                        return i;
                    }
                }
            }
        }
        return -1;
    }

    public EntityPlayer getTarget() {
        double shortestDistance = -1.0;
        EntityPlayer target = null;
        for (EntityPlayer player : mc.world.playerEntities) {
            if (this.getPlaceableBlocksAboveEntity(player).isEmpty() || shortestDistance != -1.0
                    && !(mc.player.getDistanceSq(player) < square(shortestDistance)))
                continue;
            shortestDistance = mc.player.getDistance(player);
            target = player;
        }
        return target;
    }

    public BlockPos getTargetPos(Entity target) {
        double distance = -1.0;
        BlockPos finalPos = null;
        for (BlockPos pos : this.getPlaceableBlocksAboveEntity(target)) {
            if (distance != -1.0 && !(mc.player.getDistanceSq(pos) < square(distance)))
                continue;
            finalPos = pos;
            distance = mc.player.getDistance(pos.getX(), pos.getY(), pos.getZ());
        }
        return finalPos;
    }

    private double square(double distance) {
        return distance * distance;
    }

    public List<BlockPos> getPlaceableBlocksAboveEntity(Entity target) {
        BlockPos pos;
        ArrayList<BlockPos> positions = new ArrayList<BlockPos>();
        for (int i = (int) Math.floor(mc.player.posY + 2.0); i <= 256
                && BlockUtil.isPositionPlaceable(pos = new BlockPos(Math.floor(mc.player.posX), i,
                Math.floor(mc.player.posZ)), false) != 0
                && BlockUtil.isPositionPlaceable(pos, false) != -1
                && BlockUtil.isPositionPlaceable(pos, false) != 2; ++i) {
            positions.add(pos);
        }
        return positions;
    }

    private void rotateToPos(BlockPos pos) {
        if (this.rotate.getValue()) {
            float[] angle = calcAngle(mc.player.getPositionEyes(mc.getRenderPartialTicks()),
                    new Vec3d((float) pos.getX() + 0.5f, (float) pos.getY() - 0.5f, (float) pos.getZ() + 0.5f));
            this.yaw = angle[0];
            this.pitch = angle[1];
            this.rotating = true;
        }
    }

    public static float[] calcAngle(Vec3d from, Vec3d to) {
        final double difX = to.x - from.x;
        final double difY = (to.y - from.y) * -1.0F;
        final double difZ = to.z - from.z;

        final double dist = MathHelper.sqrt(difX * difX + difZ * difZ);

        return new float[] { (float) MathHelper.wrapDegrees(Math.toDegrees(Math.atan2(difZ, difX)) - 90.0f),
                (float) MathHelper.wrapDegrees(Math.toDegrees(Math.atan2(difY, dist))) };
    }

}
