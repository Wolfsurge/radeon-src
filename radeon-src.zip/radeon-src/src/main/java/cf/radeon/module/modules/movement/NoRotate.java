package cf.radeon.module.modules.movement;

import cf.radeon.event.impl.PacketEvent;
import cf.radeon.module.Category;
import cf.radeon.module.Module;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.minecraft.network.play.server.SPacketPlayerPosLook;

/**
 * @author olliem5
 */

public final class NoRotate extends Module {

    public NoRotate() {
        super("NoRotate", "Prevents server packets from turning your head", Category.MOVEMENT);
    }

    @EventHandler
    private final Listener<PacketEvent.Receive> receiveListener = new Listener<>(event -> {
        if (nullCheck()) return;

        if (event.getPacket() instanceof SPacketPlayerPosLook) {
            SPacketPlayerPosLook sPacketPlayerPosLook = (SPacketPlayerPosLook) event.getPacket();

            sPacketPlayerPosLook.yaw = mc.player.rotationYaw;
            sPacketPlayerPosLook.pitch = mc.player.rotationPitch;
        }
    });
}
