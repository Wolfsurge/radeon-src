package cf.radeon.module.modules.render;

import cf.radeon.module.Category;
import cf.radeon.module.Module;
import cf.radeon.module.settings.ModeSetting;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;

import java.util.Objects;

public class Brightness extends Module {
    public static final ModeSetting brightnessMode = new ModeSetting("Mode", "The way of achieving brightness", "Gamma");

    public Brightness() {
        super("Brightness", "Makes your game brighter", Category.RENDER);
        this.addSettings(
                brightnessMode
        );
    }

    private final PotionEffect nightVision = new PotionEffect(Objects.requireNonNull(Potion.getPotionById(16)));

    private float originalGamma;

    @Override
    public void onEnable() {
        if (nullCheck()) return;

        if (brightnessMode.is("Gamma")) {
            originalGamma = mc.gameSettings.gammaSetting;
            mc.gameSettings.gammaSetting = 10;
        } else {
            mc.player.addPotionEffect(nightVision);
        }
    }

    @Override
    public void onDisable() {
        if (nullCheck()) return;

        if (brightnessMode.is("Gamma")) {
            mc.gameSettings.gammaSetting = originalGamma;
        } else {
            mc.player.removeActivePotionEffect(nightVision.getPotion());
        }
    }

    @Override
    public String getHUDData() {
        return brightnessMode.getMode();
    }
}
