package cf.radeon.module.modules.movement;

import cf.radeon.module.Category;
import cf.radeon.module.Module;
import cf.radeon.module.settings.ModeSetting;

/**
 * @author olliem5
 */

public final class Sprint extends Module {
    public static final ModeSetting sprintMode = new ModeSetting("Mode", "The type of sprint to perform", "Rage", "Legit");

    public Sprint() {
        super("Sprint", "Automatically makes you sprint", Category.MOVEMENT);
        this.addSettings(
                sprintMode
        );
    }

    public void onUpdate() {
        if (nullCheck()) return;

        try {
            if (keyCheck() && logicCheck()) {
                mc.player.setSprinting(true);
            }
        } catch (Exception ignored) {}
    }

    private boolean keyCheck() {
        switch (sprintMode.getMode()) {
            case "Legit":
                if (mc.gameSettings.keyBindForward.isKeyDown()) {
                    return true;
                }

                break;

            case "Rage":
                if (mc.gameSettings.keyBindForward.isKeyDown() || mc.gameSettings.keyBindBack.isKeyDown() || mc.gameSettings.keyBindLeft.isKeyDown() || mc.gameSettings.keyBindRight.isKeyDown()) {
                    return true;
                }

                break;
        }

        return false;
    }

    private boolean logicCheck() {
        switch (sprintMode.getMode()) {
            case "Legit":
                if (!mc.player.collidedHorizontally && !mc.player.isSneaking() && !mc.player.isHandActive() && mc.player.getFoodStats().getFoodLevel() > 6f) {
                    return true;
                }

                break;

            case "Rage":
                if (!mc.player.collidedHorizontally && !mc.player.isSneaking() && mc.player.getFoodStats().getFoodLevel() > 6f) {
                    return true;
                }

                break;
        }

        return false;
    }

    @Override
    public String getHUDData() {
        return sprintMode.getMode();
    }
}
