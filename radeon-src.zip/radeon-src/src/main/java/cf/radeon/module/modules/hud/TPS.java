package cf.radeon.module.modules.hud;

import cf.radeon.module.Category;
import cf.radeon.module.Module;

public class TPS extends Module {

    public TPS() {
        super("TPS", "Displays the current server's TPS on screen.", Category.HUD, true);
    }

}
