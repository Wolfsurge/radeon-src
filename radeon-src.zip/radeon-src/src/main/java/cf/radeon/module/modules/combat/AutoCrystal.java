    package cf.radeon.module.modules.combat;

import cf.radeon.event.impl.PacketEvent;
import cf.radeon.managers.RotationManager;
import cf.radeon.module.Category;
import cf.radeon.module.Module;
import cf.radeon.module.settings.*;
import cf.radeon.utils.block.BlockUtil;
import cf.radeon.utils.other.ChatUtil;
import cf.radeon.utils.player.InventoryUtil;
import cf.radeon.utils.player.PlayerUtil;
import cf.radeon.utils.render.Colour;
import cf.radeon.utils.render.RenderUtil3D;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityEnderCrystal;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.init.MobEffects;
import net.minecraft.init.SoundEvents;
import net.minecraft.item.ItemEndCrystal;
import net.minecraft.item.ItemSword;
import net.minecraft.network.play.client.CPacketUseEntity;
import net.minecraft.network.play.server.SPacketSoundEffect;
import net.minecraft.util.EnumHand;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.BlockPos;
import org.lwjgl.opengl.GL11;
import cf.radeon.utils.combat.*;
import cf.radeon.utils.combat.crystal.*;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * @author Z3R0
 *
 *         TODO: Settings to add
 *
 *         Break - Actual good timing - Min Damage
 *
 *         Place - Walls Range - Range for block to target
 *
 *         TODO: Better prediction, based on target as well...?
 *         TODO: Fix compatibility with AutoSwitch & AntiWeakness.
 *         TODO: Actual rotation system!
 *         TODO: Better MultiPlace.
 *         TODO: Other Place Calculations.
 *         TODO: AutoSwitch override when holding gaps or pickaxe. TODO: 'Both'
 *         Text render mode.
 *         TODO: Better delays!
 *         TODO: Pause modes for place &
 *         break.
 *         TODO: Check number comparisons
 *
 *         TODO: Fix lag (there is a little)
 *         TODO: Multithread
 *         TODO: Multiplace configuration
 */

public final class AutoCrystal extends Module {

    public static final BooleanSetting crystalBreak = new BooleanSetting("Break", "Allows for crystals to be broken", true);
    public static final ModeSetting breakMode = new ModeSetting("Type", "The mode for how the crystal is broken", "Packet", "Swing");
    public static final ModeSetting swingMode = new ModeSetting("Swing", "The mode for how the player swings at the crystal", "None", "Mainhand", "Offhand", "Both", "Spam");
    public static final ModeSetting syncMode = new ModeSetting("Sync", "The way the crystal is synced", "None", "Attack", "Packet", "Sound");
    public static final BooleanSetting antiWeakness = new BooleanSetting("Anti Weakness", "Allow switching to a sword or tool when you have weakness", false);
    public static final BooleanSetting throughWalls = new BooleanSetting("Through Walls", "Allows the AutoCrystal to break through walls", true);
    public static final NumberSetting breakRange = new NumberSetting("Range", "The range to break crystals in", 0.0, 5.0, 7.0, 0.1);
    public static final NumberSetting breakAttempts = new NumberSetting("Break Attempts", "How many times attempt to break the crystal", 1, 1, 5, 1);
    public static final NumberSetting breakDelay = new NumberSetting("Delay", "The delay between crystal breaks", 0, 2, 20, 1);

    public static final BooleanSetting crystalPlace = new BooleanSetting("Place", "Allows for crystals to be placed", true);
    public static final ModeSetting placeMode = new ModeSetting("Type", "The mode for how the crystal is placed", "Packet", "Standard");
    public static final BooleanSetting autoSwitch = new BooleanSetting("Auto Switch", "Switches to crystals before placing", false);
    public static final BooleanSetting raytrace = new BooleanSetting("Raytrace", "Allow raytracing for placements", true);
    public static final BooleanSetting multiPlace = new BooleanSetting("Multi Place", "Place multiple crystals before a break", false);
    public static final BooleanSetting predictPlace = new BooleanSetting("Predict", "Takes movement into account for placements", false);
    public static final BooleanSetting verifyPlace = new BooleanSetting("Verify", "Verifies the eligibility for a place", false);
    public static final NumberSetting placeRange = new NumberSetting("Range", "The range to place crystals in", 0.0, 5.0, 7.0, 0.1);
    public static final NumberSetting wallRange = new NumberSetting("Wall Range", "The range to place through walls in", 0.0, 3.0, 7.0, 0.1);
    public static final NumberSetting minDamage = new NumberSetting("Min Target Damage", "Minimum target damage for a place", 0.0, 7.0, 36.0, 1);
    public static final NumberSetting maxSelfPlaceDamage = new NumberSetting("Max Self Damage", "Maximum self damage for a place", 0.0, 8.0, 36.0, 1);
    public static final NumberSetting placeDelay = new NumberSetting("Delay", "The delay between crystal places", 0, 2, 20, 1);

    public static final BooleanSetting crystalRotations = new BooleanSetting("Rotate", "Allow for rotations", false);
    public static final ModeSetting rotateMode = new ModeSetting("Mode", "The mode to use for rotations", "Packet", "Legit");
    public static final ModeSetting rotateWhen = new ModeSetting("When", "When to rotate", "Break", "Place", "Both");

    public static final BooleanSetting crystalCalculations = new BooleanSetting("Calculations", "Controls how AutoCrystal calculates", true);
    public static final ModeSetting logicMode = new ModeSetting("Order", "The order to perform AutoCrystal functions", "BreakPlace", "PlaceBreak");
    public static final ModeSetting blockLogicMode = new ModeSetting("Game Version", "The game version to check for blocks to place crystals on", "Twelve", "Thirteen+");
    public static final NumberSetting targetRange = new NumberSetting("Target Range", "The range the target can be in", 1.0, 10.0, 15.0, 0.1);
    public static final ModeSetting targetGetter = new ModeSetting("Targetting type", "The type of targetting to use.", "New", "Old");

    public static final BooleanSetting crystalPause = new BooleanSetting("Pause", "Controls when the AutoCrystal pauses", true);
    public static final BooleanSetting pauseHealthAllow = new BooleanSetting("At Specified Health", "Pauses the AutoCrystal at a specified health", true);
    public static final NumberSetting pauseHealth = new NumberSetting("Health", "Health to be at to pause the AutoCrystal", 0.0, 8.0, 36.0, 1);
    public static final BooleanSetting pauseWhileMining = new BooleanSetting("While Mining", "Pauses the AutoCrystal while mining", false);
    public static final BooleanSetting pauseWhileEating = new BooleanSetting("While Eating", "Pauses the AutoCrystal while eating", false);

    public static final BooleanSetting crystalRender = new BooleanSetting("Render", "Allows the crystal placements to be rendered", true);
    public static final ModeSetting blockRenderMode = new ModeSetting("Block Mode", "The type of box to render", "Full", "Box", "Outline", "None");
    public static final NumberSetting outlineWidth = new NumberSetting("Outline Width", "The width of the outline", 1.0, 2.0, 5.0, 0.5);
    public static final ColourPicker renderColour = new ColourPicker("Render Colour", "The colour for the crystal placements", new Colour(231, 15, 101, 180));

    public AutoCrystal() {
        super("AutoCrystal", "Places and destroys end crystals to kill enemies", Category.COMBAT);
        addSettings(crystalBreak, breakMode, swingMode, syncMode, antiWeakness, throughWalls, breakRange, breakAttempts, breakDelay); // Break
        addSettings(crystalPlace, placeMode, autoSwitch, raytrace, multiPlace, predictPlace, verifyPlace, placeRange, wallRange, minDamage, maxSelfPlaceDamage, placeDelay); // Place
        addSettings(crystalRotations, rotateMode, rotateWhen); // Rotate
        addSettings(crystalCalculations, logicMode, blockLogicMode, targetRange, targetGetter); // Logic and targeting
        addSettings(crystalPause, pauseHealthAllow, pauseHealth, pauseWhileMining, pauseWhileEating); // Pause
        addSettings(crystalRender, blockRenderMode, outlineWidth, renderColour); // Pause
    }

    private final CooldownUtil breakTimer = new CooldownUtil();
    private final CooldownUtil placeTimer = new CooldownUtil();

    public static EntityPlayer playerTarget = null;
    private CrystalPosition crystalTarget = new CrystalPosition(null, 0, 0);

    @Override
    public void onDisable() {
        if (nullCheck())
            return;

        playerTarget = null;
        crystalTarget = null;
    }

    public void onUpdate() {
        if (nullCheck())
            return;

        try {
            playerTarget = getNextTarget();

            if (playerTarget == null
                    || playerTarget.isDead
                    || playerTarget.getHealth() <= 0.0
                    || playerTarget.getDistance(mc.player) > targetRange.getFloatValue()
                    || !isHoldingCrystal())
                return;

            implementLogic();
        } catch (Throwable e) {
            e.printStackTrace();
        }

    }

    private EntityPlayer getNextTarget() {
        if(crystalCalculations.getValue()) {
            switch(targetGetter.getMode()) {
                case "Old": {
                    return TargetUtil.getClosestPlayer(targetRange.getFloatValue());
                }
                case "New": {
                    return TargetUtil.getClosestPlayer2(targetRange.getFloatValue());
                }
                default: {
                    return TargetUtil.getClosestPlayer2(targetRange.getFloatValue());
                }
            }
        } else {
            return TargetUtil.getClosestPlayer2(targetRange.getFloatValue());
        }
    }

    private boolean isHoldingCrystal() {
        return mc.player.getHeldItemMainhand().getItem() != null && (mc.player.getHeldItemMainhand().getItem() == Items.END_CRYSTAL || mc.player.getHeldItemOffhand().getItem() == Items.END_CRYSTAL);
    }

    private void implementLogic() {
        switch (logicMode.getMode()) {
            case "BreakPlace":
                breakCrystal();
                placeCrystal();
                break;
            case "PlaceBreak":
                placeCrystal();
                breakCrystal();
                break;
        }
    }

    private void breakCrystal() {
        if (handlePause())
            return;

        if (crystalBreak.getValue()) {
            EntityEnderCrystal entityEnderCrystal = (EntityEnderCrystal) mc.world.loadedEntityList.stream()
                    .filter(entity -> entity instanceof EntityEnderCrystal)
                    // TODO: Filter for attack check
                    .min(Comparator.comparing(entity -> mc.player.getDistance(entity))).orElse(null);

            if (entityEnderCrystal != null && !entityEnderCrystal.isDead
                    && breakTimer.passed(breakDelay.getDoubleValue() * 60)) {
                if (!(mc.player.getDistance(entityEnderCrystal) <= breakRange.getDoubleValue()))
                    return;

                if (!mc.player.canEntityBeSeen(entityEnderCrystal) && !throughWalls.getValue())
                    return;

                if (antiWeakness.getValue() && mc.player.isPotionActive(MobEffects.WEAKNESS)) {
                    InventoryUtil.switchToSlot(ItemSword.class);
                }

                if (crystalRotations.getValue()) {
                    if (rotateWhen.is("Break")
                            || rotateWhen.is("Both")) {
                        RotationManager.rotateToEntity(entityEnderCrystal,
                                rotateMode.is("Packet"));
                    }
                }

                handleBreak(entityEnderCrystal);

                if (syncMode.is("Attack")) {
                    entityEnderCrystal.setDead();
                }

                breakTimer.reset();
            }
        }
    }

    private void placeCrystal() {
        if (handlePause())
            return;

        try {
            if (crystalPlace.getValue()) {
                List<CrystalPosition> crystalPositions = new ArrayList<>();

                CrystalPosition tempPosition;

                for (BlockPos blockPos : crystalBlocks(mc.player, placeRange.getDoubleValue(), predictPlace.getValue(),
                        !multiPlace.getValue(), blockLogicMode.is("Thirteen+"))) {
                    if (PlayerUtil.isInViewFrustrum(blockPos)
                            && mc.player.getDistanceSq(blockPos) >= Math.pow(wallRange.getDoubleValue(), 2))
                        continue;

                    if (verifyPlace.getValue()
                            && mc.player.getDistanceSq(blockPos) >= Math.pow(breakRange.getDoubleValue(), 2))
                        continue;

                    double calculatedTargetDamage = CrystalUtil.calculateDamage(blockPos.getX() + 0.5,
                            blockPos.getY() + 1, blockPos.getZ() + 0.5, playerTarget);
                    double calculatedSelfDamage = mc.player.capabilities.isCreativeMode ? 0
                            : CrystalUtil.calculateDamage(blockPos.getX() + 0.5, blockPos.getY() + 1,
                            blockPos.getZ() + 0.5, mc.player);

                    if (calculatedTargetDamage < minDamage.getDoubleValue())
                        continue;

                    if (calculatedSelfDamage > maxSelfPlaceDamage.getDoubleValue())
                        continue;

                    crystalPositions.add(new CrystalPosition(blockPos, calculatedTargetDamage, calculatedSelfDamage));
                }

                tempPosition = crystalPositions.stream().max(Comparator.comparing(CrystalPosition::getTargetDamage)) // TODO:
                        // Different
                        // calculation
                        // algorithms
                        .orElse(null);

                if (tempPosition == null) {
                    crystalTarget = null;

                    return;
                }

                crystalTarget = tempPosition;

                if (crystalTarget.getPosition() != null && placeTimer.passed(placeDelay.getDoubleValue() * 60)) {
                    if (autoSwitch.getValue()) {
                        InventoryUtil.switchToSlot(ItemEndCrystal.class);
                    }

                    if (crystalRotations.getValue()) {
                        if (rotateWhen.is("Place")
                                || rotateWhen.is("Both")) {
                            RotationManager.rotateToBlockPos(crystalTarget.getPosition(),
                                    rotateMode.is("Packet"));
                        }
                    }

                    if (mc.player.getHeldItemMainhand().getItem() == Items.END_CRYSTAL
                            || mc.player.getHeldItemOffhand().getItem() == Items.END_CRYSTAL) {
                        CrystalUtil.placeCrystal(crystalTarget.getPosition(),
                                CrystalUtil.getEnumFacing(raytrace.getValue(), crystalTarget.getPosition()),
                                placeMode.is("Place"));
                    }

                    placeTimer.reset();
                }
            }
        } catch (Throwable e) {
            e.printStackTrace();
            mc.shutdown();
            e.printStackTrace();
        }

    }

    private void handleBreak(EntityEnderCrystal entityEnderCrystal) {
        for (int i = 0; i < breakAttempts.getDoubleValue(); i++) {
            switch (breakMode.getMode()) {
                case "Swing":
                    CrystalUtil.breakCrystal(entityEnderCrystal, false);
                    break;
                case "Packet":
                    CrystalUtil.breakCrystal(entityEnderCrystal, true);
                    break;
            }
        }

        switch (swingMode.getMode()) {
            case "Mainhand":
                mc.player.swingArm(EnumHand.MAIN_HAND);
                break;
            case "Offhand":
                mc.player.swingArm(EnumHand.OFF_HAND);
                break;
            case "Spam":
                for(int i = 0; i < 10; i ++) {
                    mc.player.swingArm(EnumHand.MAIN_HAND);
                }
                break;
            case "Both":
                mc.player.swingArm(EnumHand.MAIN_HAND);
                mc.player.swingArm(EnumHand.OFF_HAND);
                break;
            case "None":
                break;
            default:
                break;
        }
    }

    private boolean handlePause() {
        if(mc.player.isCreative()) return false;
        if ((mc.player.getHealth() + mc.player.getAbsorptionAmount()) <= pauseHealth.getDoubleValue()
                && pauseHealthAllow.getValue() && crystalPause.getValue())
            return true;

        if (mc.player.getHeldItemMainhand().getItem() == Items.GOLDEN_APPLE && mc.player.isHandActive()
                && pauseWhileEating.getValue() && crystalPause.getValue())
            return true;

        if (mc.player.getHeldItemMainhand().getItem() == Items.DIAMOND_PICKAXE && mc.player.isHandActive()
                && pauseWhileMining.getValue() && crystalPause.getValue())
            return true;

        return false;
    }

    public static List<BlockPos> crystalBlocks(EntityPlayer entityPlayer, double placeRange, boolean prediction,
                                               boolean multiPlace, boolean thirteen) {
        return BlockUtil.getNearbyBlocks(entityPlayer, placeRange, prediction).stream()
                .filter(blockPos -> CrystalUtil.canPlaceCrystal(blockPos, multiPlace, thirteen))
                .collect(Collectors.toList());
    }

    @Override
    public void onRenderWorld() {
        if (nullCheck())
            return;

        GlStateManager.pushMatrix();

        try {
            if (crystalRender.getValue() && crystalTarget != null) {
                GL11.glLineWidth(outlineWidth.getFloatValue());

                if (!blockRenderMode.is("None")) {
                    try {
                        RenderUtil3D.draw(crystalTarget.getPosition(),
                                !blockRenderMode.is("Outline"),
                                !blockRenderMode.is("Box"), 0, 0, renderColour.getColor());
                    } catch (Throwable e) {
                    }

                }

//				String targetDamageRounded = String.format("%.1f", crystalTarget.getTargetDamage());
//				String selfDamageRounded = String.format("%.1f", crystalTarget.getSelfDamage());
                //TODO: debug setting to display these


            }
        } catch (Throwable e) {
            e.printStackTrace();
            ChatUtil.addChatMessage("autocrystal error: msg in console!");
        }


        GlStateManager.popMatrix();

    }

    @EventHandler
    private final Listener<PacketEvent.Send> sendListener = new Listener<>(event -> {
        if (nullCheck())
            return;

        if (syncMode.is("Packet")) {
            if (event.getPacket() instanceof CPacketUseEntity) {
                CPacketUseEntity cPacketUseEntity = (CPacketUseEntity) event.getPacket();

                if (cPacketUseEntity.getAction() == CPacketUseEntity.Action.ATTACK
                        && cPacketUseEntity.getEntityFromWorld(mc.world) instanceof EntityEnderCrystal
                        && breakMode.is("Packet")) {
                    Objects.requireNonNull(cPacketUseEntity.getEntityFromWorld(mc.world)).setDead();
                }
            }
        }
    });

    @EventHandler
    private final Listener<PacketEvent.Receive> receiveListener = new Listener<>(event -> {
        if (nullCheck())
            return;

        if (syncMode.is("Sound")) {
            if (event.getPacket() instanceof SPacketSoundEffect) {
                SPacketSoundEffect sPacketSoundEffect = (SPacketSoundEffect) event.getPacket();

                if (sPacketSoundEffect.getCategory() == SoundCategory.BLOCKS
                        && sPacketSoundEffect.getSound() == SoundEvents.ENTITY_GENERIC_EXPLODE) {
                    for (Entity entity : mc.world.loadedEntityList) {
                        if (entity instanceof EntityEnderCrystal) {
                            if (entity.getDistance(sPacketSoundEffect.getX(), sPacketSoundEffect.getY(),
                                    sPacketSoundEffect.getZ()) <= breakRange.getDoubleValue()) {
                                entity.setDead();
                            }
                        }
                    }
                }
            }
        }
    });

    @Override
    public String getHUDData() {
        if (playerTarget != null) {
            return playerTarget.getName();
        }

        return "";
    }

    public enum BreakModes {
        Swing,
        Packet
    }

    public enum SwingModes {
        Mainhand,
        Offhand,
        Spam,
        Both,
        None
    }

    public enum PlaceModes {
        Standard,
        Packet
    }

    public enum SyncModes {
        None,
        Attack,
        Packet,
        Sound
    }

    public enum RotationModes {
        Packet,
        Legit
    }

    public enum RotateWhenModes {
        Break, Place, Both
    }

    public enum LogicModes {
        BreakPlace, PlaceBreak
    }

    public enum BlockLogicModes {
        Twelve("1.12"),
        Thirteen("1.13+");


        String name;
        private BlockLogicModes(String name) {
            this.name = name;
        }

        public String getName() {
            return name;
        }

        @Override
        public String toString() {
            return name;
        }
    }

    public enum BlockRenderModes {
        Box,
        Outline,
        Full,
        None
    }

    public enum TextRenderModes {
        Target,
        Self,
        Both,
        None
    }

    public enum NewOld {
        New,
        Old
    }
}
