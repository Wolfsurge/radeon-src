package cf.radeon.module.modules.render.esp.modes;

import cf.radeon.module.modules.render.ESP;
import cf.radeon.module.modules.render.esp.ESPMode;
import cf.radeon.utils.render.RenderUtil3D;
import net.minecraft.client.renderer.RenderGlobal;
import net.minecraft.util.math.AxisAlignedBB;
import org.lwjgl.opengl.GL11;
import java.util.Objects;

/**
 * @author olliem5
 */

public final class Box extends ESPMode {
    @Override
    public void drawESP() {
        mc.world.loadedEntityList.stream()
                .filter(Objects::nonNull)
                .filter(entity -> mc.player != entity)
                .filter(ESP::entityCheck)
                .forEach(entity -> {
                    RenderUtil3D.prepareGL();

                    AxisAlignedBB axisAlignedBB = entity.boundingBox.offset(-mc.renderManager.renderPosX, -mc.renderManager.renderPosY, -mc.renderManager.renderPosZ);

                    GL11.glLineWidth(ESP.lineWidth.getFloatValue());

                    RenderGlobal.drawSelectionBoundingBox(axisAlignedBB, ESP.getESPColour(entity).getRed() / 255.0f, ESP.getESPColour(entity).getGreen() / 255.0f, ESP.getESPColour(entity).getBlue() / 255.0f, ESP.getESPColour(entity).getAlpha() / 255.0f);

                    RenderUtil3D.releaseGL();
                });
    }
}
