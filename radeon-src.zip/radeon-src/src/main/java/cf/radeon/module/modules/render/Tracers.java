package cf.radeon.module.modules.render;

import cf.radeon.managers.FriendManager;
import cf.radeon.module.Category;
import cf.radeon.module.Module;
import cf.radeon.module.modules.client.Social;
import cf.radeon.module.settings.BooleanSetting;
import cf.radeon.module.settings.ColourPicker;
import cf.radeon.module.settings.NumberSetting;
import cf.radeon.utils.entity.EntityUtil;
import cf.radeon.utils.render.Colour;
import cf.radeon.utils.render.DrawUtil;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityEnderCrystal;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.entity.passive.EntityAnimal;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.Vec3d;

import java.awt.*;
import java.util.Objects;

/**
 * @author olliem5
 */

public final class Tracers extends Module {
    public static final NumberSetting lineWidth = new NumberSetting("Line Width", "The width of the lines", 1.0, 2.0, 5.0, 1);

    public static final BooleanSetting crystals = new BooleanSetting("Crystals", "Allows Tracers to function on crystals", true);
    public static final ColourPicker crystalColour = new ColourPicker("Crystal Colour", "The colour for crystals", new Colour(106, 22, 219, 100));

    public static final BooleanSetting players = new BooleanSetting("Players", "Allows Tracers to function on players", true);
    public static final ColourPicker playerColour = new ColourPicker("Player Colour", "The colour for players", new Colour(106, 22, 219, 100));

    public static final BooleanSetting animals = new BooleanSetting("Animals", "Allows Tracers to function on animals", true);
    public static final ColourPicker animalColour = new ColourPicker("Animal Colour", "The colour for animals", new Colour(75, 219, 22, 100));

    public static final BooleanSetting mobs = new BooleanSetting("Mobs", "Allows Tracers to function on animals", true);
    public static final ColourPicker mobColour = new ColourPicker("Mob Colour", "The colour for animals", new Colour(236, 13, 29, 100));

    public Tracers() {
        super("Tracers", "Renders lines to entities", Category.RENDER);
        this.addSetting(lineWidth);
        this.addSettings(crystals, crystalColour);
        this.addSettings(players, playerColour);
        this.addSettings(animals, animalColour);
        this.addSettings(mobs, mobColour);
    }

    public static boolean entityCheck(Entity entity) {
        return entity instanceof EntityEnderCrystal && crystals.getValue() || entity instanceof EntityPlayer && players.getValue() || entity instanceof EntityAnimal && animals.getValue() || entity instanceof EntityMob && mobs.getValue();
    }

    public static Color getTracerColour(Entity entity) {
        if (entity instanceof EntityEnderCrystal) {
            return new Color(crystalColour.getValue().getRed(), crystalColour.getValue().getGreen(), crystalColour.getValue().getBlue(), crystalColour.getValue().getAlpha());
        }

        if (entity instanceof EntityPlayer) {
            if (FriendManager.isFriend(entity.getName())) {
                return new Color(Social.friendColour.getValue().getRed(), Social.friendColour.getValue().getGreen(), Social.friendColour.getValue().getBlue(), Social.friendColour.getValue().getAlpha());
            } else if(!FriendManager.isEnemy(entity.getName())) {
                return new Color(Social.enemyColour.getValue().getRed(), Social.enemyColour.getValue().getGreen(), Social.enemyColour.getValue().getBlue(), Social.enemyColour.getValue().getAlpha());
            } else {
                return new Color(playerColour.getValue().getRed(), playerColour.getValue().getGreen(), playerColour.getValue().getBlue(), playerColour.getValue().getAlpha());
            }
        }

        if (entity instanceof EntityAnimal) {
            return new Color(animalColour.getValue().getRed(), animalColour.getValue().getGreen(), animalColour.getValue().getBlue(), animalColour.getValue().getAlpha());
        }

        if (entity instanceof EntityMob) {
            return new Color(mobColour.getValue().getRed(), mobColour.getValue().getGreen(), mobColour.getValue().getBlue(), mobColour.getValue().getAlpha());
        }

        return new Color(255, 255, 255, 255);
    }

    public void onRenderWorld() {
        if (nullCheck()) return;

        mc.world.loadedEntityList.stream()
                .filter(Objects::nonNull)
                .filter(entity -> mc.player != entity)
                .filter(Tracers::entityCheck)
                .forEach(entity -> {
                    Vec3d vec3d = EntityUtil.getInterpolatedPos(entity, mc.getRenderPartialTicks()).subtract(mc.getRenderManager().renderPosX, mc.getRenderManager().renderPosY, mc.getRenderManager().renderPosZ);

                    mc.entityRenderer.setupCameraTransform(mc.getRenderPartialTicks(), 0);

                    Vec3d vec3d1 = new Vec3d(0, 0, 1).rotatePitch(-(float) Math.toRadians(mc.player.rotationPitch)).rotateYaw(-(float) Math.toRadians(mc.player.rotationYaw));
                    DrawUtil.drawLine3D((float) vec3d1.x, (float) vec3d1.y + mc.player.getEyeHeight(), (float) vec3d1.z, (float) vec3d.x, (float) vec3d.y, (float) vec3d.z, lineWidth.getFloatValue(), getTracerColour(entity));

                    mc.entityRenderer.setupCameraTransform(mc.getRenderPartialTicks(), 0);
                });
    }
}
