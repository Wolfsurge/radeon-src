package cf.radeon.module.modules.combat;

import cf.radeon.Radeon;
import cf.radeon.module.Category;
import cf.radeon.module.Module;
import cf.radeon.module.settings.BooleanSetting;
import cf.radeon.module.settings.ColourPicker;
import cf.radeon.module.settings.ModeSetting;
import cf.radeon.module.settings.NumberSetting;
import cf.radeon.notifications.Notification;
import cf.radeon.notifications.NotificationType;
import cf.radeon.utils.block.BlockUtil;
import cf.radeon.utils.block.Offsets;
import cf.radeon.utils.block.PlacementUtil;
import cf.radeon.utils.combat.crystal.PlaceUtil;
import cf.radeon.utils.other.ChatUtil;
import cf.radeon.utils.other.Timer;
import cf.radeon.utils.player.InventoryUtil;
import cf.radeon.utils.player.PlayerUtil;
import cf.radeon.utils.render.Colour;
import cf.radeon.utils.render.RenderUtil3D;
import com.mojang.realmsclient.gui.ChatFormatting;
import net.minecraft.block.BlockObsidian;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBlock;
import net.minecraft.network.play.client.CPacketHeldItemChange;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.opengl.GL11;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/**
 * @author olliem5
 */

public final class SelfTrap extends Module {

    ModeSetting offsetMode = new ModeSetting("Pattern", "What pattern to use", "Normal", "No Step", "Simple", "Simple No Step");
    NumberSetting delayTicks = new NumberSetting("Tick Delay", 3, 0, 10, 1);
    NumberSetting blocksPerTick = new NumberSetting("Blocks Per Tick", 4, 1, 8, 1);
    BooleanSetting rotate = new BooleanSetting("Rotate", true);
    BooleanSetting centerPlayer = new BooleanSetting("Center Player", false);
    BooleanSetting sneakOnly = new BooleanSetting("Sneak Only", false);
    BooleanSetting disableNoBlock = new BooleanSetting("Disable No Obby", true);
    BooleanSetting offhandObby = new BooleanSetting("Offhand Obby", false);
    BooleanSetting silentSwitch = new BooleanSetting("Silent Switch", false);

    private final Timer delayTimer = new Timer();
    private Vec3d centeredBlock = Vec3d.ZERO;

    private int oldSlot = -1;
    private int offsetSteps = 0;
    private boolean outOfTargetBlock = false;
    private boolean activedOff = false;
    private boolean isSneaking = false;
    boolean hasPlaced;

    public SelfTrap() {
        super("SelfTrap", "Traps yourself", Category.COMBAT);
        this.addSettings(
                offsetMode,
                delayTicks,
                blocksPerTick,
                rotate,
                centerPlayer,
                sneakOnly,
                disableNoBlock,
                offhandObby,
                silentSwitch
        );
    }

    public void onEnable() {
        PlacementUtil.onEnable();
        if (mc.player == null || mc.world == null) {
            disable();
            return;
        }

        if (centerPlayer.getValue() && mc.player.onGround) {
            mc.player.motionX = 0;
            mc.player.motionZ = 0;
        }

        centeredBlock = BlockUtil.getCenterOfBlock(mc.player.posX, mc.player.posY, mc.player.posY);

        oldSlot = mc.player.inventory.currentItem;
    }

    public void onDisable() {
        PlacementUtil.onDisable();
        if (mc.player == null | mc.world == null) return;

        if (outOfTargetBlock) ChatUtil.addChatMessage("No obsidian detected... SelfTrap turned OFF!");

        if (oldSlot != mc.player.inventory.currentItem && oldSlot != -1 && oldSlot != 9) {
            mc.player.inventory.currentItem = oldSlot;
            oldSlot = -1;
        }

        centeredBlock = Vec3d.ZERO;
        outOfTargetBlock = false;
    }

    public void onUpdate() {
        if (mc.player == null || mc.world == null) {
            disable();
            return;
        }

        if (sneakOnly.getValue() && !mc.player.isSneaking()) {
            return;
        }

        int targetBlockSlot = InventoryUtil.findCrystalBlockSlot(offhandObby.getValue(), activedOff);

        if ((outOfTargetBlock || targetBlockSlot == -1) && disableNoBlock.getValue()) {
            outOfTargetBlock = true;
            disable();
            return;
        }

        activedOff = true;

        if (centerPlayer.getValue() && centeredBlock != Vec3d.ZERO && mc.player.onGround) {
            PlayerUtil.centerPlayer(centeredBlock);
        }

        if (delayTimer.getTime() / 50L >= delayTicks.getDoubleValue()) {
            delayTimer.reset();

            int blocksPlaced = 0;

            hasPlaced = false;

            while (blocksPlaced <= blocksPerTick.getDoubleValue()) {
                int maxSteps;
                Vec3d[] offsetPattern;

                switch (offsetMode.getMode()) {
                    case "No Step": {
                        offsetPattern = Offsets.TRAP_STEP;
                        maxSteps = Offsets.TRAP_STEP.length;
                        break;
                    }
                    case "Simple": {
                        offsetPattern = Offsets.TRAP_SIMPLE;
                        maxSteps = Offsets.TRAP_SIMPLE.length;
                        break;
                    }
                    case "Normal": {
                        offsetPattern = Offsets.TRAP_FULL;
                        maxSteps = Offsets.TRAP_FULL.length;
                        break;
                    }
                    default: {

                        offsetPattern = Offsets.TRAP_SIMPLE_NOSTEP;
                        maxSteps = offsetPattern.length;
                        break;

                    }
                }

                if (offsetSteps >= maxSteps) {
                    offsetSteps = 0;
                    break;
                }

                BlockPos offsetPos = new BlockPos(offsetPattern[offsetSteps]);
                BlockPos targetPos = new BlockPos(mc.player.getPositionVector()).add(offsetPos.getX(), offsetPos.getY(), offsetPos.getZ());

                boolean tryPlacing = true;

                if (mc.player.posY % 1 > 0.2) {
                    targetPos = new BlockPos(targetPos.getX(), targetPos.getY() + 1, targetPos.getZ());
                }

                if (!mc.world.getBlockState(targetPos).getMaterial().isReplaceable()) {
                    tryPlacing = false;
                }

                for (Entity entity : mc.world.getEntitiesWithinAABBExcludingEntity(null, new AxisAlignedBB(targetPos))) {
                    if (entity instanceof EntityPlayer) {
                        tryPlacing = false;
                        break;
                    }
                }

                if (tryPlacing && placeBlock(targetPos)) {
                    blocksPlaced++;
                }

                offsetSteps++;
            }
            if (hasPlaced)
                mc.player.connection.sendPacket(new CPacketHeldItemChange(oldSlot));
        }
    }

    private boolean placeBlock(BlockPos pos) {
        EnumHand handSwing = EnumHand.MAIN_HAND;

        int targetBlockSlot = InventoryUtil.findCrystalBlockSlot(offhandObby.getValue(), activedOff);

        if (targetBlockSlot == -1) {
            outOfTargetBlock = true;
            return false;
        }

        if (targetBlockSlot == 9) {
            activedOff = true;
            if (mc.player.getHeldItemOffhand().getItem() instanceof ItemBlock && ((ItemBlock) mc.player.getHeldItemOffhand().getItem()).getBlock() instanceof BlockObsidian) {
                handSwing = EnumHand.OFF_HAND;
            } else return false;
        }

        if (mc.player.inventory.currentItem != targetBlockSlot && targetBlockSlot != 9) {
            if (silentSwitch.getValue()) {
                if (!hasPlaced) {
                    mc.player.connection.sendPacket(new CPacketHeldItemChange(targetBlockSlot));
                    hasPlaced = true;
                }
            } else
                mc.player.inventory.currentItem = targetBlockSlot;
        }

        try {
            return PlacementUtil.place(pos, handSwing, rotate.getValue(), !silentSwitch.getValue());
        } catch(Exception e) {
            Radeon.notificationManager.addToQueue(new Notification("Error", "Exception caused by SelfTrap", NotificationType.ERROR));
            toggle();
        }
        return false;
    }
}
