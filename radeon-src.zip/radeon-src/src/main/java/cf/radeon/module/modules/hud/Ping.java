package cf.radeon.module.modules.hud;

import cf.radeon.module.Category;
import cf.radeon.module.Module;

public class Ping extends Module {

    public Ping() {
        super("Ping", "Displays your ping on screen.", Category.HUD, true);
    }

}
